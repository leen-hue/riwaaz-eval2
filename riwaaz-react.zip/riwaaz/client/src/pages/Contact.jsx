import { useEffect, useState } from "react";
import FormField from "../components/FormField";
import { useUI } from "../context/UIContext";
import { meta as homeMeta } from "./Home";

export const meta = { ...homeMeta, page: "contact", route: "/contact", title: "Contact — RIWAAZ" };

const DRAFT_KEY = "riwaaz_contact_draft";
const EMPTY = { name: "", email: "", message: "" };

// Demonstrates: controlled form, localStorage draft, fetch API, async/await, JSON handling.
export default function Contact() {
  const { showToast } = useUI();
  const [values, setValues] = useState(() => {
    try {
      return { ...EMPTY, ...JSON.parse(localStorage.getItem(DRAFT_KEY)) };
    } catch {
      return EMPTY;
    }
  });
  const [status, setStatus] = useState("idle"); // idle | sending | sent
  const [error, setError] = useState("");

  // Save the draft as the user types so a refresh doesn't lose it.
  useEffect(() => {
    localStorage.setItem(DRAFT_KEY, JSON.stringify(values));
  }, [values]);

  const onChange = (e) => setValues((v) => ({ ...v, [e.target.name]: e.target.value }));

  async function onSubmit(e) {
    e.preventDefault();
    setError("");
    setStatus("sending");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      const data = await res.json(); // JSON handling
      if (!res.ok) throw new Error(data.message || "Could not send your message.");
      localStorage.removeItem(DRAFT_KEY);
      setValues(EMPTY);
      setStatus("sent");
      showToast("Message sent — we'll be in touch");
    } catch (err) {
      setError(err.message);
      setStatus("idle");
    }
  }

  return (
    <main className="max-w-2xl mx-auto px-margin-mobile py-lg flex flex-col gap-md">
      <h1 className="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg">Contact Us</h1>
      <form onSubmit={onSubmit} className="bg-surface-container-low border-[0.5px] border-outline/30 rounded-lg p-md flex flex-col gap-sm">
        <FormField label="Name" name="name" value={values.name} onChange={onChange} required />
        <FormField label="Email" name="email" type="email" value={values.email} onChange={onChange} required />
        <FormField label="Message" name="message" as="textarea" rows={5} value={values.message} onChange={onChange} required minLength={10} />
        {error && <p className="font-label-caps text-label-caps text-error">{error}</p>}
        {status === "sent" && <p className="font-label-caps text-label-caps text-gold-muted">Thank you — your message was received.</p>}
        <button disabled={status === "sending"} className="gold-gradient-bg text-on-primary font-label-caps text-label-caps uppercase tracking-widest py-sm rounded-lg disabled:opacity-60">
          {status === "sending" ? "Sending…" : "Send message"}
        </button>
      </form>
    </main>
  );
}
