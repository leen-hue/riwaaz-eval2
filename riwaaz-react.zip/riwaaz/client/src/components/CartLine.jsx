import { useShop } from "../context/ShopContext";
import { formatINR } from "../utils/format";

export default function CartLine({ item }) {
  const { setQty, removeItem } = useShop();
  return (
    <div className="bg-surface-container-low rounded-lg p-sm md:p-md border-[0.5px] border-outline/20 flex gap-md relative overflow-hidden group transition-all duration-300 hover:border-outline-gold/50">
      <div className="w-24 md:w-32 aspect-[3/4] rounded bg-surface-container-high overflow-hidden shrink-0 relative">
        <img className="w-full h-full object-cover" src={item.image} alt={item.name} />
        <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent"></div>
      </div>
      <div className="flex flex-col justify-between flex-1 py-xs">
        <div>
          <div className="flex justify-between items-start mb-xs">
            <h3 className="font-headline-md text-body-lg md:text-headline-md text-on-surface">{item.name}</h3>
            <span className="font-headline-md text-body-lg md:text-headline-md text-gold-muted">
              {formatINR(item.price * item.qty)}
            </span>
          </div>
          <p className="font-label-caps text-label-caps text-on-surface-variant mb-sm">
            {[item.size, item.color].filter(Boolean).join(" | ")}
          </p>
        </div>
        <div className="flex justify-between items-center mt-auto">
          <div className="flex items-center bg-surface-container rounded-DEFAULT border-[0.5px] border-outline/30">
            <button
              className="px-sm py-xs text-on-surface-variant hover:text-primary transition-colors"
              onClick={() => setQty(item, item.qty - 1)}
            >
              <span className="material-symbols-outlined text-sm">remove</span>
            </button>
            <span className="font-body-md text-on-surface px-sm w-8 text-center">{item.qty}</span>
            <button
              className="px-sm py-xs text-on-surface-variant hover:text-primary transition-colors"
              onClick={() => setQty(item, item.qty + 1)}
            >
              <span className="material-symbols-outlined text-sm">add</span>
            </button>
          </div>
          <button
            className="text-on-surface-variant hover:text-error transition-colors flex items-center gap-xs font-label-caps text-label-caps"
            onClick={() => removeItem(item)}
          >
            <span className="material-symbols-outlined text-sm">delete</span>
            <span className="hidden sm:inline">Remove</span>
          </button>
        </div>
      </div>
    </div>
  );
}
