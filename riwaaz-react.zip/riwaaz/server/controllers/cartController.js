const Cart = require("../models/Cart");
const Product = require("../models/Product");
const HttpError = require("../utils/httpError");
const asyncHandler = require("../utils/asyncHandler");

const MAX_QTY = 99;
const s = (v) => (typeof v === "string" ? v.slice(0, 40) : "");
const same = (a, b) => a.productId === b.productId && (a.size || "") === (b.size || "") && (a.color || "") === (b.color || "");

async function getCart(userId) {
  return (await Cart.findOne({ user: userId })) || new Cart({ user: userId, items: [] });
}

// Prices/names/images always come from the products collection, never from the client.
async function hydrate(cart) {
  const products = await Product.find({ productId: { $in: cart.items.map((i) => i.productId) } });
  const byId = new Map(products.map((p) => [p.productId, p]));
  return cart.items
    .filter((i) => byId.has(i.productId))
    .map((i) => {
      const p = byId.get(i.productId);
      return { id: i.productId, name: p.name, price: p.price, image: p.image, size: i.size, color: i.color, qty: i.qty };
    });
}

async function respond(res, cart) {
  res.json({ items: await hydrate(cart) });
}

function parseLine(src) {
  const productId = typeof src.productId === "string" ? src.productId : "";
  const qty = Number.parseInt(src.qty, 10);
  return { productId, size: s(src.size), color: s(src.color), qty: Number.isFinite(qty) ? qty : 1 };
}

exports.get = asyncHandler(async (req, res) => respond(res, await getCart(req.user._id)));

exports.addItem = asyncHandler(async (req, res) => {
  const line = parseLine(req.body || {});
  if (line.qty < 1 || line.qty > MAX_QTY) throw new HttpError(400, "Invalid quantity.");
  if (!(await Product.exists({ productId: line.productId }))) throw new HttpError(404, "That product is not available.");

  const cart = await getCart(req.user._id);
  const existing = cart.items.find((i) => same(i, line));
  if (existing) existing.qty = Math.min(MAX_QTY, existing.qty + line.qty);
  else cart.items.push(line);
  await cart.save();
  await respond(res, cart);
});

exports.setQty = asyncHandler(async (req, res) => {
  const line = parseLine(req.body || {});
  const cart = await getCart(req.user._id);
  const idx = cart.items.findIndex((i) => same(i, line));
  if (idx === -1) throw new HttpError(404, "Item not in your bag.");
  if (line.qty < 1) cart.items.splice(idx, 1);
  else cart.items[idx].qty = Math.min(MAX_QTY, line.qty);
  await cart.save();
  await respond(res, cart);
});

exports.removeItem = asyncHandler(async (req, res) => {
  const line = parseLine(req.query || {});
  const cart = await getCart(req.user._id);
  cart.items = cart.items.filter((i) => !same(i, line));
  await cart.save();
  await respond(res, cart);
});

// Called right after login to fold in whatever a guest had in localStorage.
exports.merge = asyncHandler(async (req, res) => {
  const incoming = Array.isArray(req.body?.items) ? req.body.items.slice(0, 100) : [];
  const cart = await getCart(req.user._id);
  for (const raw of incoming) {
    const line = parseLine({ productId: raw?.id, size: raw?.size, color: raw?.color, qty: raw?.qty });
    if (line.qty < 1 || line.qty > MAX_QTY) continue;
    if (!(await Product.exists({ productId: line.productId }))) continue;
    const existing = cart.items.find((i) => same(i, line));
    if (existing) existing.qty = Math.min(MAX_QTY, existing.qty + line.qty);
    else cart.items.push(line);
  }
  await cart.save();
  await respond(res, cart);
});
