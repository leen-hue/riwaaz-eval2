const { EventEmitter } = require("events");

// App-wide event bus (Node's EventEmitter). Controllers emit, listeners react.
module.exports = new EventEmitter();
