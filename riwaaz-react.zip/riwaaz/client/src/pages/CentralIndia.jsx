import { PRODUCTS } from "../data/products";
import { useShop } from "../context/ShopContext";
import { formatINR, wishClass } from "../utils/format";

export const meta = { page: "central-india", route: "/central-india", title: "The Central India Edit - RIWAAZ", bodyClass: "antialiased min-h-screen flex flex-col font-body-md text-body-md bg-gradient-to-br from-deep-maroon via-background to-on-primary-container bg-fixed" };

export default function CentralIndia() {
  const { addToBag, toggleWishlist, isSaved } = useShop();
  return (
    <>
      <main className="flex-grow w-full max-w-[1920px] mx-auto">
        <section className="relative w-full h-[614px] md:h-[716px] flex items-center justify-center border-b-[0.5px] border-outline/30 mb-xl">
          <div className="absolute inset-0 w-full h-full">
            <div className="w-full h-full bg-cover bg-center absolute inset-0 opacity-40" data-alt="A cinematic, wide-angle shot of a majestic Central Indian palace courtyard at twilight, imbued with a luxurious dark-mode aesthetic. High-contrast lighting highlights intricate stone carvings and rich, dark silken fabrics draped elegantly. The color palette features deep blacks, velvety maroons, and striking gold metallic accents, creating an atmosphere of heritage opulence and grandeur." style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuC3ZWAgONlb4JFXforfEfFFGJUx6fjXsFkMFnzmSEOX8c_cRFiWfzlvy_L19bcpErJwKnGA-SsthiIJ1aLF7zM95lNL211SAdngkNz6Gz14Yz8LyA-kpiWptAKPOulxcXtVH5SzSjhZ8rt3MfnGfATCcWVjBzR-ZU_EdH-r4-FulwR-HiBro37aTMn5qqHkvGuNnTgk8U0LJv9nRMjwonmgjJJBcqRUz_l_HsNOcMo-DO_-SGgamkDXmw')"}}></div>
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-deep-maroon/40 to-transparent"></div>
          </div>
          <div className="relative z-10 text-center px-margin-mobile md:px-margin-desktop max-w-4xl mx-auto flex flex-col items-center">
            <span className="font-label-caps text-label-caps text-gold-muted mb-md tracking-[0.2em]">
              CURATED COLLECTION
            </span>
            <h1 className="font-display-lg text-headline-lg-mobile md:text-display-lg text-primary mb-md gold-gradient-text">
              The Central India Edit
            </h1>
            <p className="font-body-lg text-body-lg text-on-surface-variant max-w-2xl mx-auto">
              A celebration of architectural grandeur and masterful weaving. Discover the sheer elegance of Chanderi silks and the rich heritage of Maheshwari weaves, bringing Central India's royal legacy to the modern dark-mode aesthetic.
            </p>
          </div>
        </section>
        <div className="px-margin-mobile md:px-margin-desktop grid grid-cols-1 md:grid-cols-12 gap-gutter md:gap-xl pb-xl">
          <aside className="md:col-span-3 lg:col-span-2 hidden md:flex flex-col gap-xl border-r-[0.5px] border-outline/20 pr-md">
            <div>
              <h3 className="font-headline-md text-body-lg text-primary mb-sm border-b-[0.5px] border-outline/30 pb-xs">
                Categories
              </h3>
              <ul className="flex flex-col gap-base mt-sm">
                <li className="">
                  <a className="font-body-md text-body-md text-on-surface-variant hover:text-gold-tint transition-colors flex items-center justify-between" href="#">
                    Chanderi Sarees 
                    <span className="text-surface-variant text-sm">
                      24
                    </span>
                  </a>
                </li>
                <li className="">
                  <a className="font-body-md text-body-md text-primary font-bold hover:text-gold-tint transition-colors flex items-center justify-between" href="#">
                    Maheshwari Silks 
                    <span className="text-surface-variant text-sm">
                      18
                    </span>
                  </a>
                </li>
                <li className="">
                  <a className="font-body-md text-body-md text-on-surface-variant hover:text-gold-tint transition-colors flex items-center justify-between" href="#">
                    Lehengas 
                    <span className="text-surface-variant text-sm">
                      12
                    </span>
                  </a>
                </li>
                <li className="">
                  <a className="font-body-md text-body-md text-on-surface-variant hover:text-gold-tint transition-colors flex items-center justify-between" href="#">
                    Anarkalis 
                    <span className="text-surface-variant text-sm">
                      30
                    </span>
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-headline-md text-body-lg text-primary mb-sm border-b-[0.5px] border-outline/30 pb-xs">
                Price
              </h3>
              <div className="mt-sm space-y-sm">
                <label className="flex items-center gap-sm cursor-pointer group">
                  <input className="form-checkbox bg-surface border-outline text-gold-muted focus:ring-gold-muted focus:ring-offset-background rounded-sm" type="checkbox" />
                  <span className="font-body-md text-body-md text-on-surface-variant group-hover:text-gold-tint transition-colors">
                    Under ₹50,000
                  </span>
                </label>
                <label className="flex items-center gap-sm cursor-pointer group">
                  <input defaultChecked className="form-checkbox bg-surface border-outline text-gold-muted focus:ring-gold-muted focus:ring-offset-background rounded-sm" type="checkbox" />
                  <span className="font-body-md text-body-md text-primary group-hover:text-gold-tint transition-colors">
                    ₹50,000 - ₹1,00,000
                  </span>
                </label>
                <label className="flex items-center gap-sm cursor-pointer group">
                  <input className="form-checkbox bg-surface border-outline text-gold-muted focus:ring-gold-muted focus:ring-offset-background rounded-sm" type="checkbox" />
                  <span className="font-body-md text-body-md text-on-surface-variant group-hover:text-gold-tint transition-colors">
                    Above ₹1,00,000
                  </span>
                </label>
              </div>
            </div>
            <div>
              <h3 className="font-headline-md text-body-lg text-primary mb-sm border-b-[0.5px] border-outline/30 pb-xs">
                Colors
              </h3>
              <div className="flex flex-wrap gap-base mt-sm">
                <button className="w-6 h-6 rounded-full bg-deep-maroon border border-outline/50 ring-2 ring-primary ring-offset-2 ring-offset-background"></button>
                <button className="w-6 h-6 rounded-full bg-primary-container border border-outline/50"></button>
                <button className="w-6 h-6 rounded-full bg-surface-container-highest border border-outline/50"></button>
                <button className="w-6 h-6 rounded-full bg-emerald-on-surface border border-outline/50"></button>
                <button className="w-6 h-6 rounded-full bg-on-secondary border border-outline/50"></button>
              </div>
            </div>
          </aside>
          <div className="md:col-span-9 lg:col-span-10 flex flex-col gap-md">
            <div className="flex justify-between items-center py-base border-b-[0.5px] border-outline/20 mb-md">
              <span className="font-body-md text-body-md text-on-surface-variant">
                Showing 84 Products
              </span>
              <div className="flex items-center gap-md">
                <button className="md:hidden flex items-center gap-xs font-label-caps text-label-caps text-primary uppercase">
                  <span className="material-symbols-outlined text-sm">
                    tune
                  </span>
                  Filters
                </button>
                <div className="hidden md:flex items-center gap-sm">
                  <span className="font-body-md text-body-md text-on-surface-variant">
                    Sort by:
                  </span>
                  <select className="bg-transparent border-none text-primary font-body-md focus:ring-0 cursor-pointer px-0 py-0 pr-6">
                    <option className="bg-surface text-on-surface">
                      Recommended
                    </option>
                    <option className="bg-surface text-on-surface">
                      Newest Arrivals
                    </option>
                    <option className="bg-surface text-on-surface">
                      Price: High to Low
                    </option>
                  </select>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-gutter md:gap-md">
              <div className="group relative flex flex-col gap-sm cursor-pointer" data-product data-product-id="midnight-zari-drape" data-product-name="Midnight Zari Drape" data-product-price="68500" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuAEe0VVimUP-WEJQiD0paYqvLJkm4JwTs5z52095v0DsrNc1ev0AujAdBaqEFaDo0d--_muqNN22fVlwXmH-2bc28TQhT4fE7_qoIYpHHV5j3e0KcRTEUVNSjoy7aAZU8Mi76wS7kMRnuLQAiU5jPhrIBvDlV5dXEeIGJChge9JsZeAAsnbBuhuPNlrfa0WfbrJJdGlmC7wPpfkhoPyCJv1CdOcJGJ_Hr6ri0oTg9gTRnvdjyQLXdEGHQ">
                <div className="relative w-full aspect-[3/4] overflow-hidden rounded-sm bg-surface/50 backdrop-blur-sm border-[0.5px] border-outline/10">
                  <img className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" data-alt="A fashion editorial shot of an Indian model wearing a luxurious midnight blue and gold Maheshwari silk saree. The lighting is dramatic and moody, emphasizing the sheer texture and metallic zari work. The background is a deeply shadowed palatial archway, fitting the dark-mode maximalist aesthetic." src="https://lh3.googleusercontent.com/aida-public/AB6AXuAEe0VVimUP-WEJQiD0paYqvLJkm4JwTs5z52095v0DsrNc1ev0AujAdBaqEFaDo0d--_muqNN22fVlwXmH-2bc28TQhT4fE7_qoIYpHHV5j3e0KcRTEUVNSjoy7aAZU8Mi76wS7kMRnuLQAiU5jPhrIBvDlV5dXEeIGJChge9JsZeAAsnbBuhuPNlrfa0WfbrJJdGlmC7wPpfkhoPyCJv1CdOcJGJ_Hr6ri0oTg9gTRnvdjyQLXdEGHQ" />
                  <div className="absolute inset-0 product-card-overlay opacity-80"></div>
                  <button className={wishClass("absolute top-sm right-sm text-surface-variant hover:text-primary transition-colors z-10", isSaved("midnight-zari-drape"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["midnight-zari-drape"]); }}>
                    <span className="material-symbols-outlined">
                      {isSaved("midnight-zari-drape") ? "favorite" : "favorite_border"}
                    </span>
                  </button>
                  <div className="absolute bottom-0 left-0 w-full p-sm z-10 flex flex-col justify-end translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                    <button className="w-full bg-gradient-to-r from-primary-container to-gold-bright text-on-primary font-label-caps text-label-caps py-xs uppercase tracking-widest shadow-[0_0_15px_rgba(212,175,55,0.3)]" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["midnight-zari-drape"]); }}>
                      Quick Add
                    </button>
                  </div>
                </div>
                <div className="flex flex-col">
                  <span className="font-label-caps text-label-caps text-gold-muted mb-xs uppercase">
                    Maheshwari Silk
                  </span>
                  <h4 className="font-headline-md text-body-lg text-on-surface truncate group-hover:text-primary transition-colors">
                    Midnight Zari Drape
                  </h4>
                  <span className="font-body-md text-body-md text-primary mt-xs">
                    ₹ 68,500
                  </span>
                </div>
              </div>
              <div className="group relative flex flex-col gap-sm cursor-pointer" data-product data-product-id="burgundy-royal-lehenga" data-product-name="Burgundy Royal Lehenga" data-product-price="112000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuChnTv5ztNiAX9QNmXfbPNveyoGIm_djMfBpgL933HuTjFO7p83Io60sD6uEsnyXCS6kLsdf5uXtpxQclpchkfnrPM_MVLcQUcazwTajZVA2_xynj3IC2zxkv1219GQh3bjZsr1sLvY78edlhaIPUd9SJxHK4Lm-T4JS2xu6rqXmVVmvkIm3SksP9qyUnDCHRVB7DnYXy0xOuAxRnR5omqY2af8LJbCwd7tJjeeTBox39vjSrAtHpmTOg">
                <div className="relative w-full aspect-[3/4] overflow-hidden rounded-sm bg-surface/50 backdrop-blur-sm border-[0.5px] border-outline/10">
                  <img className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" data-alt="Close up photography of a rich burgundy Chanderi silk lehenga with intricate golden embroidery. The fabric has a subtle sheen, illuminated by soft, focused light against a pitch-black background, highlighting the tactile maximalist luxury and craftsmanship." src="https://lh3.googleusercontent.com/aida-public/AB6AXuChnTv5ztNiAX9QNmXfbPNveyoGIm_djMfBpgL933HuTjFO7p83Io60sD6uEsnyXCS6kLsdf5uXtpxQclpchkfnrPM_MVLcQUcazwTajZVA2_xynj3IC2zxkv1219GQh3bjZsr1sLvY78edlhaIPUd9SJxHK4Lm-T4JS2xu6rqXmVVmvkIm3SksP9qyUnDCHRVB7DnYXy0xOuAxRnR5omqY2af8LJbCwd7tJjeeTBox39vjSrAtHpmTOg" />
                  <div className="absolute inset-0 product-card-overlay opacity-80"></div>
                  <button className={wishClass("absolute top-sm right-sm text-surface-variant hover:text-primary transition-colors z-10", isSaved("burgundy-royal-lehenga"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["burgundy-royal-lehenga"]); }}>
                    <span className="material-symbols-outlined">
                      {isSaved("burgundy-royal-lehenga") ? "favorite" : "favorite_border"}
                    </span>
                  </button>
                  <div className="absolute bottom-0 left-0 w-full p-sm z-10 flex flex-col justify-end translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                    <button className="w-full bg-gradient-to-r from-primary-container to-gold-bright text-on-primary font-label-caps text-label-caps py-xs uppercase tracking-widest shadow-[0_0_15px_rgba(212,175,55,0.3)]" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["burgundy-royal-lehenga"]); }}>
                      Quick Add
                    </button>
                  </div>
                </div>
                <div className="flex flex-col">
                  <span className="font-label-caps text-label-caps text-gold-muted mb-xs uppercase">
                    Chanderi Brocade
                  </span>
                  <h4 className="font-headline-md text-body-lg text-on-surface truncate group-hover:text-primary transition-colors">
                    Burgundy Royal Lehenga
                  </h4>
                  <span className="font-body-md text-body-md text-primary mt-xs">
                    ₹ 1,12,000
                  </span>
                </div>
              </div>
              <div className="group relative flex flex-col gap-sm cursor-pointer" data-product data-product-id="onyx-gilded-sherwani" data-product-name="Onyx Gilded Sherwani" data-product-price="85000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuB20HOQVed1-ec88TU0zdIVFSDxqyjTVOUllbBRW3UwuuLFPMqP6Br_-sXCM73Pl5cp1UgUzatFIbIEC6uSUDm42DDFHYcgVDTZP_JWWHnwk6XdZAG5zm6MbK2D-YzE2wYscIXHZ1-GfwTIP7nZ4vtrd11fsfwXotK1C_QSKKY9kZBkAQ4s3vxxunu8j0xmO6Avq4SqorSDP7edXtT7HLzYEKGlVKAw2-Wc4PoZp48XaBuyEgkMKM0yJw">
                <div className="relative w-full aspect-[3/4] overflow-hidden rounded-sm bg-surface/50 backdrop-blur-sm border-[0.5px] border-outline/10">
                  <img className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" data-alt="A male model adorned in a stark black and gold embroidered sherwani, representing Central Indian regal attire. The image is styled in a high-contrast dark mode palette, with sharp lighting defining the intricate gold threadwork against the deep black fabric." src="https://lh3.googleusercontent.com/aida-public/AB6AXuB20HOQVed1-ec88TU0zdIVFSDxqyjTVOUllbBRW3UwuuLFPMqP6Br_-sXCM73Pl5cp1UgUzatFIbIEC6uSUDm42DDFHYcgVDTZP_JWWHnwk6XdZAG5zm6MbK2D-YzE2wYscIXHZ1-GfwTIP7nZ4vtrd11fsfwXotK1C_QSKKY9kZBkAQ4s3vxxunu8j0xmO6Avq4SqorSDP7edXtT7HLzYEKGlVKAw2-Wc4PoZp48XaBuyEgkMKM0yJw" />
                  <div className="absolute inset-0 product-card-overlay opacity-80"></div>
                  <button className={wishClass("absolute top-sm right-sm text-surface-variant hover:text-primary transition-colors z-10", isSaved("onyx-gilded-sherwani"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["onyx-gilded-sherwani"]); }}>
                    <span className="material-symbols-outlined">
                      {isSaved("onyx-gilded-sherwani") ? "favorite" : "favorite_border"}
                    </span>
                  </button>
                  <div className="absolute bottom-0 left-0 w-full p-sm z-10 flex flex-col justify-end translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                    <button className="w-full bg-gradient-to-r from-primary-container to-gold-bright text-on-primary font-label-caps text-label-caps py-xs uppercase tracking-widest shadow-[0_0_15px_rgba(212,175,55,0.3)]" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["onyx-gilded-sherwani"]); }}>
                      Quick Add
                    </button>
                  </div>
                </div>
                <div className="flex flex-col">
                  <span className="font-label-caps text-label-caps text-gold-muted mb-xs uppercase">
                    Heritage Menswear
                  </span>
                  <h4 className="font-headline-md text-body-lg text-on-surface truncate group-hover:text-primary transition-colors">
                    Onyx Gilded Sherwani
                  </h4>
                  <span className="font-body-md text-body-md text-primary mt-xs">
                    ₹ 85,000
                  </span>
                </div>
              </div>
              <div className="group relative flex flex-col gap-sm cursor-pointer" data-product data-product-id="emerald-zari-anarkali" data-product-name="Emerald Zari Anarkali" data-product-price="54000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuAjVBLirx1EAqxvipivxqHWc-qU7LR5kwn9gY27pbXwReovKB9STKRm7RO8OUzuI7raXi0Lys2E-gayLAHLYcba6goJ91cmP_vuJI-QQYAelNpdN2VGwHYbz1UDq3M4t9Xdm2Kfx3gzFrbU6G7B5UsHPuyTFF609kv-keyxYsOK3YZx5rbv1iaEsuNUcgqb5DkNJHNsued_A_t_tvmGVrE1znngmzcV4Ia0w_CkBUeHO4zGr3iv9lTiiQ">
                <div className="relative w-full aspect-[3/4] overflow-hidden rounded-sm bg-surface/50 backdrop-blur-sm border-[0.5px] border-outline/10">
                  <img className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" data-alt="An elegant deep emerald green Anarkali suit featuring delicate gold zari borders. The garment is draped beautifully, lit by a soft spotlight that creates rich shadows, perfect for a premium luxury fashion catalog in a dark aesthetic." src="https://lh3.googleusercontent.com/aida-public/AB6AXuAjVBLirx1EAqxvipivxqHWc-qU7LR5kwn9gY27pbXwReovKB9STKRm7RO8OUzuI7raXi0Lys2E-gayLAHLYcba6goJ91cmP_vuJI-QQYAelNpdN2VGwHYbz1UDq3M4t9Xdm2Kfx3gzFrbU6G7B5UsHPuyTFF609kv-keyxYsOK3YZx5rbv1iaEsuNUcgqb5DkNJHNsued_A_t_tvmGVrE1znngmzcV4Ia0w_CkBUeHO4zGr3iv9lTiiQ" />
                  <div className="absolute inset-0 product-card-overlay opacity-80"></div>
                  <button className={wishClass("absolute top-sm right-sm text-surface-variant hover:text-primary transition-colors z-10", isSaved("emerald-zari-anarkali"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["emerald-zari-anarkali"]); }}>
                    <span className="material-symbols-outlined">
                      {isSaved("emerald-zari-anarkali") ? "favorite" : "favorite_border"}
                    </span>
                  </button>
                  <div className="absolute bottom-0 left-0 w-full p-sm z-10 flex flex-col justify-end translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                    <button className="w-full bg-gradient-to-r from-primary-container to-gold-bright text-on-primary font-label-caps text-label-caps py-xs uppercase tracking-widest shadow-[0_0_15px_rgba(212,175,55,0.3)]" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["emerald-zari-anarkali"]); }}>
                      Quick Add
                    </button>
                  </div>
                </div>
                <div className="flex flex-col">
                  <span className="font-label-caps text-label-caps text-gold-muted mb-xs uppercase">
                    Chanderi Blend
                  </span>
                  <h4 className="font-headline-md text-body-lg text-on-surface truncate group-hover:text-primary transition-colors">
                    Emerald Zari Anarkali
                  </h4>
                  <span className="font-body-md text-body-md text-primary mt-xs">
                    ₹ 54,000
                  </span>
                </div>
              </div>
            </div>
            <div className="flex justify-center mt-xl">
              <button className="border-[0.5px] border-outline text-primary font-label-caps text-label-caps py-sm px-xl uppercase tracking-widest hover:bg-surface-container-high transition-colors">
                Load More
              </button>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
