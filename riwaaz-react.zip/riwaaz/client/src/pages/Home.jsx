import { Link } from "react-router-dom";
import { PRODUCTS } from "../data/products";
import { useShop } from "../context/ShopContext";
import { formatINR, wishClass } from "../utils/format";

export const meta = { page: "home", route: "/", title: "RIWAAZ Luxury Ethnic", bodyClass: "antialiased selection:bg-primary-container selection:text-on-primary-container" };

export default function Home() {
  const { addToBag, toggleWishlist, isSaved } = useShop();
  return (
    <>
      <main className="max-w-[1920px] mx-auto overflow-hidden">
        <section className="relative w-full h-[819px] min-h-[600px] bg-gradient-to-br from-deep-maroon via-surface-container to-gold-muted/20 flex items-center justify-center border-b-[0.5px] border-primary/20">
          <div className="absolute inset-0 z-0">
            <img className="w-full h-full object-cover object-center opacity-60 mix-blend-overlay" data-alt="A sweeping, cinematic ultra-wide shot of a grand Indian palatial courtyard at twilight. A model in an opulent, heavily embroidered dark maroon and gold South Asian bridal lehenga stands regally. High-contrast lighting highlights the metallic threadwork against the dark, mysterious background. The atmosphere is palatial luxury, maximalist, and deeply rooted in heritage. Tactile textures and deep shadows." src="https://lh3.googleusercontent.com/aida-public/AB6AXuCHtaUwVrhBHUKpXscx1Tzg7Rrxk-6Lp-4YUMXVRRZZHq2QXSXfyO6IHGGDiv2HaYt1MgxceWZI4UmqbPNinWcvvjtfC1otCLo3uZ1pAi1YbuN2P8o-9Tz2-krhGvM1gMl-E7YZRUcka5yYyhOOXDcu4uR740LQi1Otg6-dB3wVdNZX1H8jnFKqt_sSO9sKyQGT8z4dYmO91Bkdjb7v0c_pvMqik4gfnDmJGisJomFLi066I4aazqKUHQ" />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-deep-maroon/60 to-transparent"></div>
          </div>
          <div className="relative z-10 text-center px-margin-desktop flex flex-col items-center">
            <p className="font-label-caps text-label-caps text-gold-muted mb-sm tracking-[0.2em]">
              The Fall Winter Collection
            </p>
            <h1 className="font-display-lg text-display-lg text-primary mb-md text-glow">
              HERITAGE REVIVED
            </h1>
            <p className="font-body-lg text-body-lg text-on-surface max-w-2xl mb-lg">
              A maximalist exploration of ancestral craftsmanship, woven with dark romance and golden threads.
            </p>
            <button className="gold-gradient-bg text-on-primary font-label-caps text-label-caps px-xl py-sm rounded-none border border-primary-container box-glow hover:scale-105 transition-transform duration-300">
              EXPLORE COLLECTION
            </button>
          </div>
        </section>
        <section className="py-xl px-margin-desktop border-b-[0.5px] border-outline/30 bg-gradient-to-r from-surface via-surface-container to-deep-maroon/20">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-gutter">
            <Link className="group relative h-48 overflow-hidden bg-surface-container rounded-sm border border-outline/20 hover:border-primary/50 transition-colors" to="/north-indian">
              <img className="absolute inset-0 w-full h-full object-cover opacity-50 group-hover:opacity-70 transition-opacity duration-500 group-hover:scale-105" data-alt="Close-up of intricate zari and zardosi embroidery on a deep emerald green silk fabric. Luxurious texture, golden threads catching the light. Dark mode aesthetic, rich jewel tones, highly detailed macro photography." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDvKjnOARS3ve0JTWbWEGCr_9THInps7rSCEVaDXxTYikXPE329MFSsEa3A9B6OsuO3x0_d6rOF05nGA8Fp9N3_dnGQT1lKRprINH3FELbWb7aPgsr_HdNNm5Ktt0ZTkS9SzQrFkLp0jOAk6KWZT9ZoNWMqVR76Lhu3wgPNZ1_u7M0vkkU0FkyvvHNkf93H3G100v5qlgreiuZ0ViTC8pO8cY98EX7-wSlaoIyoOyyiTK1AbeDp-HFDXg" />
              <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent flex items-end p-md">
                <h3 className="font-headline-md text-headline-md text-primary">
                  North Indian
                </h3>
              </div>
            </Link>
            <Link className="group relative h-48 overflow-hidden bg-surface-container rounded-sm border border-outline/20 hover:border-primary/50 transition-colors" to="/south-indian">
              <img className="absolute inset-0 w-full h-full object-cover opacity-50 group-hover:opacity-70 transition-opacity duration-500 group-hover:scale-105" data-alt="Close-up of traditional Kanjeevaram silk saree pleats in a rich crimson red with heavy pure gold zari border. The fabric folds elegantly in low, dramatic lighting. Opulent, tactile maximalism, dark mysterious background." src="https://lh3.googleusercontent.com/aida-public/AB6AXuB3drAHLgcwTaHiA593Kv-cTqKfZskiB84T-6e_ilaq2AG7w-D-fpClFBX1B9_rGQlJytyZqOCLeqYEHgwEEnj9LSWN7HZZ3kvP2A4hZHL2bWSCfF7kMSjpJgmP3ixxObNarioTnNXKiw1zq0e2LO1sIlB_v1ONdyW13ITGF-cJLb2fQmFFDbmgijR3j5cHhHCEMCDZgQkOgTG3ptxNAo0AWUsBZ_S24C8pWj6VIDMS2KGUGSUHZ4gZBg" />
              <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent flex items-end p-md">
                <h3 className="font-headline-md text-headline-md text-primary">
                  South Indian
                </h3>
              </div>
            </Link>
            <Link className="group relative h-48 overflow-hidden bg-surface-container rounded-sm border border-outline/20 hover:border-primary/50 transition-colors" to="/central-india">
              <img className="absolute inset-0 w-full h-full object-cover opacity-50 group-hover:opacity-70 transition-opacity duration-500 group-hover:scale-105" data-alt="Detail shot of heavy bridal jewelry, including an elaborate Kundan necklace and maang tikka, resting on dark velvet. Gleaming gold, uncut diamonds, and deep ruby accents. Dramatic spotlighting, luxurious, high-contrast dark mode." src="https://lh3.googleusercontent.com/aida-public/AB6AXuAM1T_jGdf8AlawHVEjYITSkdxXjbVISTFzznfaZ1INIR7K_Qyfc4dotby4jewMCQAFt9XakX5Ilhuk6fqUhwCrvCAxdGhCUVlJiSirRkUlY1Ux0pi7yVNniVg6mtbANqDECBnXQi2PnEmP0RUVCQyOQieajyx_vjz2Z1fgcSwl0TzCLDS9OimpRpe6NQIyq39p152L-JSjfpygwxu4iwivSn3ghW_oZf-HWsGTohGcVScWdTQHkHKwSQ" />
              <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent flex items-end p-md">
                <h3 className="font-headline-md text-headline-md text-primary">
                  Bridal
                </h3>
              </div>
            </Link>
            <Link className="group relative h-48 overflow-hidden bg-surface-container rounded-sm border border-outline/20 hover:border-primary/50 transition-colors" to="/north-eastern">
              <img className="absolute inset-0 w-full h-full object-cover opacity-50 group-hover:opacity-70 transition-opacity duration-500 group-hover:scale-105" data-alt="A modern, avant-garde silhouette featuring a structured South Asian men's sherwani in midnight blue velvet with subtle silver geometric embroidery. High fashion editorial style, moody lighting, dark mode maximalism." src="https://lh3.googleusercontent.com/aida-public/AB6AXuC9t4glzGdw37O-zDypwYfvmfXphZir_pylwxtbjRrR0cMj1WqPtGn2nXggH0evRMvA9Y6EhlP2F2PJ0-XgaNTH_Cul06Xv6vGu9RrRxS8XhPUM3W_cSrrKnUVeR_YJsk-DKXA3BiDaveHH-ZMH8Q6rB2Bd-07qZq7af9e1MTJHWZ7rQ_qk6X69-LbnxhveR7hG49Rufq8mgf8hKL-45cTm_sKRAXBXV1gPXbS9GWbAyUUVNwsWc5dmIA" />
              <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent flex items-end p-md">
                <h3 className="font-headline-md text-headline-md text-primary">
                  Couture
                </h3>
              </div>
            </Link>
          </div>
        </section>
        <section className="py-xl px-margin-desktop bg-gradient-to-br from-surface-dim via-deep-maroon/30 to-gold-muted/10">
          <div className="flex justify-between items-end mb-lg">
            <h2 className="font-display-lg text-display-lg text-primary">
              Trending Collections
            </h2>
            <a className="font-label-caps text-label-caps text-gold-muted hover:text-primary transition-colors flex items-center gap-xs" href="#">
              VIEW ALL 
              <span className="material-symbols-outlined text-[16px]">
                arrow_forward
              </span>
            </a>
          </div>
          <div className="grid grid-cols-12 gap-gutter h-[600px]">
            <div className="col-span-8 relative group overflow-hidden border border-outline/20">
              <img className="absolute inset-0 w-full h-full object-cover opacity-70 group-hover:scale-105 transition-transform duration-700" data-alt="A sprawling, elegant setup featuring an array of regal anarkali suits in varying shades of deep plum and charcoal. Intricate gota patti work shimmers. The setting is a dimly lit, grand room with arched doorways. High-end fashion editorial photography." src="https://lh3.googleusercontent.com/aida-public/AB6AXuC_OofFVlYuK3W2VXmE4CsmzzhxanCOZkB6Q1am1E63TB3ET_-T2A6gRyZhL6iwmaPSvx5hJ_J1HRRh-dKK6hGqJXmqy8iJ24_4o9fJI-ZI1YyQx41FETl_h_ecb6Zpjcg4oJ4gxf_wEGtbDNs_C-SoL9i7zO07JXZAg8zYUBF-eEKaD0GpsBPI9Y-EfsZLFuBA_cdGZ-PuNV6rsevU8i_KtH8aAnzK1cHd2fLcng9divVPvlkdVpYMIA" />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent"></div>
              <div className="absolute bottom-0 left-0 p-lg">
                <span className="font-label-caps text-label-caps text-gold-tint bg-background/50 backdrop-blur-sm px-sm py-xs border border-primary/30 mb-sm inline-block">
                  FEATURED STORY
                </span>
                <h3 className="font-headline-lg text-headline-lg text-on-background mb-xs">
                  The Royal Anarkali
                </h3>
                <p className="font-body-md text-body-md text-on-surface-variant max-w-md">
                  Sweeping silhouettes adorned with hand-stitched zardozi.
                </p>
              </div>
            </div>
            <div className="col-span-4 flex flex-col gap-gutter">
              <div className="flex-1 relative group overflow-hidden border border-outline/20">
                <img className="absolute inset-0 w-full h-full object-cover opacity-70 group-hover:scale-105 transition-transform duration-700" data-alt="A striking portrait of a model wearing heavy polki jewelry and a minimalist yet rich velvet dark green dupatta. Focus on the textures of the velvet and the gleam of the uncut diamonds. Moody, dark aesthetic." src="https://lh3.googleusercontent.com/aida-public/AB6AXuA4rAhCC29t9ddsz3TMQ5Hz6kpnT4DDwdWT7NFYRYot-WZ8mClNSBsdIuCIlZalHrZ66fbM1k-69hwHpI8MuuqBO71eJwEPypXdGgrW6A2DHIr9T-_htz5IiHEz43dHholiuAWWVrIWW81HbAw0c7Xkj1kMgODpmQ6FrK28du46YO1LBxZJYqZdqzb1OYg4UW4AvPpHfNnV5rX4dcycLGpclcj2r-12SrqX4gw21P5vM0MqHd72JwB3rg" />
                <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-md">
                  <h4 className="font-headline-md text-headline-md text-on-background">
                    Velvet & Polki
                  </h4>
                </div>
              </div>
              <div className="flex-1 relative group overflow-hidden border border-outline/20">
                <img className="absolute inset-0 w-full h-full object-cover opacity-70 group-hover:scale-105 transition-transform duration-700" data-alt="Detail of a man's hand-embroidered raw silk bandhgala jacket in deep burgundy. The embroidery features subtle geometric metallic accents. Luxurious, sophisticated, dark mode." src="https://lh3.googleusercontent.com/aida-public/AB6AXuAwZlbeuw6NbDiQ56Z4h0kqJiOExeTCv3kCtom-eApG8F5-Z82A88roDBmLezJvWHCgKE2otmDh5m1uBHJhX9f5V5ZAiB1cZ_f9m576fpduOBRJM5aDJ_jdJLAWWSkgMG8oYlNTeYg6Hgy27tKtRxINbAHmc56FgHJ84UU2OEny-7Utd5YwBlS0n9HdXJqNGmq7BBHWmUU-g8hiOd53rqw_PXJxWHwou-Jjh_OmlDXN2XCdmxg7YO41vw" />
                <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-md">
                  <h4 className="font-headline-md text-headline-md text-on-background">
                    Menswear Edit
                  </h4>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section className="py-xl px-margin-desktop border-t-[0.5px] border-outline/30 bg-gradient-to-bl from-surface-container via-background to-primary/10">
          <div className="flex justify-between items-center mb-lg">
            <h2 className="font-headline-lg text-headline-lg text-primary">
              New Arrivals
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-gutter">
            <div className="group flex flex-col gap-sm" data-product data-product-id="midnight-zardozi-lehenga" data-product-name="Midnight Zardozi Lehenga" data-product-price="145000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuBJeLott6rSqWja7Ekbm24EWLrViE5F1jdg4xIpPMKd4BJxqKfqFlNiC6zVHbfahqwgR1nPDLwXQzxXr6eYMpCpAHQrCsnGDwGZRLu5yv6-lLDCEHuRPvumm2PRn3SrSTiC2mGT2tkAw03l3JOndqOgMJxXBOXA-3ksH0PpKD-zvvBZ_Wqyx95pOwmIOMKTGw1aTXD8xOQT8YiKzcl2oRWjONNUj_aDjskwgu6mq_Nz2zpcr7V15jocnA">
              <div className="relative aspect-[3/4] overflow-hidden bg-surface-container border border-outline/20 group-hover:border-primary/50 transition-colors">
                <img className="absolute inset-0 w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-500" data-alt="Full length shot of a heavy bridal lehenga in midnight blue with extensive silver and gold embroidery. The model stands against a dark, textured wall. The fabric is rich silk. The lighting is dramatic and focused on the intricate details." src="https://lh3.googleusercontent.com/aida-public/AB6AXuBJeLott6rSqWja7Ekbm24EWLrViE5F1jdg4xIpPMKd4BJxqKfqFlNiC6zVHbfahqwgR1nPDLwXQzxXr6eYMpCpAHQrCsnGDwGZRLu5yv6-lLDCEHuRPvumm2PRn3SrSTiC2mGT2tkAw03l3JOndqOgMJxXBOXA-3ksH0PpKD-zvvBZ_Wqyx95pOwmIOMKTGw1aTXD8xOQT8YiKzcl2oRWjONNUj_aDjskwgu6mq_Nz2zpcr7V15jocnA" />
                <button className={wishClass("absolute top-sm right-sm p-sm bg-background/50 backdrop-blur-md rounded-full text-on-surface-variant hover:text-primary transition-colors border border-outline/30", isSaved("midnight-zardozi-lehenga"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["midnight-zardozi-lehenga"]); }}>
                  <span className="material-symbols-outlined text-[20px]">
                    {isSaved("midnight-zardozi-lehenga") ? "favorite" : "favorite_border"}
                  </span>
                </button>
              </div>
              <div className="flex justify-between items-start pt-xs">
                <div>
                  <h3 className="font-body-lg text-body-lg text-on-background group-hover:text-primary transition-colors">
                    Midnight Zardozi Lehenga
                  </h3>
                  <p className="font-body-md text-body-md text-on-surface-variant">
                    ₹1,45,000
                  </p>
                </div>
                <button className="gold-gradient-bg text-on-primary p-sm border border-primary-container hover:scale-105 transition-transform shadow-sm" aria-label="Add to bag" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["midnight-zardozi-lehenga"]); }}>
                  <span className="material-symbols-outlined text-[20px]">
                    shopping_bag
                  </span>
                </button>
              </div>
            </div>
            <div className="group flex flex-col gap-sm" data-product data-product-id="crimson-royal-sherwani" data-product-name="Crimson Royal Sherwani" data-product-price="85000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuBOsjcj3cXee10bGBy4VgQUcWeUDOMh0qLImL8467vP43AtIS1ZfJghkg-Uw5HVItlhYelUugc1dBp40kl0Tbse9nskLkFcWLf-f9tOB7jmeWRDjZuDx3918Un6PmKWqA45QqUe2OAokPU2pWaciv9x_-VAcKrXzdao4Kqk0eaz899RLnMcVvOb66GIWcHhT8MSMyh3rDau_N_vwk6jWbwSh1Ps7_wgqHYNznWYE95T7ACrdETgOGD5zg">
              <div className="relative aspect-[3/4] overflow-hidden bg-surface-container border border-outline/20 group-hover:border-primary/50 transition-colors">
                <img className="absolute inset-0 w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-500" data-alt="A regal maroon silk sherwani for men, heavily embroidered with gold thread motifs. The garment is styled on a form with a dark, moody background. Tactile fabrics, opulent maximalism." src="https://lh3.googleusercontent.com/aida-public/AB6AXuBOsjcj3cXee10bGBy4VgQUcWeUDOMh0qLImL8467vP43AtIS1ZfJghkg-Uw5HVItlhYelUugc1dBp40kl0Tbse9nskLkFcWLf-f9tOB7jmeWRDjZuDx3918Un6PmKWqA45QqUe2OAokPU2pWaciv9x_-VAcKrXzdao4Kqk0eaz899RLnMcVvOb66GIWcHhT8MSMyh3rDau_N_vwk6jWbwSh1Ps7_wgqHYNznWYE95T7ACrdETgOGD5zg" />
                <button className={wishClass("absolute top-sm right-sm p-sm bg-background/50 backdrop-blur-md rounded-full text-on-surface-variant hover:text-primary transition-colors border border-outline/30", isSaved("crimson-royal-sherwani"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["crimson-royal-sherwani"]); }}>
                  <span className="material-symbols-outlined text-[20px]">
                    {isSaved("crimson-royal-sherwani") ? "favorite" : "favorite_border"}
                  </span>
                </button>
              </div>
              <div className="flex justify-between items-start pt-xs">
                <div>
                  <h3 className="font-body-lg text-body-lg text-on-background group-hover:text-primary transition-colors">
                    Crimson Royal Sherwani
                  </h3>
                  <p className="font-body-md text-body-md text-on-surface-variant">
                    ₹85,000
                  </p>
                </div>
                <button className="gold-gradient-bg text-on-primary p-sm border border-primary-container hover:scale-105 transition-transform shadow-sm" aria-label="Add to bag" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["crimson-royal-sherwani"]); }}>
                  <span className="material-symbols-outlined text-[20px]">
                    shopping_bag
                  </span>
                </button>
              </div>
            </div>
            <div className="group flex flex-col gap-sm" data-product data-product-id="emerald-organza-drape" data-product-name="Emerald Organza Drape" data-product-price="55000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuAta6YQ1qyYx43flV5pAW5SmMRasSJx0-J3UWFZ9uUvO5tz8AMPWDBgHLWJRSFwdv9e_T_SRHAf8ME_wxd2e7UZLp76bkOgAC5OU2VJj3F84sE1j4KXWrVyTSbdmrld-Sk6sWxp9C1LGcttp_vuVOevYJkqMom2MEknOQ2rsihCFvWBkJ_8glCv5ZNCQbOkOsS1BaFS-Bco1-aLKwr3AkhO_luiDXLVPAweqRlZsQTAD1SO8qyyUHYqoQ">
              <div className="relative aspect-[3/4] overflow-hidden bg-surface-container border border-outline/20 group-hover:border-primary/50 transition-colors">
                <img className="absolute inset-0 w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-500" data-alt="A delicate organza saree in deep emerald green with subtle, scattered gold sequins and a heavy zari border. Elegantly draped. Dark, sophisticated background, highlighting the sheer texture and metallic gleam." src="https://lh3.googleusercontent.com/aida-public/AB6AXuAta6YQ1qyYx43flV5pAW5SmMRasSJx0-J3UWFZ9uUvO5tz8AMPWDBgHLWJRSFwdv9e_T_SRHAf8ME_wxd2e7UZLp76bkOgAC5OU2VJj3F84sE1j4KXWrVyTSbdmrld-Sk6sWxp9C1LGcttp_vuVOevYJkqMom2MEknOQ2rsihCFvWBkJ_8glCv5ZNCQbOkOsS1BaFS-Bco1-aLKwr3AkhO_luiDXLVPAweqRlZsQTAD1SO8qyyUHYqoQ" />
                <button className={wishClass("absolute top-sm right-sm p-sm bg-background/50 backdrop-blur-md rounded-full text-on-surface-variant hover:text-primary transition-colors border border-outline/30", isSaved("emerald-organza-drape"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["emerald-organza-drape"]); }}>
                  <span className="material-symbols-outlined text-[20px]">
                    {isSaved("emerald-organza-drape") ? "favorite" : "favorite_border"}
                  </span>
                </button>
              </div>
              <div className="flex justify-between items-start pt-xs">
                <div>
                  <h3 className="font-body-lg text-body-lg text-on-background group-hover:text-primary transition-colors">
                    Emerald Organza Drape
                  </h3>
                  <p className="font-body-md text-body-md text-on-surface-variant">
                    ₹55,000
                  </p>
                </div>
                <button className="gold-gradient-bg text-on-primary p-sm border border-primary-container hover:scale-105 transition-transform shadow-sm" aria-label="Add to bag" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["emerald-organza-drape"]); }}>
                  <span className="material-symbols-outlined text-[20px]">
                    shopping_bag
                  </span>
                </button>
              </div>
            </div>
            <div className="group flex flex-col gap-sm" data-product data-product-id="heritage-ruby-choker" data-product-name="Heritage Ruby Choker" data-product-price="360000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuCNbd1k5_EdZ-z8frKAjMzdUvWv4tiPN33ukA6_kktT_ioi_NZD-IOCQKE_hYQz7mMY-ofskLeCi58SKt9z-e84xDZ33QwLa1-xG-wf0BI_DDW1gnpiDX0D6qB2qtwbj1FnL2rMz4U1pcXkPQ3aAMc3j7TQCggYlCr--DVU4VS_RYRifYHv6OHM6jA2ju-05q9IYdzT8ucqnV11bBkhcaVyoboWm14Vj0D86mkydaZDaDkzwxL1314bkA">
              <div className="relative aspect-[3/4] overflow-hidden bg-surface-container border border-outline/20 group-hover:border-primary/50 transition-colors">
                <img className="absolute inset-0 w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-500" data-alt="A close-up of a stunning, heavy bridal choker necklace set in 22k gold with deep red rubies and uncut diamonds. Resting on a dark maroon velvet cushion. Extremely detailed, luxurious dark mode presentation." src="https://lh3.googleusercontent.com/aida-public/AB6AXuCNbd1k5_EdZ-z8frKAjMzdUvWv4tiPN33ukA6_kktT_ioi_NZD-IOCQKE_hYQz7mMY-ofskLeCi58SKt9z-e84xDZ33QwLa1-xG-wf0BI_DDW1gnpiDX0D6qB2qtwbj1FnL2rMz4U1pcXkPQ3aAMc3j7TQCggYlCr--DVU4VS_RYRifYHv6OHM6jA2ju-05q9IYdzT8ucqnV11bBkhcaVyoboWm14Vj0D86mkydaZDaDkzwxL1314bkA" />
                <button className={wishClass("absolute top-sm right-sm p-sm bg-background/50 backdrop-blur-md rounded-full text-on-surface-variant hover:text-primary transition-colors border border-outline/30", isSaved("heritage-ruby-choker"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["heritage-ruby-choker"]); }}>
                  <span className="material-symbols-outlined text-[20px]">
                    {isSaved("heritage-ruby-choker") ? "favorite" : "favorite_border"}
                  </span>
                </button>
              </div>
              <div className="flex justify-between items-start pt-xs">
                <div>
                  <h3 className="font-body-lg text-body-lg text-on-background group-hover:text-primary transition-colors">
                    Heritage Ruby Choker
                  </h3>
                  <p className="font-body-md text-body-md text-on-surface-variant">
                    ₹3,60,000
                  </p>
                </div>
                <button className="gold-gradient-bg text-on-primary p-sm border border-primary-container hover:scale-105 transition-transform shadow-sm" aria-label="Add to bag" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["heritage-ruby-choker"]); }}>
                  <span className="material-symbols-outlined text-[20px]">
                    shopping_bag
                  </span>
                </button>
              </div>
            </div>
          </div>
          <div className="mt-lg flex justify-center">
            <button className="px-lg py-sm border-[0.5px] border-primary text-primary font-label-caps text-label-caps hover:bg-primary/10 transition-colors">
              VIEW ALL PRODUCTS
            </button>
          </div>
        </section>
      </main>
    </>
  );
}
