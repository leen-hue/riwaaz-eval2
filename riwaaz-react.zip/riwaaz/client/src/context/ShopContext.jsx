import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import api, { errorMessage } from "../api/client";
import { useAuth } from "./AuthContext";
import { useUI } from "./UIContext";

/**
 * Cart + wishlist.
 *  - Guests: stored in localStorage exactly like the original site.
 *  - Logged-in users: stored in MongoDB through the API. Whatever a guest
 *    collected is merged into the account on login.
 */
const LS_CART = "riwaaz_cart";
const LS_WISH = "riwaaz_wishlist";

const readLS = (key) => {
  try {
    const parsed = JSON.parse(localStorage.getItem(key));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};
const writeLS = (key, value) => localStorage.setItem(key, JSON.stringify(value));

const lineKey = (i) => `${i.id}|${i.size || ""}|${i.color || ""}`;
const withKeys = (list) => list.map((i) => ({ ...i, key: lineKey(i) }));
const sameLine = (a, b) => lineKey(a) === lineKey(b);

const ShopContext = createContext(null);

export function ShopProvider({ children }) {
  const { user, loading: authLoading } = useAuth();
  const { showToast } = useUI();
  const [items, setItems] = useState([]);
  const [wishlist, setWishlist] = useState([]);

  // Load / switch storage whenever the logged-in user changes.
  useEffect(() => {
    if (authLoading) return;
    let cancelled = false;

    async function load() {
      if (!user) {
        setItems(withKeys(readLS(LS_CART)));
        setWishlist(readLS(LS_WISH));
        return;
      }
      try {
        const guestCart = readLS(LS_CART);
        const guestWish = readLS(LS_WISH);
        if (guestCart.length) await api.post("/cart/merge", { items: guestCart });
        if (guestWish.length) await api.post("/wishlist/merge", { productIds: guestWish.map((w) => w.id) });
        localStorage.removeItem(LS_CART);
        localStorage.removeItem(LS_WISH);
        const [cartRes, wishRes] = await Promise.all([api.get("/cart"), api.get("/wishlist")]);
        if (cancelled) return;
        setItems(withKeys(cartRes.data.items));
        setWishlist(wishRes.data.items);
      } catch (err) {
        if (!cancelled) showToast(errorMessage(err, "Could not load your bag"));
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, [user, authLoading, showToast]);

  /* ---------------- cart ---------------- */

  const addToBag = useCallback(
    async (product, qty = 1) => {
      const line = {
        id: product.id,
        name: product.name,
        price: Number(product.price) || 0,
        image: product.image || "",
        size: product.size || "One Size",
        color: product.color || "",
        qty,
      };
      if (user) {
        try {
          const res = await api.post("/cart/items", {
            productId: line.id, size: line.size, color: line.color, qty,
          });
          setItems(withKeys(res.data.items));
        } catch (err) {
          showToast(errorMessage(err));
          return;
        }
      } else {
        const next = readLS(LS_CART);
        const existing = next.find((i) => sameLine(i, line));
        if (existing) existing.qty += qty;
        else next.push(line);
        writeLS(LS_CART, next);
        setItems(withKeys(next));
      }
      showToast(`Added "${product.name}" to your bag`);
    },
    [user, showToast]
  );

  const setQty = useCallback(
    async (item, qty) => {
      if (user) {
        try {
          const res = await api.patch("/cart/items", {
            productId: item.id, size: item.size, color: item.color, qty,
          });
          setItems(withKeys(res.data.items));
        } catch (err) {
          showToast(errorMessage(err));
        }
        return;
      }
      let next = readLS(LS_CART);
      if (qty < 1) next = next.filter((i) => !sameLine(i, item));
      else next = next.map((i) => (sameLine(i, item) ? { ...i, qty } : i));
      writeLS(LS_CART, next);
      setItems(withKeys(next));
    },
    [user, showToast]
  );

  const removeItem = useCallback(
    async (item) => {
      if (user) {
        try {
          const res = await api.delete("/cart/items", {
            params: { productId: item.id, size: item.size, color: item.color },
          });
          setItems(withKeys(res.data.items));
        } catch (err) {
          showToast(errorMessage(err));
        }
        return;
      }
      const next = readLS(LS_CART).filter((i) => !sameLine(i, item));
      writeLS(LS_CART, next);
      setItems(withKeys(next));
    },
    [user, showToast]
  );

  /* ---------------- wishlist ---------------- */

  const isSaved = useCallback((id) => wishlist.some((w) => w.id === id), [wishlist]);

  const toggleWishlist = useCallback(
    async (product) => {
      let nowSaved;
      if (user) {
        try {
          const res = await api.post("/wishlist/toggle", { productId: product.id });
          setWishlist(res.data.items);
          nowSaved = res.data.saved;
        } catch (err) {
          showToast(errorMessage(err));
          return;
        }
      } else {
        const list = readLS(LS_WISH);
        const idx = list.findIndex((w) => w.id === product.id);
        if (idx === -1) {
          list.push({ id: product.id, name: product.name, price: Number(product.price) || 0, image: product.image || "" });
          nowSaved = true;
        } else {
          list.splice(idx, 1);
          nowSaved = false;
        }
        writeLS(LS_WISH, list);
        setWishlist(list);
      }
      showToast(
        nowSaved ? `Saved "${product.name}" to your wishlist` : `Removed "${product.name}" from your wishlist`
      );
    },
    [user, showToast]
  );

  const removeFromWishlist = useCallback(
    async (id) => {
      if (user) {
        try {
          const res = await api.delete(`/wishlist/${encodeURIComponent(id)}`);
          setWishlist(res.data.items);
        } catch (err) {
          showToast(errorMessage(err));
        }
        return;
      }
      const next = readLS(LS_WISH).filter((w) => w.id !== id);
      writeLS(LS_WISH, next);
      setWishlist(next);
    },
    [user, showToast]
  );

  const moveWishlistItemToBag = useCallback(
    async (item) => {
      await addToBag({ ...item, size: "One Size", color: "" }, 1);
      await removeFromWishlist(item.id);
    },
    [addToBag, removeFromWishlist]
  );

  const cartCount = useMemo(() => items.reduce((n, i) => n + i.qty, 0), [items]);
  const subtotal = useMemo(() => items.reduce((n, i) => n + i.price * i.qty, 0), [items]);

  return (
    <ShopContext.Provider
      value={{
        items, cartCount, subtotal, addToBag, setQty, removeItem,
        wishlist, isSaved, toggleWishlist, removeFromWishlist, moveWishlistItemToBag,
      }}
    >
      {children}
    </ShopContext.Provider>
  );
}

export const useShop = () => useContext(ShopContext);
