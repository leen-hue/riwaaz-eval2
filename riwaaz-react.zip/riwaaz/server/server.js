require("dotenv").config();
const connectDB = require("./config/db");

if (!process.env.JWT_SECRET || process.env.JWT_SECRET === "change-me") {
  console.error("Set a strong JWT_SECRET in server/.env before starting (see .env.example).");
  process.exit(1);
}

const app = require("./app");
const PORT = process.env.PORT || 5000;

connectDB()
  .then(() => app.listen(PORT, () => console.log(`API listening on http://localhost:${PORT}`)))
  .catch((err) => {
    console.error("Failed to start:", err.message);
    process.exit(1);
  });
