const router = require("express").Router();
const c = require("../controllers/orderController");
const { requireAuth } = require("../middleware/auth");
const { requireRole } = require("../middleware/role");

router.use(requireAuth);
router.post("/", c.checkout);
router.get("/mine", c.mine);
router.get("/", requireRole("admin"), c.all);
router.get("/:id", c.get);
router.patch("/:id/status", requireRole("admin"), c.setStatus);

module.exports = router;
