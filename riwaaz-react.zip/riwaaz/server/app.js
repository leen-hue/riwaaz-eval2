const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const cookieParser = require("cookie-parser");
const multer = require("multer");
const { UPLOAD_DIR } = require("./middleware/upload");
const logger = require("./middleware/logger");
require("./utils/listeners"); // registers EventEmitter listeners

const app = express();

app.use(
  helmet({
    // Uploaded images are loaded by the React app from another origin in dev.
    crossOriginResourcePolicy: { policy: "cross-origin" },
  })
);
app.use(cors({ origin: process.env.CLIENT_ORIGIN || "http://localhost:5173", credentials: true }));
app.use(express.json({ limit: "100kb" }));
app.use(cookieParser());
if (process.env.NODE_ENV !== "test") app.use(logger);

app.use("/uploads", express.static(UPLOAD_DIR, { maxAge: "7d" }));

app.get("/api/health", (req, res) => res.json({ ok: true }));
app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/products", require("./routes/productRoutes"));
app.use("/api/cart", require("./routes/cartRoutes"));
app.use("/api/wishlist", require("./routes/wishlistRoutes"));
app.use("/api/auctions", require("./routes/auctionRoutes"));
app.use("/api/orders", require("./routes/orderRoutes"));
app.use("/api/contact", require("./routes/contactRoutes"));

app.use("/api", (req, res) => res.status(404).json({ message: "Not found." }));

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    const message = err.code === "LIMIT_FILE_SIZE" ? "Image is too large (max 5 MB)." : "Upload failed.";
    return res.status(400).json({ message });
  }
  if (err.name === "CastError" || err.name === "ValidationError") {
    return res.status(400).json({ message: "Invalid data." });
  }
  const status = err.status || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({ message: status >= 500 ? "Something went wrong on our side." : err.message });
});

module.exports = app;
