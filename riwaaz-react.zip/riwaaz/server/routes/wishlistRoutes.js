const router = require("express").Router();
const c = require("../controllers/wishlistController");
const { requireAuth } = require("../middleware/auth");

router.use(requireAuth);
router.get("/", c.get);
router.post("/toggle", c.toggle);
router.post("/merge", c.merge);
router.delete("/:productId", c.remove);

module.exports = router;
