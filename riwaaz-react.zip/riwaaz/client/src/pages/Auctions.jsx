import { PRODUCTS } from "../data/products";
import { useShop } from "../context/ShopContext";
import { formatINR, wishClass } from "../utils/format";
import { useAuction } from "../hooks/useAuction";

export const meta = { page: "auctions", route: "/auctions", title: "RIWAAZ | Exclusive Auctions", bodyClass: "antialiased selection:bg-primary-container selection:text-on-primary-container" };

export default function Auctions() {
  const { isSaved } = useShop();
  const { countdown, auction, ended, showTimer, secondsLeft, placeBid, busy } = useAuction();
  return (
    <>
      <main className="max-w-[1920px] mx-auto overflow-hidden">
        <section className="relative w-full h-[420px] min-h-[340px] bg-gradient-to-br from-deep-maroon via-surface-container to-gold-muted/20 flex items-center justify-center border-b-[0.5px] border-primary/20">
          <div className="absolute inset-0 z-0">
            <img className="w-full h-full object-cover object-center opacity-40 mix-blend-overlay" data-alt="A dramatic, dark-mode auction house interior with a single spotlight illuminating a velvet pedestal displaying an ornate gold and ruby bridal necklace. Palatial architecture in the background, soft bokeh, opulent and mysterious atmosphere." src="https://lh3.googleusercontent.com/aida-public/AB6AXuCNbd1k5_EdZ-z8frKAjMzdUvWv4tiPN33ukA6_kktT_ioi_NZD-IOCQKE_hYQz7mMY-ofskLeCi58SKt9z-e84xDZ33QwLa1-xG-wf0BI_DDW1gnpiDX0D6qB2qtwbj1FnL2rMz4U1pcXkPQ3aAMc3j7TQCggYlCr--DVU4VS_RYRifYHv6OHM6jA2ju-05q9IYdzT8ucqnV11bBkhcaVyoboWm14Vj0D86mkydaZDaDkzwxL1314bkA" />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-deep-maroon/60 to-transparent"></div>
          </div>
          <div className="relative z-10 text-center px-margin-desktop flex flex-col items-center">
            <p className="font-label-caps text-label-caps text-gold-muted mb-sm tracking-[0.2em]">
              Rare & Heirloom Pieces
            </p>
            <h1 className="font-display-lg text-display-lg text-primary mb-md text-glow">
              EXCLUSIVE AUCTIONS
            </h1>
            <p className="font-body-lg text-body-lg text-on-surface max-w-2xl">
              Bid on one-of-a-kind heritage lehengas, sherwanis, and jewellery — released to auction in strictly limited runs.
            </p>
          </div>
        </section>
        <section className="py-xl px-margin-desktop border-b-[0.5px] border-outline/30 bg-gradient-to-r from-surface via-surface-container to-deep-maroon/20">
          <div className="flex flex-col items-center text-center gap-md">
            <p className="font-label-caps text-label-caps text-gold-muted tracking-[0.2em]" id="countdown-label">
              {countdown.done ? "Auction Is Now Live" : "Next Auction Opens In"}
            </p>
            <div className="flex items-center gap-sm md:gap-md" id="countdown-clock">
              <div className="flex flex-col items-center bg-surface-container-high border border-outline/20 rounded-lg px-md py-sm md:px-lg md:py-md min-w-[90px] md:min-w-[120px] box-glow">
                <span className="font-display-lg text-[36px] md:text-display-lg text-primary text-glow tabular-nums" id="countdown-days">
                  {countdown.days}
                </span>
                <span className="font-label-xs text-label-xs text-on-surface-variant mt-xs">
                  DAYS
                </span>
              </div>
              <span className="font-display-lg text-[36px] md:text-display-lg text-gold-muted">
                :
              </span>
              <div className="flex flex-col items-center bg-surface-container-high border border-outline/20 rounded-lg px-md py-sm md:px-lg md:py-md min-w-[90px] md:min-w-[120px] box-glow">
                <span className="font-display-lg text-[36px] md:text-display-lg text-primary text-glow tabular-nums" id="countdown-hours">
                  {countdown.hours}
                </span>
                <span className="font-label-xs text-label-xs text-on-surface-variant mt-xs">
                  HOURS
                </span>
              </div>
              <span className="font-display-lg text-[36px] md:text-display-lg text-gold-muted">
                :
              </span>
              <div className="flex flex-col items-center bg-surface-container-high border border-outline/20 rounded-lg px-md py-sm md:px-lg md:py-md min-w-[90px] md:min-w-[120px] box-glow">
                <span className="font-display-lg text-[36px] md:text-display-lg text-primary text-glow tabular-nums" id="countdown-mins">
                  {countdown.mins}
                </span>
                <span className="font-label-xs text-label-xs text-on-surface-variant mt-xs">
                  MINUTES
                </span>
              </div>
            </div>
            <p className="font-body-md text-body-md text-on-surface-variant max-w-lg" id="next-auction-name">
              {countdown.name}
            </p>
          </div>
        </section>
        <section className="py-xl px-margin-desktop border-b-[0.5px] border-outline/30 bg-gradient-to-bl from-surface-dim via-deep-maroon/30 to-gold-muted/10">
          <div className="flex justify-between items-end mb-lg">
            <h2 className="font-display-lg text-display-lg text-primary">
              Live Now
            </h2>
            <span className="flex items-center gap-xs font-label-caps text-label-caps text-secondary">
              <span className="w-2 h-2 rounded-full bg-secondary pulse-dot"></span>
              LIVE AUCTION
            </span>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-lg items-stretch" data-product data-product-id="heritage-ruby-choker-auction" data-product-name="Heritage Ruby Choker" data-product-price="240000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuCNbd1k5_EdZ-z8frKAjMzdUvWv4tiPN33ukA6_kktT_ioi_NZD-IOCQKE_hYQz7mMY-ofskLeCi58SKt9z-e84xDZ33QwLa1-xG-wf0BI_DDW1gnpiDX0D6qB2qtwbj1FnL2rMz4U1pcXkPQ3aAMc3j7TQCggYlCr--DVU4VS_RYRifYHv6OHM6jA2ju-05q9IYdzT8ucqnV11bBkhcaVyoboWm14Vj0D86mkydaZDaDkzwxL1314bkA">
            <div className="relative aspect-[4/3] lg:aspect-auto overflow-hidden bg-surface-container border border-outline/20 rounded-lg">
              <img className="absolute inset-0 w-full h-full object-cover opacity-90" data-alt="A close-up of a stunning, heavy bridal choker necklace set in 22k gold with deep red rubies and uncut diamonds, resting on dark maroon velvet under a single dramatic spotlight, as if displayed on an auction pedestal." src="https://lh3.googleusercontent.com/aida-public/AB6AXuCNbd1k5_EdZ-z8frKAjMzdUvWv4tiPN33ukA6_kktT_ioi_NZD-IOCQKE_hYQz7mMY-ofskLeCi58SKt9z-e84xDZ33QwLa1-xG-wf0BI_DDW1gnpiDX0D6qB2qtwbj1FnL2rMz4U1pcXkPQ3aAMc3j7TQCggYlCr--DVU4VS_RYRifYHv6OHM6jA2ju-05q9IYdzT8ucqnV11bBkhcaVyoboWm14Vj0D86mkydaZDaDkzwxL1314bkA" />
              <span className={ended ? "absolute top-sm left-sm font-label-caps text-label-caps px-sm py-xs rounded-DEFAULT bg-surface-container-highest text-on-surface-variant border border-outline/30" : "absolute top-sm left-sm font-label-caps text-label-caps text-on-primary gold-gradient-bg px-sm py-xs rounded-DEFAULT"} id="auction-status-badge">
                {ended ? "SOLD" : "LOT 06 · LIVE"}
              </span>
            </div>
            <div className="flex flex-col justify-center gap-md bg-surface-container-low border border-outline/20 rounded-lg p-lg">
              <div>
                <p className="font-label-caps text-label-caps text-gold-muted tracking-[0.15em] mb-xs">
                  HERITAGE COLLECTIBLE · ONE OF ONE
                </p>
                <h3 className="font-headline-lg text-headline-lg text-on-background">
                  Heritage Ruby Choker
                </h3>
                <p className="font-body-md text-body-md text-on-surface-variant mt-xs">
                  A one-of-a-kind 22k gold choker set with uncut diamonds and Burmese rubies, hand-crafted by master karigars over 400 hours.
                </p>
              </div>
              <div className="flex flex-wrap gap-lg pt-sm border-t-[0.5px] border-outline/20">
                <div>
                  <p className="font-label-caps text-label-caps text-on-surface-variant">
                    Base Price
                  </p>
                  <p className="font-headline-md text-headline-md text-on-surface" id="base-price-amount">
                    {formatINR(auction.basePrice)}
                  </p>
                </div>
                <div>
                  <p className="font-label-caps text-label-caps text-on-surface-variant">
                    Current Highest Bid
                  </p>
                  <p className="font-headline-md text-headline-md text-gold-tint text-glow" id="current-bid-amount">
                    {formatINR(auction.currentBid)}
                  </p>
                </div>
                <div>
                  <p className="font-label-caps text-label-caps text-on-surface-variant">
                    Bids Placed
                  </p>
                  <p className="font-headline-md text-headline-md text-on-surface" id="bid-count">
                    {auction.bidCount}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-md pt-sm">
                <button
                  className={"gold-gradient-bg text-on-primary font-label-caps text-label-caps px-lg py-sm rounded-DEFAULT border border-primary-container box-glow transition-transform duration-300 " + (ended ? "opacity-50 cursor-not-allowed hover:scale-100" : "hover:scale-105")}
                  id="bid-button"
                  disabled={ended || busy}
                  onClick={placeBid}
                >
                  {ended ? "AUCTION ENDED" : "PLACE BID"}
                </button>
                <div className={showTimer ? "items-center gap-xs" : "hidden items-center gap-xs"} id="bid-timer-wrap">
                  <span className="material-symbols-outlined text-secondary text-[20px]">
                    timer
                  </span>
                  <span className="font-label-caps text-label-caps text-on-surface-variant">
                    Ends in
                  </span>
                  <span className={"font-headline-md text-headline-md tabular-nums tick-anim " + (secondsLeft <= 2 ? "text-error" : "text-secondary")} id="bid-timer" key={secondsLeft}>
                    {secondsLeft}
                  </span>
                  <span className="font-label-caps text-label-caps text-on-surface-variant">
                    s
                  </span>
                </div>
              </div>
              <p className="font-label-xs text-label-xs text-on-surface-variant tracking-[0.1em]">
                Each bid extends the auction by 5 seconds. Highest bid standing when the clock hits zero wins the lot.
              </p>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}
