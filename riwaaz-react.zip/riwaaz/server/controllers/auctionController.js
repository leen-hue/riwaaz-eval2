const Auction = require("../models/Auction");
const HttpError = require("../utils/httpError");
const asyncHandler = require("../utils/asyncHandler");
const { removeUpload } = require("../middleware/upload");

/**
 * Lifecycle (no background jobs needed - state is settled lazily on each read):
 *   upcoming --(startsAt passes)--> live --(endsAt passes with no new bid)--> ended
 * The first bid sets endsAt = now + windowSeconds; each later bid pushes it forward again.
 */
async function settle(now = new Date()) {
  await Auction.updateMany({ status: "upcoming", startsAt: { $lte: now } }, { $set: { status: "live" } });
  await Auction.updateMany({ status: "live", endsAt: { $ne: null, $lte: now } }, { $set: { status: "ended" } });
}

exports.state = asyncHandler(async (req, res) => {
  const now = new Date();
  await settle(now);
  // The lot to show: the most recently started one (live, or just sold).
  const current = await Auction.findOne({ status: { $in: ["live", "ended"] } }).sort({ startsAt: -1 });
  const next = await Auction.findOne({ status: "upcoming" }).sort({ startsAt: 1 });
  res.json({
    serverTime: now.toISOString(),
    windowSeconds: current ? current.windowSeconds : 5,
    auction: current ? current.toPublic() : null,
    next: next ? { title: next.title, startsAt: next.startsAt } : null,
  });
});

exports.bid = asyncHandler(async (req, res) => {
  const id = String(req.params.id);
  if (!/^[a-f\d]{24}$/i.test(id)) throw new HttpError(404, "Auction not found.");

  // Optimistic concurrency: the update only applies if nobody bid in between
  // (bidCount unchanged). Retry a few times, then report a conflict.
  for (let attempt = 0; attempt < 4; attempt++) {
    const now = new Date();
    await settle(now);
    const auction = await Auction.findById(id);
    if (!auction) throw new HttpError(404, "Auction not found.");
    if (auction.status !== "live") {
      throw new HttpError(409, auction.status === "ended" ? "This auction has ended." : "This auction hasn't started yet.");
    }

    const updated = await Auction.findOneAndUpdate(
      { _id: auction._id, status: "live", bidCount: auction.bidCount },
      {
        $set: {
          currentBid: auction.currentBid + auction.increment,
          bidCount: auction.bidCount + 1,
          highestBidder: req.user._id,
          endsAt: new Date(now.getTime() + auction.windowSeconds * 1000),
        },
      },
      { new: true }
    );
    if (updated) return res.json({ serverTime: now.toISOString(), auction: updated.toPublic() });
  }
  throw new HttpError(409, "Someone else bid at the same moment - please try again.");
});

// ---- admin ----

exports.create = asyncHandler(async (req, res) => {
  const uploaded = req.file ? `/uploads/${req.file.filename}` : "";
  try {
    const b = req.body || {};
    const title = typeof b.title === "string" ? b.title.trim().slice(0, 160) : "";
    const basePrice = Number(b.basePrice);
    const increment = Number(b.increment);
    if (!title) throw new HttpError(400, "Title is required.");
    if (!(basePrice >= 1) || !(increment >= 1)) throw new HttpError(400, "Base price and increment must be at least 1.");
    let startsAt = b.startsAt ? new Date(b.startsAt) : new Date();
    if (Number.isNaN(startsAt.getTime())) throw new HttpError(400, "Invalid start time.");

    const auction = await Auction.create({
      title,
      description: typeof b.description === "string" ? b.description.slice(0, 2000) : "",
      image: uploaded,
      basePrice,
      increment,
      currentBid: basePrice,
      startsAt,
      status: startsAt <= new Date() ? "live" : "upcoming",
    });
    res.status(201).json({ auction: auction.toPublic() });
  } catch (err) {
    removeUpload(uploaded);
    throw err;
  }
});

exports.remove = asyncHandler(async (req, res) => {
  const auction = await Auction.findByIdAndDelete(String(req.params.id));
  if (!auction) throw new HttpError(404, "Auction not found.");
  removeUpload(auction.image);
  res.json({ ok: true });
});
