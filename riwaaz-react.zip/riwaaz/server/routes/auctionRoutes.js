const router = require("express").Router();
const c = require("../controllers/auctionController");
const { requireAuth } = require("../middleware/auth");
const { requireRole } = require("../middleware/role");
const { upload } = require("../middleware/upload");

router.get("/", c.state);
router.post("/:id/bid", requireAuth, c.bid); // must be logged in to bid

router.post("/", requireAuth, requireRole("admin"), upload.single("image"), c.create);
router.delete("/:id", requireAuth, requireRole("admin"), c.remove);

module.exports = router;
