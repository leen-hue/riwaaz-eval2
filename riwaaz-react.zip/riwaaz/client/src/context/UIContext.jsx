import { createContext, useCallback, useContext, useRef, useState } from "react";

const UIContext = createContext(null);

export function UIProvider({ children }) {
  const [modal, setModal] = useState(null); // null | "wishlist" | "account"
  const [toasts, setToasts] = useState([]);
  const nextId = useRef(1);

  const openModal = useCallback((name) => setModal(name), []);
  const closeModal = useCallback(() => setModal(null), []);

  const showToast = useCallback((message) => {
    const id = nextId.current++;
    setToasts((t) => [...t, { id, message, visible: false }]);
    // fade in, then fade out and remove (same timing as the old showToast)
    requestAnimationFrame(() =>
      setToasts((t) => t.map((x) => (x.id === id ? { ...x, visible: true } : x)))
    );
    setTimeout(() => setToasts((t) => t.map((x) => (x.id === id ? { ...x, visible: false } : x))), 1800);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2100);
  }, []);

  return (
    <UIContext.Provider value={{ modal, openModal, closeModal, toasts, showToast }}>
      {children}
    </UIContext.Provider>
  );
}

export const useUI = () => useContext(UIContext);
