import { useEffect } from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";
import ModalRoot from "./ModalRoot";
import Toast from "./Toast";

/**
 * Wraps every page. The original pages each had their own <body> classes,
 * data-page value and <title>, so those are applied to <body> here and the
 * per-page palette / CSS (styles/pages.css) keys off body[data-page].
 */
export default function Layout({ meta, children }) {
  useEffect(() => {
    document.title = meta.title;
    document.body.className = meta.bodyClass;
    document.body.dataset.page = meta.page;
    window.scrollTo(0, 0);
  }, [meta]);

  return (
    <>
      <Navbar page={meta.page} />
      {children}
      <Footer />
      <ModalRoot />
      <Toast />
    </>
  );
}
