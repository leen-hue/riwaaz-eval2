import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useShop } from "../context/ShopContext";
import { useUI } from "../context/UIContext";
import { navClass } from "../utils/format";

export default function Navbar({ page }) {
  const { user } = useAuth();
  const { cartCount } = useShop();
  const { openModal } = useUI();
  return (
    <header className="bg-surface/80 dark:bg-surface/80 text-primary dark:text-primary font-body-md text-body-md uppercase tracking-widest w-full sticky top-0 z-50 backdrop-blur-md border-b-[0.5px] border-outline/30 shadow-sm transition-all duration-300">
      <div className="flex justify-between items-center px-margin-mobile md:px-margin-desktop py-md max-w-[1920px] mx-auto">
        <Link className="font-display-lg text-display-lg text-primary dark:text-gold-bright tracking-tighter hover:text-gold-tint transition-all duration-300" to="/">
          RIWAAZ
        </Link>
        <nav className="hidden md:flex items-center gap-md">
          <Link className={navClass("nav-link text-on-surface-variant hover:text-primary transition-colors hover:text-gold-tint duration-300 active:scale-95", page === "home")} to="/">
            New Arrivals
          </Link>
          <Link className={navClass("nav-link text-on-surface-variant hover:text-primary transition-colors hover:text-gold-tint duration-300 active:scale-95", page === "north-indian")} to="/north-indian">
            Collections
          </Link>
          <Link className={navClass("nav-link text-on-surface-variant hover:text-primary transition-colors hover:text-gold-tint duration-300 active:scale-95", page === "south-indian")} to="/south-indian">
            Bridal
          </Link>
          <Link className={navClass("nav-link text-on-surface-variant hover:text-primary transition-colors hover:text-gold-tint duration-300 active:scale-95", page === "central-india")} to="/central-india">
            Couture
          </Link>
          <Link className={navClass("nav-link text-on-surface-variant hover:text-primary transition-colors hover:text-gold-tint duration-300 active:scale-95", page === "north-eastern")} to="/north-eastern">
            Heritage
          </Link>
          <Link className={navClass("nav-link text-on-surface-variant hover:text-primary transition-colors hover:text-gold-tint duration-300 active:scale-95", page === "auctions")} to="/auctions">
            Auctions
          </Link>
        </nav>
        <div className="flex items-center gap-sm md:gap-md">
          <button id="nav-wishlist-btn" onClick={() => openModal("wishlist")} className="text-primary hover:text-gold-tint transition-all duration-300 active:scale-95">
            <span className="material-symbols-outlined" style={{fontVariationSettings: "'FILL' 0"}}>
              favorite
            </span>
          </button>
          <Link className="relative text-primary hover:text-gold-tint transition-all duration-300 active:scale-95" to="/cart">
            <span className="material-symbols-outlined" style={{fontVariationSettings: "'FILL' 0"}}>
              shopping_bag
            </span>
            <span className={(cartCount === 0 ? "hidden " : "") + "absolute -top-2 -right-2 bg-secondary text-on-secondary text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center normal-case"} data-cart-badge>
              {cartCount}
            </span>
          </Link>
          <button id="nav-account-btn" onClick={() => openModal("account")} title={user ? `Signed in as ${user.name}` : "Log in / Sign up"} className="hidden md:flex text-primary hover:text-gold-tint transition-all duration-300 active:scale-95">
            <span className="material-symbols-outlined" style={{ fontVariationSettings: user ? "'FILL' 1" : "'FILL' 0" }}>
              person
            </span>
          </button>
        </div>
      </div>
    </header>
  );
}
