import Home, { meta as HomeMeta } from "./Home";
import NorthIndian, { meta as NorthIndianMeta } from "./NorthIndian";
import SouthIndian, { meta as SouthIndianMeta } from "./SouthIndian";
import CentralIndia, { meta as CentralIndiaMeta } from "./CentralIndia";
import NorthEastern, { meta as NorthEasternMeta } from "./NorthEastern";
import Auctions, { meta as AuctionsMeta } from "./Auctions";
import Cart, { meta as CartMeta } from "./Cart";

export const pages = [
  { path: "/", Component: Home, meta: HomeMeta },
  { path: "/north-indian", Component: NorthIndian, meta: NorthIndianMeta },
  { path: "/south-indian", Component: SouthIndian, meta: SouthIndianMeta },
  { path: "/central-india", Component: CentralIndia, meta: CentralIndiaMeta },
  { path: "/north-eastern", Component: NorthEastern, meta: NorthEasternMeta },
  { path: "/auctions", Component: Auctions, meta: AuctionsMeta },
  { path: "/cart", Component: Cart, meta: CartMeta },
];
