const Wishlist = require("../models/Wishlist");
const Product = require("../models/Product");
const HttpError = require("../utils/httpError");
const asyncHandler = require("../utils/asyncHandler");

async function getList(userId) {
  return (await Wishlist.findOne({ user: userId })) || new Wishlist({ user: userId, productIds: [] });
}

async function hydrate(list) {
  const products = await Product.find({ productId: { $in: list.productIds } });
  const byId = new Map(products.map((p) => [p.productId, p]));
  return list.productIds
    .filter((id) => byId.has(id))
    .map((id) => {
      const p = byId.get(id);
      return { id, name: p.name, price: p.price, image: p.image };
    });
}

exports.get = asyncHandler(async (req, res) => {
  res.json({ items: await hydrate(await getList(req.user._id)) });
});

exports.toggle = asyncHandler(async (req, res) => {
  const productId = typeof req.body?.productId === "string" ? req.body.productId : "";
  if (!(await Product.exists({ productId }))) throw new HttpError(404, "That product is not available.");
  const list = await getList(req.user._id);
  const idx = list.productIds.indexOf(productId);
  const saved = idx === -1;
  if (saved) list.productIds.push(productId);
  else list.productIds.splice(idx, 1);
  await list.save();
  res.json({ saved, items: await hydrate(list) });
});

exports.remove = asyncHandler(async (req, res) => {
  const list = await getList(req.user._id);
  list.productIds = list.productIds.filter((id) => id !== String(req.params.productId));
  await list.save();
  res.json({ items: await hydrate(list) });
});

exports.merge = asyncHandler(async (req, res) => {
  const incoming = Array.isArray(req.body?.productIds) ? req.body.productIds.slice(0, 200) : [];
  const valid = await Product.find({ productId: { $in: incoming.filter((x) => typeof x === "string") } }).select("productId");
  const list = await getList(req.user._id);
  for (const p of valid) if (!list.productIds.includes(p.productId)) list.productIds.push(p.productId);
  await list.save();
  res.json({ items: await hydrate(list) });
});
