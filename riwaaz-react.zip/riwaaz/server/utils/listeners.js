const fs = require("fs");
const path = require("path");
const events = require("./events");

const LOG_DIR = path.join(__dirname, "..", "logs");
fs.mkdirSync(LOG_DIR, { recursive: true });

// A writable stream: lines are appended without loading the file into memory.
const orderLog = fs.createWriteStream(path.join(LOG_DIR, "orders.log"), { flags: "a" });
orderLog.on("error", (err) => console.error("orders.log:", err.message));

events.on("order:placed", (order) => {
  orderLog.write(`${new Date().toISOString()} order=${order._id} user=${order.user} total=${order.total} items=${order.items.length}\n`);
});

events.on("contact:received", (msg) => {
  console.log(`New contact message from ${msg.email}`);
});
