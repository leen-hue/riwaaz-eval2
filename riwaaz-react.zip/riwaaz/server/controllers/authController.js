const bcrypt = require("bcryptjs");
const User = require("../models/User");
const HttpError = require("../utils/httpError");
const asyncHandler = require("../utils/asyncHandler");
const { signToken, setAuthCookie, clearAuthCookie } = require("../utils/token");

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
// Used to keep login timing similar whether or not the email exists.
const DUMMY_HASH = bcrypt.hashSync("not-a-real-password", 12);

const isString = (v) => typeof v === "string";

exports.register = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body || {};
  if (!isString(name) || !isString(email) || !isString(password) || !name.trim() || !email.trim() || !password) {
    throw new HttpError(400, "Please fill in every field.");
  }
  const cleanEmail = email.trim().toLowerCase();
  if (!EMAIL_RE.test(cleanEmail)) throw new HttpError(400, "Please enter a valid email address.");
  if (password.length < 8 || password.length > 128) {
    throw new HttpError(400, "Password must be between 8 and 128 characters.");
  }
  if (await User.exists({ email: cleanEmail })) {
    throw new HttpError(409, "An account with that email already exists.");
  }

  const passwordHash = await bcrypt.hash(password, 12);
  let user;
  try {
    // role is never taken from the request body - new accounts are always "user".
    user = await User.create({ name: name.trim().slice(0, 80), email: cleanEmail, passwordHash, role: "user" });
  } catch (err) {
    if (err.code === 11000) throw new HttpError(409, "An account with that email already exists.");
    throw err;
  }
  setAuthCookie(res, signToken(user));
  res.status(201).json({ user: user.toPublic() });
});

exports.login = asyncHandler(async (req, res) => {
  const { email, password } = req.body || {};
  if (!isString(email) || !isString(password)) throw new HttpError(400, "Please enter your email and password.");

  const user = await User.findOne({ email: email.trim().toLowerCase() }).select("+passwordHash");
  const ok = await bcrypt.compare(password, user ? user.passwordHash : DUMMY_HASH);
  if (!user || !ok) throw new HttpError(401, "Email or password is incorrect.");

  setAuthCookie(res, signToken(user));
  res.json({ user: user.toPublic() });
});

exports.logout = (req, res) => {
  clearAuthCookie(res);
  res.json({ ok: true });
};

exports.me = (req, res) => res.json({ user: req.user ? req.user.toPublic() : null });
