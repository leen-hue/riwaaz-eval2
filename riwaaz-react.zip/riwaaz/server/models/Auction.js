const mongoose = require("mongoose");

const auctionSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true, maxlength: 160 },
    description: { type: String, default: "", maxlength: 2000 },
    image: { type: String, default: "" },
    basePrice: { type: Number, required: true, min: 1 },
    increment: { type: Number, required: true, min: 1 },
    currentBid: { type: Number, required: true },
    bidCount: { type: Number, default: 0 },
    highestBidder: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
    status: { type: String, enum: ["upcoming", "live", "ended"], default: "upcoming" },
    startsAt: { type: Date, required: true },
    // Set by the first bid; every later bid pushes it forward by windowSeconds.
    endsAt: { type: Date, default: null },
    windowSeconds: { type: Number, default: 5 },
  },
  { timestamps: true }
);

auctionSchema.methods.toPublic = function () {
  return {
    id: this._id.toString(), title: this.title, description: this.description, image: this.image,
    basePrice: this.basePrice, increment: this.increment, currentBid: this.currentBid,
    bidCount: this.bidCount, status: this.status, startsAt: this.startsAt, endsAt: this.endsAt,
  };
};

module.exports = mongoose.model("Auction", auctionSchema);
