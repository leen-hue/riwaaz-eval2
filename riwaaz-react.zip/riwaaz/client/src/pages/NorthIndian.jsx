import { PRODUCTS } from "../data/products";
import { useShop } from "../context/ShopContext";
import { formatINR, wishClass } from "../utils/format";

export const meta = { page: "north-indian", route: "/north-indian", title: "RIWAAZ | The North Indian Edit", bodyClass: "font-body-md antialiased relative min-h-screen flex flex-col" };

export default function NorthIndian() {
  const { addToBag, toggleWishlist, isSaved } = useShop();
  return (
    <>
      <div className="noise-overlay"></div>
      <main className="flex-grow flex flex-col">
        <section className="relative w-full h-[614px] md:h-[716px] flex items-center justify-center overflow-hidden border-b-[0.5px] border-outline/30">
          <div className="absolute inset-0 bg-surface-container-lowest z-0">
            <img className="w-full h-full object-cover opacity-60 mix-blend-luminosity" data-alt="A cinematic, wide-angle shot of a majestic North Indian palace courtyard at dusk, setting a palatial and grandiose mood for a luxury ethnic wear campaign. Deep shadows contrast with warm, glowing gold accents. The atmosphere is mysterious, tactile, and maximalist, aligning perfectly with a modern dark-mode aesthetic." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDnODwr8SrZ6a357INOKzKS9Jc3rejKHrIWD9I6TeHv6jUVKuwquqnkO0Ns8UHN5EV-Tud7itIJowhlrHv1P2syx9z8h9TpZDv6Wzcds9frH_9XH6qrer1VKqquTY1PS9_XzTbqEqzs6XF_ULka_sbuUf6N6IHMN8bHDpP5-cpF5xIQhCzQ7wUJfXvsAn1cK__0uha8_Ky-TQmsGBnFD4WbJ8eLFsfJqSu5tJ1pCT9-pGj2aqgZW77aoQ" />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent"></div>
          </div>
          <div className="relative z-10 text-center px-margin-mobile">
            <h2 className="font-label-caps text-label-caps text-gold-muted tracking-[0.2em] mb-sm uppercase">
              Curated Collection
            </h2>
            <h1 className="font-display-lg text-display-lg text-on-surface mb-md">
              The North Indian Edit
            </h1>
            <p className="font-body-lg text-body-lg text-on-surface-variant max-w-2xl mx-auto">
              Discover palatial grandeur with our handpicked selection of Lehengas, Anarkalis, and Sherwanis, crafted for the modern maximalist.
            </p>
          </div>
        </section>
        <section className="flex flex-col md:flex-row px-margin-mobile md:px-margin-desktop py-lg max-w-[1920px] mx-auto w-full gap-lg">
          <aside className="w-full md:w-64 flex-shrink-0 flex flex-col gap-lg border-b-[0.5px] md:border-b-0 md:border-r-[0.5px] border-outline/30 pb-lg md:pb-0 md:pr-lg">
            <div className="flex items-center justify-between mb-sm">
              <h3 className="font-headline-md text-headline-md text-gold-bright">
                Filters
              </h3>
              <button className="font-label-caps text-label-caps text-on-surface-variant hover:text-gold-tint transition-colors">
                Clear All
              </button>
            </div>
            <div className="flex flex-col gap-sm">
              <h4 className="font-label-caps text-label-caps text-on-surface uppercase tracking-widest border-b-[0.5px] border-outline/20 pb-xs mb-xs">
                Category
              </h4>
              <label className="flex items-center gap-sm cursor-pointer group">
                <input className="form-checkbox bg-surface-container border-outline/50 text-gold-muted rounded-DEFAULT focus:ring-gold-tint focus:ring-offset-background h-4 w-4 transition-all" type="checkbox" />
                <span className="font-body-md text-body-md text-on-surface-variant group-hover:text-gold-tint transition-colors">
                  Lehengas (24)
                </span>
              </label>
              <label className="flex items-center gap-sm cursor-pointer group">
                <input defaultChecked className="form-checkbox bg-surface-container border-outline/50 text-gold-muted rounded-DEFAULT focus:ring-gold-tint focus:ring-offset-background h-4 w-4 transition-all" type="checkbox" />
                <span className="font-body-md text-body-md text-gold-muted group-hover:text-gold-tint transition-colors">
                  Anarkalis (18)
                </span>
              </label>
              <label className="flex items-center gap-sm cursor-pointer group">
                <input className="form-checkbox bg-surface-container border-outline/50 text-gold-muted rounded-DEFAULT focus:ring-gold-tint focus:ring-offset-background h-4 w-4 transition-all" type="checkbox" />
                <span className="font-body-md text-body-md text-on-surface-variant group-hover:text-gold-tint transition-colors">
                  Sherwanis (12)
                </span>
              </label>
            </div>
            <div className="flex flex-col gap-sm">
              <h4 className="font-label-caps text-label-caps text-on-surface uppercase tracking-widest border-b-[0.5px] border-outline/20 pb-xs mb-xs">
                Color
              </h4>
              <div className="flex flex-wrap gap-sm">
                <button aria-label="Deep Maroon" className="w-8 h-8 rounded-full border-[0.5px] border-outline/50 bg-[#690000] ring-2 ring-offset-2 ring-offset-background ring-gold-muted"></button>
                <button aria-label="Obsidian Black" className="w-8 h-8 rounded-full border-[0.5px] border-outline/50 bg-[#131313]"></button>
                <button aria-label="Antique Gold" className="w-8 h-8 rounded-full border-[0.5px] border-outline/50 bg-[#d4af37]"></button>
                <button aria-label="Emerald Green" className="w-8 h-8 rounded-full border-[0.5px] border-outline/50 bg-[#004e47]"></button>
              </div>
            </div>
            <div className="flex flex-col gap-sm">
              <h4 className="font-label-caps text-label-caps text-on-surface uppercase tracking-widest border-b-[0.5px] border-outline/20 pb-xs mb-xs">
                Price Range
              </h4>
              <input className="w-full accent-gold-muted bg-surface-container h-1 rounded-full appearance-none outline-none" max="5000" min="500" type="range" defaultValue="2500" />
              <div className="flex justify-between font-label-caps text-label-caps text-on-surface-variant mt-xs">
                <span className="">
                  $500
                </span>
                <span className="">
                  $5,000+
                </span>
              </div>
            </div>
          </aside>
          <div className="flex-grow">
            <div className="flex justify-between items-center mb-md">
              <span className="font-body-md text-body-md text-on-surface-variant">
                Showing 54 items
              </span>
              <select className="bg-surface-container border-[0.5px] border-outline/30 text-on-surface font-label-caps text-label-caps rounded-DEFAULT py-xs px-sm focus:ring-gold-tint focus:border-gold-tint">
                <option>
                  Sort by: Recommended
                </option>
                <option>
                  Price: High to Low
                </option>
                <option>
                  Price: Low to High
                </option>
                <option>
                  Newest Arrivals
                </option>
              </select>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-gutter md:gap-md">
              <div className="group relative flex flex-col gap-xs cursor-pointer" data-product data-product-id="zardosi-anarkali" data-product-name="The Zardosi Anarkali" data-product-price="105000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuD0jEvE7u8vuCIxBWdE-L56A2kDCvMz9GgA-pIqAi-As5iendAC-nJmOINz7znaSW-QsZyDHFUAXx4UUWvBH453NLhksZaje0vXrVbA8XpU7SmpAoy-8MeBCH-a476HnMpD-R6H7Kc722vQ_C1uxHIAyuccySNv7nJe5HYEFKvqs9awc6gi4nS6WspJx31rxVDct6rSLimdHhHgHWMB5lQsKY8BHQyKcWSInOeGFA8JTBplaa_j7TQj6g">
                <div className="relative aspect-[3/4] overflow-hidden rounded-lg bg-surface-container-highest border-[0.5px] border-outline/20">
                  <img className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" data-alt="A high-fashion studio shot of a deep maroon velvet Anarkali suit heavily embroidered with intricate antique gold zari work. The garment is draped elegantly on a mannequin against a dark, moody background. Dramatic, directional lighting highlights the rich texture of the velvet and the metallic sheen of the gold thread, embodying a luxurious, maximalist aesthetic." src="https://lh3.googleusercontent.com/aida-public/AB6AXuD0jEvE7u8vuCIxBWdE-L56A2kDCvMz9GgA-pIqAi-As5iendAC-nJmOINz7znaSW-QsZyDHFUAXx4UUWvBH453NLhksZaje0vXrVbA8XpU7SmpAoy-8MeBCH-a476HnMpD-R6H7Kc722vQ_C1uxHIAyuccySNv7nJe5HYEFKvqs9awc6gi4nS6WspJx31rxVDct6rSLimdHhHgHWMB5lQsKY8BHQyKcWSInOeGFA8JTBplaa_j7TQj6g" />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <button className={wishClass("absolute top-sm right-sm text-on-surface hover:text-gold-tint z-10 transition-colors", isSaved("zardosi-anarkali"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["zardosi-anarkali"]); }}>
                    <span className="material-symbols-outlined" data-icon="favorite_border" style={{ fontVariationSettings: isSaved("zardosi-anarkali") ? "'FILL' 1" : "'FILL' 0" }}>
                      {isSaved("zardosi-anarkali") ? "favorite" : "favorite_border"}
                    </span>
                  </button>
                  <div className="absolute bottom-sm left-0 w-full px-sm translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                    <button className="w-full gold-gradient-bg text-on-primary font-label-caps text-label-caps py-sm rounded-DEFAULT glow-gold hover:opacity-90 transition-opacity" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["zardosi-anarkali"]); }}>
                      Add to Bag
                    </button>
                  </div>
                </div>
                <div className="flex flex-col mt-xs">
                  <h3 className="font-body-lg text-body-lg text-on-surface truncate group-hover:text-gold-tint transition-colors">
                    The Zardosi Anarkali
                  </h3>
                  <p className="font-headline-md text-headline-md text-gold-muted mt-xs">
                    ₹1,05,000
                  </p>
                </div>
              </div>
              <div className="group relative flex flex-col gap-xs cursor-pointer" data-product data-product-id="emerald-heritage-lehenga" data-product-name="Emerald Heritage Lehenga" data-product-price="290000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuCrglkefC3S_EdgnuNvFSMBZIYTXuDsUAgn77PKQmUWmpfr5wN1bnJZmNiwxlyEz_2L7eOyuuul9n9l2C1IZqHneCUg7WOP18lsYsFbcVX2auGEjKmX4irXxL6PzCTnkQpDSn1e_EJNz0J5bEKo2F3HWOGZdRFp2mdFo2nMIHy7UFKbyRgeDp5AH7C4ORxF9FvmfvK2Z2HsfHUDX4fnbW032i2KdfNW9GC8R0KmFKE5ERbvjHo72M6P5Q">
                <div className="relative aspect-[3/4] overflow-hidden rounded-lg bg-surface-container-highest border-[0.5px] border-outline/20">
                  <img className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" data-alt="A luxurious, heavy bridal Lehenga in a rich jewel-toned emerald green silk, adorned with palatial silver and gold motif embroidery. Photographed in a dramatic, dark-mode studio setting. Soft, glowing rim light catches the edge of the fabric, emphasizing its weight and the premium, maximalist aesthetic of the brand." src="https://lh3.googleusercontent.com/aida-public/AB6AXuCrglkefC3S_EdgnuNvFSMBZIYTXuDsUAgn77PKQmUWmpfr5wN1bnJZmNiwxlyEz_2L7eOyuuul9n9l2C1IZqHneCUg7WOP18lsYsFbcVX2auGEjKmX4irXxL6PzCTnkQpDSn1e_EJNz0J5bEKo2F3HWOGZdRFp2mdFo2nMIHy7UFKbyRgeDp5AH7C4ORxF9FvmfvK2Z2HsfHUDX4fnbW032i2KdfNW9GC8R0KmFKE5ERbvjHo72M6P5Q" />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <button className={wishClass("absolute top-sm right-sm text-on-surface hover:text-gold-tint z-10 transition-colors", isSaved("emerald-heritage-lehenga"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["emerald-heritage-lehenga"]); }}>
                    <span className="material-symbols-outlined" data-icon="favorite_border" style={{ fontVariationSettings: isSaved("emerald-heritage-lehenga") ? "'FILL' 1" : "'FILL' 0" }}>
                      {isSaved("emerald-heritage-lehenga") ? "favorite" : "favorite_border"}
                    </span>
                  </button>
                  <div className="absolute bottom-sm left-0 w-full px-sm translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                    <button className="w-full gold-gradient-bg text-on-primary font-label-caps text-label-caps py-sm rounded-DEFAULT glow-gold hover:opacity-90 transition-opacity" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["emerald-heritage-lehenga"]); }}>
                      Add to Bag
                    </button>
                  </div>
                </div>
                <div className="flex flex-col mt-xs">
                  <h3 className="font-body-lg text-body-lg text-on-surface truncate group-hover:text-gold-tint transition-colors">
                    Emerald Heritage Lehenga
                  </h3>
                  <p className="font-headline-md text-headline-md text-gold-muted mt-xs">
                    ₹2,90,000
                  </p>
                </div>
              </div>
              <div className="group relative flex flex-col gap-xs cursor-pointer" data-product data-product-id="ivory-brocade-sherwani" data-product-name="Ivory Brocade Sherwani" data-product-price="155000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuBT5IsSJfnP7JTqTHkx9VistOKkvda281Sp-POIYLO4A1uHWl2I7vgVOzPTmGB5UXSlnOSoOHgWoz5wRNCGer2HTpmVIenFKv9GFAB6p3WlBxDIaaeeNYzSNvjojAzRQs9Mq404cK__NF8uauhoGWgVtRhSSdAeiqFuREOTo7bb4IdZXDmyTqvCfOPHMwNeVfa5lRPdLYDWCL15eDx4cZ4z53v-nwg3MNFQRz1rrpEO5OON1vAAdK5aaA">
                <div className="relative aspect-[3/4] overflow-hidden rounded-lg bg-surface-container-highest border-[0.5px] border-outline/20">
                  <img className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" data-alt="An opulent men's Sherwani in a dark ivory brocade, layered with a contrasting deep maroon velvet stole. The garment features intricate palatial embroidery on the collar and cuffs. The setting is dark and mysterious, lit with a high-contrast cinematic glow that highlights the tactile luxury and grandeur of South Asian heritage wear." src="https://lh3.googleusercontent.com/aida-public/AB6AXuBT5IsSJfnP7JTqTHkx9VistOKkvda281Sp-POIYLO4A1uHWl2I7vgVOzPTmGB5UXSlnOSoOHgWoz5wRNCGer2HTpmVIenFKv9GFAB6p3WlBxDIaaeeNYzSNvjojAzRQs9Mq404cK__NF8uauhoGWgVtRhSSdAeiqFuREOTo7bb4IdZXDmyTqvCfOPHMwNeVfa5lRPdLYDWCL15eDx4cZ4z53v-nwg3MNFQRz1rrpEO5OON1vAAdK5aaA" />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <button className={wishClass("absolute top-sm right-sm text-on-surface hover:text-gold-tint z-10 transition-colors", isSaved("ivory-brocade-sherwani"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["ivory-brocade-sherwani"]); }}>
                    <span className="material-symbols-outlined" data-icon="favorite_border" style={{ fontVariationSettings: isSaved("ivory-brocade-sherwani") ? "'FILL' 1" : "'FILL' 0" }}>
                      {isSaved("ivory-brocade-sherwani") ? "favorite" : "favorite_border"}
                    </span>
                  </button>
                  <div className="absolute bottom-sm left-0 w-full px-sm translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                    <button className="w-full gold-gradient-bg text-on-primary font-label-caps text-label-caps py-sm rounded-DEFAULT glow-gold hover:opacity-90 transition-opacity" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["ivory-brocade-sherwani"]); }}>
                      Add to Bag
                    </button>
                  </div>
                </div>
                <div className="flex flex-col mt-xs">
                  <h3 className="font-body-lg text-body-lg text-on-surface truncate group-hover:text-gold-tint transition-colors">
                    Ivory Brocade Sherwani
                  </h3>
                  <p className="font-headline-md text-headline-md text-gold-muted mt-xs">
                    ₹1,55,000
                  </p>
                </div>
              </div>
              <div className="group relative flex flex-col gap-xs cursor-pointer" data-product data-product-id="obsidian-sequin-lehenga" data-product-name="Obsidian Sequin Lehenga" data-product-price="180000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuCDmSp6SDi8YmsNks07ztLZQ1A28iQhpfgIbExky9XkD3n9HXVZaeYqtv3NyaDLN8AkwZ0-I7c8N03Cqbm1c0vgXlwkWohpWyCf8kjQFhw9XtrRAcPnSKDRAjVlYNEwJuzLvzBE5f_0Dui8N4H3Tj7zBAYudGrGDAEUx6OBFb_EyRAiH9tIuwUmm1KNUUSP7jNaErbsZzm28FYk2KYUvlFhTCFJbgn53sQJ1qPZF0T1-3CiJRDD6EbIhQ">
                <div className="relative aspect-[3/4] overflow-hidden rounded-lg bg-surface-container-highest border-[0.5px] border-outline/20">
                  <img className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" data-alt="A striking detail shot of a heavily embellished Lehenga dupatta in obsidian black net, covered in shimmering gold and silver sequins arranged in grand geometric patterns. The dark background ensures the glowing metallic details stand out sharply. The tactile, maximalist aesthetic is captured through shallow depth of field and dramatic lighting." src="https://lh3.googleusercontent.com/aida-public/AB6AXuCDmSp6SDi8YmsNks07ztLZQ1A28iQhpfgIbExky9XkD3n9HXVZaeYqtv3NyaDLN8AkwZ0-I7c8N03Cqbm1c0vgXlwkWohpWyCf8kjQFhw9XtrRAcPnSKDRAjVlYNEwJuzLvzBE5f_0Dui8N4H3Tj7zBAYudGrGDAEUx6OBFb_EyRAiH9tIuwUmm1KNUUSP7jNaErbsZzm28FYk2KYUvlFhTCFJbgn53sQJ1qPZF0T1-3CiJRDD6EbIhQ" />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <button className={wishClass("absolute top-sm right-sm text-on-surface hover:text-gold-tint z-10 transition-colors", isSaved("obsidian-sequin-lehenga"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["obsidian-sequin-lehenga"]); }}>
                    <span className="material-symbols-outlined" data-icon="favorite_border" style={{ fontVariationSettings: isSaved("obsidian-sequin-lehenga") ? "'FILL' 1" : "'FILL' 0" }}>
                      {isSaved("obsidian-sequin-lehenga") ? "favorite" : "favorite_border"}
                    </span>
                  </button>
                  <div className="absolute bottom-sm left-0 w-full px-sm translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                    <button className="w-full gold-gradient-bg text-on-primary font-label-caps text-label-caps py-sm rounded-DEFAULT glow-gold hover:opacity-90 transition-opacity" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["obsidian-sequin-lehenga"]); }}>
                      Add to Bag
                    </button>
                  </div>
                </div>
                <div className="flex flex-col mt-xs">
                  <h3 className="font-body-lg text-body-lg text-on-surface truncate group-hover:text-gold-tint transition-colors">
                    Obsidian Sequin Lehenga
                  </h3>
                  <p className="font-headline-md text-headline-md text-gold-muted mt-xs">
                    ₹1,80,000
                  </p>
                </div>
              </div>
            </div>
            <div className="mt-lg flex justify-center">
              <button className="bg-transparent border-[0.5px] border-gold-muted text-gold-muted font-label-caps text-label-caps py-sm px-lg rounded-DEFAULT hover:bg-gold-muted/10 transition-colors uppercase tracking-widest">
                Load More
              </button>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}
