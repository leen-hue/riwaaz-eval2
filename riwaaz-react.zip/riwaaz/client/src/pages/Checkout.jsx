import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import api, { errorMessage } from "../api/client";
import FormField from "../components/FormField";
import { useShop } from "../context/ShopContext";
import { useUI } from "../context/UIContext";
import { formatINR } from "../utils/format";
import { meta as homeMeta } from "./Home";

export const meta = { ...homeMeta, page: "checkout", route: "/checkout", title: "Checkout — RIWAAZ" };

// Client-side validation mirrors the server's rules (server stays the authority).
function validate(v) {
  const e = {};
  if (!v.fullName.trim()) e.fullName = "Full name is required.";
  if (!/^[6-9]\d{9}$/.test(v.phone)) e.phone = "Enter a valid 10-digit mobile number.";
  if (v.address.trim().length < 8) e.address = "Please enter your full address.";
  if (!v.city.trim()) e.city = "City is required.";
  if (!/^\d{6}$/.test(v.pincode)) e.pincode = "Enter a valid 6-digit PIN code.";
  return e;
}

export default function Checkout() {
  const { items, subtotal } = useShop();
  const { showToast } = useUI();
  const navigate = useNavigate();
  // Multiple state variables: form values, errors, submitting flag
  const [values, setValues] = useState({ fullName: "", phone: "", address: "", city: "", pincode: "" });
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const onChange = (e) => setValues((v) => ({ ...v, [e.target.name]: e.target.value }));

  async function onSubmit(e) {
    e.preventDefault();
    const found = validate(values);
    setErrors(found);
    if (Object.keys(found).length) return;
    setSubmitting(true);
    try {
      await api.post("/orders", { shipping: values });
      showToast("Order placed — thank you!");
      navigate("/orders");
    } catch (err) {
      showToast(errorMessage(err));
    } finally {
      setSubmitting(false);
    }
  }

  if (items.length === 0) {
    return (
      <main className="max-w-[1920px] mx-auto px-margin-desktop py-xl text-center flex flex-col items-center gap-md">
        <h1 className="font-headline-lg text-headline-lg text-on-surface">Your bag is empty</h1>
        <Link to="/" className="gold-gradient-bg text-on-primary font-label-caps text-label-caps px-lg py-sm rounded-full">
          Start Shopping
        </Link>
      </main>
    );
  }

  return (
    <main className="max-w-[1920px] mx-auto px-margin-mobile md:px-margin-desktop py-lg">
      <h1 className="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg mb-lg">Checkout</h1>
      <div className="flex flex-col lg:flex-row gap-lg">
        <form onSubmit={onSubmit} noValidate className="flex-1 bg-surface-container-low border-[0.5px] border-outline/30 rounded-lg p-md flex flex-col gap-sm">
          <h2 className="font-headline-md text-headline-md text-on-surface">Delivery details</h2>
          <FormField label="Full name" name="fullName" value={values.fullName} onChange={onChange} error={errors.fullName} />
          <FormField label="Mobile number" name="phone" value={values.phone} onChange={onChange} error={errors.phone} inputMode="numeric" maxLength={10} />
          <FormField label="Address" name="address" as="textarea" rows={3} value={values.address} onChange={onChange} error={errors.address} />
          <div className="grid grid-cols-2 gap-sm">
            <FormField label="City" name="city" value={values.city} onChange={onChange} error={errors.city} />
            <FormField label="PIN code" name="pincode" value={values.pincode} onChange={onChange} error={errors.pincode} inputMode="numeric" maxLength={6} />
          </div>
          <button disabled={submitting} className="gold-gradient-bg text-on-primary font-label-caps text-label-caps uppercase tracking-widest py-sm rounded-lg mt-sm disabled:opacity-60">
            {submitting ? "Placing order…" : `Place order · ${formatINR(subtotal)}`}
          </button>
        </form>
        <aside className="w-full lg:w-96 bg-surface-container-high/80 border-[0.5px] border-outline/30 rounded-xl p-md flex flex-col gap-sm h-fit">
          <h2 className="font-headline-md text-headline-md border-b-[0.5px] border-outline/20 pb-sm">Order summary</h2>
          {items.map((i) => (
            <div key={i.key} className="flex justify-between gap-sm font-body-md text-body-md">
              <span className="text-on-surface-variant">{i.name} × {i.qty}</span>
              <span className="text-on-surface">{formatINR(i.price * i.qty)}</span>
            </div>
          ))}
          <div className="flex justify-between border-t-[0.5px] border-outline/20 pt-sm font-headline-md text-headline-md text-gold-bright">
            <span>Total</span><span>{formatINR(subtotal)}</span>
          </div>
        </aside>
      </div>
    </main>
  );
}
