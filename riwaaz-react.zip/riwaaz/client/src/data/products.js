// Product catalogue extracted from the original static pages (also used to seed MongoDB).
export const PRODUCTS = {
  "midnight-zardozi-lehenga": {
    "id": "midnight-zardozi-lehenga",
    "name": "Midnight Zardozi Lehenga",
    "price": 145000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuBJeLott6rSqWja7Ekbm24EWLrViE5F1jdg4xIpPMKd4BJxqKfqFlNiC6zVHbfahqwgR1nPDLwXQzxXr6eYMpCpAHQrCsnGDwGZRLu5yv6-lLDCEHuRPvumm2PRn3SrSTiC2mGT2tkAw03l3JOndqOgMJxXBOXA-3ksH0PpKD-zvvBZ_Wqyx95pOwmIOMKTGw1aTXD8xOQT8YiKzcl2oRWjONNUj_aDjskwgu6mq_Nz2zpcr7V15jocnA",
    "size": "",
    "color": "",
    "category": "home",
    "description": "Full length shot of a heavy bridal lehenga in midnight blue with extensive silver and gold embroidery. The model stands against a dark, textured wall. The fabric is rich silk. The lighting is dramatic and focused on the intricate details."
  },
  "crimson-royal-sherwani": {
    "id": "crimson-royal-sherwani",
    "name": "Crimson Royal Sherwani",
    "price": 85000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuBOsjcj3cXee10bGBy4VgQUcWeUDOMh0qLImL8467vP43AtIS1ZfJghkg-Uw5HVItlhYelUugc1dBp40kl0Tbse9nskLkFcWLf-f9tOB7jmeWRDjZuDx3918Un6PmKWqA45QqUe2OAokPU2pWaciv9x_-VAcKrXzdao4Kqk0eaz899RLnMcVvOb66GIWcHhT8MSMyh3rDau_N_vwk6jWbwSh1Ps7_wgqHYNznWYE95T7ACrdETgOGD5zg",
    "size": "",
    "color": "",
    "category": "home",
    "description": "A regal maroon silk sherwani for men, heavily embroidered with gold thread motifs. The garment is styled on a form with a dark, moody background. Tactile fabrics, opulent maximalism."
  },
  "emerald-organza-drape": {
    "id": "emerald-organza-drape",
    "name": "Emerald Organza Drape",
    "price": 55000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuAta6YQ1qyYx43flV5pAW5SmMRasSJx0-J3UWFZ9uUvO5tz8AMPWDBgHLWJRSFwdv9e_T_SRHAf8ME_wxd2e7UZLp76bkOgAC5OU2VJj3F84sE1j4KXWrVyTSbdmrld-Sk6sWxp9C1LGcttp_vuVOevYJkqMom2MEknOQ2rsihCFvWBkJ_8glCv5ZNCQbOkOsS1BaFS-Bco1-aLKwr3AkhO_luiDXLVPAweqRlZsQTAD1SO8qyyUHYqoQ",
    "size": "",
    "color": "",
    "category": "home",
    "description": "A delicate organza saree in deep emerald green with subtle, scattered gold sequins and a heavy zari border. Elegantly draped. Dark, sophisticated background, highlighting the sheer texture and metallic gleam."
  },
  "heritage-ruby-choker": {
    "id": "heritage-ruby-choker",
    "name": "Heritage Ruby Choker",
    "price": 360000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuCNbd1k5_EdZ-z8frKAjMzdUvWv4tiPN33ukA6_kktT_ioi_NZD-IOCQKE_hYQz7mMY-ofskLeCi58SKt9z-e84xDZ33QwLa1-xG-wf0BI_DDW1gnpiDX0D6qB2qtwbj1FnL2rMz4U1pcXkPQ3aAMc3j7TQCggYlCr--DVU4VS_RYRifYHv6OHM6jA2ju-05q9IYdzT8ucqnV11bBkhcaVyoboWm14Vj0D86mkydaZDaDkzwxL1314bkA",
    "size": "",
    "color": "",
    "category": "home",
    "description": "A close-up of a stunning, heavy bridal choker necklace set in 22k gold with deep red rubies and uncut diamonds. Resting on a dark maroon velvet cushion. Extremely detailed, luxurious dark mode presentation."
  },
  "zardosi-anarkali": {
    "id": "zardosi-anarkali",
    "name": "The Zardosi Anarkali",
    "price": 105000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuD0jEvE7u8vuCIxBWdE-L56A2kDCvMz9GgA-pIqAi-As5iendAC-nJmOINz7znaSW-QsZyDHFUAXx4UUWvBH453NLhksZaje0vXrVbA8XpU7SmpAoy-8MeBCH-a476HnMpD-R6H7Kc722vQ_C1uxHIAyuccySNv7nJe5HYEFKvqs9awc6gi4nS6WspJx31rxVDct6rSLimdHhHgHWMB5lQsKY8BHQyKcWSInOeGFA8JTBplaa_j7TQj6g",
    "size": "",
    "color": "",
    "category": "north-indian",
    "description": "A high-fashion studio shot of a deep maroon velvet Anarkali suit heavily embroidered with intricate antique gold zari work. The garment is draped elegantly on a mannequin against a dark, moody background. Dramatic, directional lighting highlights the rich texture of the velvet and the metallic sheen of the gold thread, embodying a luxurious, maximalist aesthetic."
  },
  "emerald-heritage-lehenga": {
    "id": "emerald-heritage-lehenga",
    "name": "Emerald Heritage Lehenga",
    "price": 290000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuCrglkefC3S_EdgnuNvFSMBZIYTXuDsUAgn77PKQmUWmpfr5wN1bnJZmNiwxlyEz_2L7eOyuuul9n9l2C1IZqHneCUg7WOP18lsYsFbcVX2auGEjKmX4irXxL6PzCTnkQpDSn1e_EJNz0J5bEKo2F3HWOGZdRFp2mdFo2nMIHy7UFKbyRgeDp5AH7C4ORxF9FvmfvK2Z2HsfHUDX4fnbW032i2KdfNW9GC8R0KmFKE5ERbvjHo72M6P5Q",
    "size": "",
    "color": "",
    "category": "north-indian",
    "description": "A luxurious, heavy bridal Lehenga in a rich jewel-toned emerald green silk, adorned with palatial silver and gold motif embroidery. Photographed in a dramatic, dark-mode studio setting. Soft, glowing rim light catches the edge of the fabric, emphasizing its weight and the premium, maximalist aesthetic of the brand."
  },
  "ivory-brocade-sherwani": {
    "id": "ivory-brocade-sherwani",
    "name": "Ivory Brocade Sherwani",
    "price": 155000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuBT5IsSJfnP7JTqTHkx9VistOKkvda281Sp-POIYLO4A1uHWl2I7vgVOzPTmGB5UXSlnOSoOHgWoz5wRNCGer2HTpmVIenFKv9GFAB6p3WlBxDIaaeeNYzSNvjojAzRQs9Mq404cK__NF8uauhoGWgVtRhSSdAeiqFuREOTo7bb4IdZXDmyTqvCfOPHMwNeVfa5lRPdLYDWCL15eDx4cZ4z53v-nwg3MNFQRz1rrpEO5OON1vAAdK5aaA",
    "size": "",
    "color": "",
    "category": "north-indian",
    "description": "An opulent men's Sherwani in a dark ivory brocade, layered with a contrasting deep maroon velvet stole. The garment features intricate palatial embroidery on the collar and cuffs. The setting is dark and mysterious, lit with a high-contrast cinematic glow that highlights the tactile luxury and grandeur of South Asian heritage wear."
  },
  "obsidian-sequin-lehenga": {
    "id": "obsidian-sequin-lehenga",
    "name": "Obsidian Sequin Lehenga",
    "price": 180000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuCDmSp6SDi8YmsNks07ztLZQ1A28iQhpfgIbExky9XkD3n9HXVZaeYqtv3NyaDLN8AkwZ0-I7c8N03Cqbm1c0vgXlwkWohpWyCf8kjQFhw9XtrRAcPnSKDRAjVlYNEwJuzLvzBE5f_0Dui8N4H3Tj7zBAYudGrGDAEUx6OBFb_EyRAiH9tIuwUmm1KNUUSP7jNaErbsZzm28FYk2KYUvlFhTCFJbgn53sQJ1qPZF0T1-3CiJRDD6EbIhQ",
    "size": "",
    "color": "",
    "category": "north-indian",
    "description": "A striking detail shot of a heavily embellished Lehenga dupatta in obsidian black net, covered in shimmering gold and silver sequins arranged in grand geometric patterns. The dark background ensures the glowing metallic details stand out sharply. The tactile, maximalist aesthetic is captured through shallow depth of field and dramatic lighting."
  },
  "rajarajeshwari-drape": {
    "id": "rajarajeshwari-drape",
    "name": "The Rajarajeshwari Drape",
    "price": 270000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuDSvGb1zzEMRLeYXMKt1iNx8ZQeADZozBnRto5zBcE_X15KZFF2CVXoJChKoZ0m9VCl3putvc2f1pFYTJLQV-OzJ_ibGB010B3q2adi5i0EiA6n8S38xhkIf2Resy9QV0YnPITMm0KNfMohVR3ftwWrn3RUj-QUi2zUmL2_YYTjtd-m0mRMdBxNkRQwa1GYTkbSzh3_kDGAJbQBKZI7VJW_3GYbWv8_9_yk5C-0cSW9oH4DmxSxYjhYLQ",
    "size": "",
    "color": "",
    "category": "south-indian",
    "description": "A stunning, full-length portrait of a model wearing a heavy, dark maroon Kanjeevaram silk saree with expansive, intricate gold zari borders featuring traditional peacock and mango motifs. The model is adorned with authentic antique gold temple jewelry, including a heavy choker and long haram. The background is a moody, dark palace interior lit by warm, ambient golden light. The style is Desi Maximalist, rich, tactile, and highly detailed, emphasizing the weight and sheen of the silk."
  },
  "lakshmi-heritage-choker": {
    "id": "lakshmi-heritage-choker",
    "name": "Lakshmi Heritage Choker",
    "price": 155000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuDoD7sFSdcYmUwMpG8cIUYGc0GLvKNhg4koat1-URz51HSkZInyx2C-dJOi0QLSyA9DHrH8Ik0ZMxPh48LgH3TNHbz0vOUara4HkGlaOoLOa2QIAZxK5NBerSt7Vuv1fIZnfhVeleDHxtAIHpcuIdgzzHBPFfoil5Gjk0eumL9P35dnOGlg0Ezx3gVt_Y4y1dxkmTQLc8WCKPuT6Qd73MLAIausm9KJivt9Cq3av4-F1cdbqd0Wun6mcg",
    "size": "",
    "color": "",
    "category": "south-indian",
    "description": "A close-up studio shot of an ornate, antique-finish gold choker necklace intricately carved with depictions of deities and lotus flowers, characteristic of South Indian temple jewelry. The necklace rests on a dark, textured velvet surface. The lighting highlights the tactile, raised filigree details and the muted, rich tone of the gold against the deep black background. The mood is luxurious, historical, and opulent."
  },
  "emerald-silk-veshti-set": {
    "id": "emerald-silk-veshti-set",
    "name": "Emerald & Silk Veshti Set",
    "price": 72000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuBPx5MiEoNL51QjxCUdBZFbTcSQOff-8b0_8lmu_gyBGhvYIgvazZQrYj8B02UPxynvXlZWw2MFrC76B1oqzLCS5goGyWykRKFC20SCYRDBTAS_zYhZSXdJcpTqahjcILmCW6tA6nj8eTuGTksoe8wdxhJu5iNvEf7KtQ2TXwuUH4UJiuEREOSfJcZOdrQfTl7YINVcUznjqVfKaXtMyF8-vI27fbFO0NJSpUbFblMOAUkumtZfW4P6dw",
    "size": "",
    "color": "",
    "category": "south-indian",
    "description": "A male model elegantly draped in a pristine, cream-colored silk Veshti with a broad, luminous gold zari border. He is wearing a matching silk Angavastram over a deep emerald green raw silk kurta. The setting is a dimly lit, atmospheric heritage courtyard with dark wood pillars. The style is sophisticated, traditional yet styled with a modern, high-fashion dark mode aesthetic. The contrast between the bright silk and dark surroundings is striking."
  },
  "indigo-zari-weave": {
    "id": "indigo-zari-weave",
    "name": "Indigo Zari Weave",
    "price": 180000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuDaXjntLrazzZ0qDsCqPuxl5SxUquJ41sQDdJ1m7BHxcTMjjrn7r23m9ZPAqF6mVuS-fk-TbkXq1FeO3fVrUZeZE5TPIvkVmCh_CElo7ZvdzwMvT6M4_IvMhsmMumLrs3TH7snz5PbD0GWGLfhLCFFtI6y1DraL2neL7F2KP2xoFb48yQ82W7rPtCf4P0lcJpNva1rf5MQRz9DVHe-jYgOW0SyImoolKxByM2X0ODUdaDgGjf5LK8X48Q",
    "size": "",
    "color": "",
    "category": "south-indian",
    "description": "A detailed, macro view of the pallu (end piece) of a Kanchipuram silk saree. The silk base is a deep, majestic indigo blue, heavily ornamented with complex geometric and floral patterns woven in contrasting silver and gold zari. The lighting is low and directional, emphasizing the tactile, raised texture of the metallic threads against the smooth silk base. The overall aesthetic is dark, luxurious, and highly detailed."
  },
  "ruby-temple-armlets": {
    "id": "ruby-temple-armlets",
    "name": "Ruby Temple Armlets",
    "price": 100000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuDOO-l5QlAkIRs254eOX42fJVVsWmCgltF5sOgfJJuFLr1HhC2KVwXaNrO0ylwTcPSNf_e-hyCp6rV3HeumbEAt28WoyC294RyrKe4pH5gXCve01WzPj8wYovPhUZQcBpYXe-c9hbfXEjfVFFy3y8UBKMR8YrPO4uPXeXClkAcn9OT6rbzBoDySUVoFjSRFRq0GYSfq1A3YHn7NM6kX651jNggsJ82D5T8-WUZ2mmsgnPR6ng1hr6fUvA",
    "size": "",
    "color": "",
    "category": "south-indian",
    "description": "An imposing set of heavy, gold Vanki (armlets) and matching bangles resting atop a piece of raw, unspun deep crimson silk. The jewelry features intricate repousse work typical of South Indian temple design, studded with unpolished rubies and emeralds. The scene is shot with a macro lens in a dark studio setting, using spotlighting to make the gold and jewels gleam intensely against the dark, textured fabric background."
  },
  "midnight-zari-drape": {
    "id": "midnight-zari-drape",
    "name": "Midnight Zari Drape",
    "price": 68500,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuAEe0VVimUP-WEJQiD0paYqvLJkm4JwTs5z52095v0DsrNc1ev0AujAdBaqEFaDo0d--_muqNN22fVlwXmH-2bc28TQhT4fE7_qoIYpHHV5j3e0KcRTEUVNSjoy7aAZU8Mi76wS7kMRnuLQAiU5jPhrIBvDlV5dXEeIGJChge9JsZeAAsnbBuhuPNlrfa0WfbrJJdGlmC7wPpfkhoPyCJv1CdOcJGJ_Hr6ri0oTg9gTRnvdjyQLXdEGHQ",
    "size": "",
    "color": "",
    "category": "central-india",
    "description": "A fashion editorial shot of an Indian model wearing a luxurious midnight blue and gold Maheshwari silk saree. The lighting is dramatic and moody, emphasizing the sheer texture and metallic zari work. The background is a deeply shadowed palatial archway, fitting the dark-mode maximalist aesthetic."
  },
  "burgundy-royal-lehenga": {
    "id": "burgundy-royal-lehenga",
    "name": "Burgundy Royal Lehenga",
    "price": 112000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuChnTv5ztNiAX9QNmXfbPNveyoGIm_djMfBpgL933HuTjFO7p83Io60sD6uEsnyXCS6kLsdf5uXtpxQclpchkfnrPM_MVLcQUcazwTajZVA2_xynj3IC2zxkv1219GQh3bjZsr1sLvY78edlhaIPUd9SJxHK4Lm-T4JS2xu6rqXmVVmvkIm3SksP9qyUnDCHRVB7DnYXy0xOuAxRnR5omqY2af8LJbCwd7tJjeeTBox39vjSrAtHpmTOg",
    "size": "",
    "color": "",
    "category": "central-india",
    "description": "Close up photography of a rich burgundy Chanderi silk lehenga with intricate golden embroidery. The fabric has a subtle sheen, illuminated by soft, focused light against a pitch-black background, highlighting the tactile maximalist luxury and craftsmanship."
  },
  "onyx-gilded-sherwani": {
    "id": "onyx-gilded-sherwani",
    "name": "Onyx Gilded Sherwani",
    "price": 85000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuB20HOQVed1-ec88TU0zdIVFSDxqyjTVOUllbBRW3UwuuLFPMqP6Br_-sXCM73Pl5cp1UgUzatFIbIEC6uSUDm42DDFHYcgVDTZP_JWWHnwk6XdZAG5zm6MbK2D-YzE2wYscIXHZ1-GfwTIP7nZ4vtrd11fsfwXotK1C_QSKKY9kZBkAQ4s3vxxunu8j0xmO6Avq4SqorSDP7edXtT7HLzYEKGlVKAw2-Wc4PoZp48XaBuyEgkMKM0yJw",
    "size": "",
    "color": "",
    "category": "central-india",
    "description": "A male model adorned in a stark black and gold embroidered sherwani, representing Central Indian regal attire. The image is styled in a high-contrast dark mode palette, with sharp lighting defining the intricate gold threadwork against the deep black fabric."
  },
  "emerald-zari-anarkali": {
    "id": "emerald-zari-anarkali",
    "name": "Emerald Zari Anarkali",
    "price": 54000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuAjVBLirx1EAqxvipivxqHWc-qU7LR5kwn9gY27pbXwReovKB9STKRm7RO8OUzuI7raXi0Lys2E-gayLAHLYcba6goJ91cmP_vuJI-QQYAelNpdN2VGwHYbz1UDq3M4t9Xdm2Kfx3gzFrbU6G7B5UsHPuyTFF609kv-keyxYsOK3YZx5rbv1iaEsuNUcgqb5DkNJHNsued_A_t_tvmGVrE1znngmzcV4Ia0w_CkBUeHO4zGr3iv9lTiiQ",
    "size": "",
    "color": "",
    "category": "central-india",
    "description": "An elegant deep emerald green Anarkali suit featuring delicate gold zari borders. The garment is draped beautifully, lit by a soft spotlight that creates rich shadows, perfect for a premium luxury fashion catalog in a dark aesthetic."
  },
  "suwani-mekhela": {
    "id": "suwani-mekhela",
    "name": "The Suwani Mekhela",
    "price": 45000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuBid7n7t4Kqb13blwMGmFSQJjHxaI7HkQ5ybwiCew2XYLCGiCfDxpLZO9SrKR74m5AJ-S6vXp8nSlSQ0DOsfDbu6H-XU2Nsc-yj_8dZCTzuftRPCo2YOK6GEeqayEX6FGjYI6CYXOT9Qcv3K51Sm5Ul8rH78Ig_YyHK_WPbLB4AR8-7_u2xvaq5hoaZLonPM6tSHoZdtPXROzj596kEpFJQ_jWRe-nVCcO3_4-RH5x7b3XaZ8WHzARx9A",
    "size": "",
    "color": "",
    "category": "north-eastern",
    "description": "A studio shot of a traditional Assamese Mekhela Chador made of rich golden Muga silk, draped beautifully. The dark mode lighting emphasizes the subtle, intricate tribal motifs woven into the borders. The background is a deep, textured black, allowing the golden hue of the silk to stand out brilliantly, capturing the maximalist yet refined aesthetic."
  },
  "ao-geometric-wrap": {
    "id": "ao-geometric-wrap",
    "name": "Ao Geometric Wrap",
    "price": 28500,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuBfpOkb_rAU1mwnoQX5nfDXLz3jCEtS-JIBIzSfxRnWcfpB-i6bXa3XGjAnppr5f-mYS3d-QCPisPEzR8Ie9Wuw11a4YhstlLkGiFJS45Nh6xuZUGaTd4z31h8leZufuheJkg37bhLPVVj-bHQzGo4FPZmPR3XzD5-2oQB66yCbIHl59n-yp48uLt1HsVhg1yiNKfoBLlZEMq7HtnntWI_VSPgik3rKu8_TIkDXH_qOATJOM8pq5vK9Ng",
    "size": "",
    "color": "",
    "category": "north-eastern",
    "description": "A striking image of a Naga tribal wrap skirt in deep maroon and black tones, featuring bold, geometric woven patterns. The fabric appears thick and textured, shot in low-key lighting to enhance the mysterious, palatial vibe. Subtle silver threads catch the light, contrasting beautifully with the dark background, perfectly aligned with the dark maximalist theme."
  },
  "ahimsa-eri-shawl": {
    "id": "ahimsa-eri-shawl",
    "name": "Ahimsa Eri Shawl",
    "price": 32000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuBpwSHQc03TXVYK1QsB7iQqSCZxuHcmkU7ekzWAvh42wUCZhvjWyRmOmKlRWtdWogqBe3QOhQwuk7HmhmG23Gv--x43R6QCsxVmtohkg5k6Msx0yH2GphKnfXVcUkPWYhNxQjLkSut293GwzjfqiH1mOO7MRW2_oy33SrDtcijL1z1ejfEGebYYqzhB2rUQjLOpGr7dync_-yGK1qhD5_IWXpeDrJ-skfcJ3dx6LOFTcrr9WvwOPUOeKA",
    "size": "",
    "color": "",
    "category": "north-eastern",
    "description": "A luxurious Eri silk shawl, known as peace silk, draped over a dark carved wooden stand. The off-white fabric has a heavy, textured drape, and its borders are adorned with intricate red and gold threadwork typical of North Eastern designs. The moody lighting casts deep shadows, making the shawl look like a prized artifact in a dimly lit, high-end gallery."
  },
  "emerald-zari-mekhela": {
    "id": "emerald-zari-mekhela",
    "name": "Emerald Zari Mekhela",
    "price": 65000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuBqH3OTmP6cl6S-16EP64lnOLcb1N7082nN9Wpq94-H58f5ijGrBqwN0npLzY-L6HZCzNiV0VNmho7T4LbB1pwYNZWffrwcLSxHC_YNbJdK9DN_PGzKzSwQ3xvJ0Oh2M4_ADf_mRmErtzeLh2-WW6OIeSgpd6th2RXFKI9ZlnDnpHDVQehqCapfhrAAX8JxV4vR-oQHj6ZfeNeP1nPGw2aCnCRKRisTbRiYjvFab65nCUD3xtvN16eJsg",
    "size": "",
    "color": "",
    "category": "north-eastern",
    "description": "A close-up fashion shot focusing on the ornate blouse and upper draping of a contemporary Mekhela Chador interpretation. The fabric is a deep, saturated emerald green with heavy gold zari work. The model is partially visible, styled with antique gold jewelry. The high-contrast dark mode aesthetic highlights the richness of the South Asian maximalist design against a pure black background."
  },
  "heritage-ruby-choker-auction": {
    "id": "heritage-ruby-choker-auction",
    "name": "Heritage Ruby Choker",
    "price": 240000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuCNbd1k5_EdZ-z8frKAjMzdUvWv4tiPN33ukA6_kktT_ioi_NZD-IOCQKE_hYQz7mMY-ofskLeCi58SKt9z-e84xDZ33QwLa1-xG-wf0BI_DDW1gnpiDX0D6qB2qtwbj1FnL2rMz4U1pcXkPQ3aAMc3j7TQCggYlCr--DVU4VS_RYRifYHv6OHM6jA2ju-05q9IYdzT8ucqnV11bBkhcaVyoboWm14Vj0D86mkydaZDaDkzwxL1314bkA",
    "size": "",
    "color": "",
    "category": "auctions",
    "description": "A close-up of a stunning, heavy bridal choker necklace set in 22k gold with deep red rubies and uncut diamonds, resting on dark maroon velvet under a single dramatic spotlight, as if displayed on an auction pedestal."
  },
  "gold-tissue-scallop-dupatta": {
    "id": "gold-tissue-scallop-dupatta",
    "name": "Gold Tissue Scallop Dupatta",
    "price": 15000,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuDbkSN6bIJbYq-SXlYijXFTMHNu0QguQU8AdP1ZywktZ4HKeYDJHlAg6D2FrC2MgW4GI9MSoKu8F0cTuRBl2pTWkjg8uDFBQZwel5qmkpyhPD7-4o0eSkQC7YE-KWWww3H4qP2dXZJUPoTNTkgWeVdbXInmSl-y8DZUr1hF2BxnkQL6B0WNoNrPebKCtqTIc0uYN4a-3QshediGL_yb1XHs9s8nSmpH4hOyMTcASnsr1n0-h-_CpKxFZQ",
    "size": "",
    "color": "",
    "category": "cart",
    "description": "A shimmering gold tissue silk dupatta with scalloped borders and heavy embellishments, draped elegantly on a dark background to highlight its metallic sheen."
  },
  "velvet-zardozi-potli": {
    "id": "velvet-zardozi-potli",
    "name": "Velvet Zardozi Potli",
    "price": 8500,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuAfCbH2JumA56fPF4e6nCw7gK49Gz2myAQ1H-X-Mh1V3OFsn3hJvH1b6CcWb56sTjx0yrqJ-ZwjqmT7PEYLxghnEVhnzjhzW76b38NOOBSCOU5HsOobNmmG1_dw5zGnEPrO5QnxlMeSENUDt8-T7KuQkvjtpp6DVRjJLSkt8-cvDzuZsTSfpLjmU7r56urJhtW3IAW8xOUV0p98VVATvNHIy16LF9QYE0EUVJmDDpK6le1ScLV351kwtA",
    "size": "",
    "color": "",
    "category": "cart",
    "description": "An ornate handcrafted potli bag in deep maroon velvet, adorned with antique gold zardozi embroidery and pearl tassels, sitting on a polished stone surface."
  },
  "ivory-embroidered-mojari": {
    "id": "ivory-embroidered-mojari",
    "name": "Ivory Embroidered Mojari",
    "price": 6200,
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuARb_jqOor-4piigeo-nnc9BRlbSwS34kBPfxCwZ2Gp5TrQ0LTbCLwa2Fpwd8qxcLN0YkZDCHSw4prn6GuQikg1D2BpOdvEtLwuhYIKm4W4UC9wparHmtipkZJAM4eqpcdjoRkscRBPSW18XaXeaBuhjP1aUfqaLyFJnjfHAI61MFYA8_XsBX-uNPMyEo35qBg7KmIo8OndCoMqFRkhV9PWf3674954VfQG9_pflRVGRsK3f0cMQC9ciA",
    "size": "",
    "color": "",
    "category": "cart",
    "description": "A pair of traditional men's embroidered mojari shoes in ivory raw silk with subtle gold accents, placed on a dark, textured velvet fabric."
  }
};
