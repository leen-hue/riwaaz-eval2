const mongoose = require("mongoose");

const productSchema = new mongoose.Schema(
  {
    // Slug used by the storefront markup (e.g. "zardosi-anarkali")
    productId: { type: String, required: true, unique: true, match: /^[a-z0-9-]+$/ },
    name: { type: String, required: true, trim: true, maxlength: 160 },
    price: { type: Number, required: true, min: 0 },
    image: { type: String, default: "" }, // external URL or /uploads/<file>
    category: { type: String, default: "", trim: true, maxlength: 60 },
    description: { type: String, default: "", maxlength: 2000 },
    size: { type: String, default: "" },
    color: { type: String, default: "" },
  },
  { timestamps: true }
);

productSchema.methods.toPublic = function () {
  return {
    id: this.productId, name: this.name, price: this.price, image: this.image,
    category: this.category, description: this.description, size: this.size, color: this.color,
  };
};

module.exports = mongoose.model("Product", productSchema);
