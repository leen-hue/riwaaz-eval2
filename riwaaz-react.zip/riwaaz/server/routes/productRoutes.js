const router = require("express").Router();
const c = require("../controllers/productController");
const { requireAuth } = require("../middleware/auth");
const { requireRole } = require("../middleware/role");
const { upload } = require("../middleware/upload");

router.get("/", c.list);
router.get("/:id", c.get);

// Admin only. `upload.single("image")` is multer reading the "image" form field.
router.post("/", requireAuth, requireRole("admin"), upload.single("image"), c.create);
router.put("/:id", requireAuth, requireRole("admin"), upload.single("image"), c.update);
router.delete("/:id", requireAuth, requireRole("admin"), c.remove);

module.exports = router;
