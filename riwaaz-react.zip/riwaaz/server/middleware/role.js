const HttpError = require("../utils/httpError");

// Authorization: are you allowed to do this? Use after requireAuth.
exports.requireRole =
  (...roles) =>
  (req, res, next) => {
    if (!req.user) return next(new HttpError(401, "Please log in to continue."));
    if (!roles.includes(req.user.role)) return next(new HttpError(403, "You don't have permission to do that."));
    next();
  };
