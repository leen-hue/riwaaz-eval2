import { Route, Routes } from "react-router-dom";
import { pages } from "./pages";
import Admin, { meta as adminMeta } from "./pages/Admin";
import Checkout, { meta as checkoutMeta } from "./pages/Checkout";
import Orders, { meta as ordersMeta } from "./pages/Orders";
import Contact, { meta as contactMeta } from "./pages/Contact";
import Layout from "./components/Layout";
import ProtectedRoute from "./components/ProtectedRoute";

export default function App() {
  return (
    <Routes>
      {pages.map(({ path, Component, meta }) => (
        <Route
          key={path}
          path={path}
          element={
            <Layout meta={meta}>
              <Component />
            </Layout>
          }
        />
      ))}
      <Route
        path="/admin"
        element={
          <Layout meta={adminMeta}>
            <ProtectedRoute role="admin">
              <Admin />
            </ProtectedRoute>
          </Layout>
        }
      />
      <Route path="/checkout" element={<Layout meta={checkoutMeta}><ProtectedRoute><Checkout /></ProtectedRoute></Layout>} />
      <Route path="/orders" element={<Layout meta={ordersMeta}><ProtectedRoute><Orders /></ProtectedRoute></Layout>} />
      <Route path="/contact" element={<Layout meta={contactMeta}><Contact /></Layout>} />
      <Route
        path="*"
        element={
          <Layout meta={{ ...adminMeta, title: "Not found — RIWAAZ" }}>
            <main className="max-w-[1920px] mx-auto px-margin-desktop py-xl text-center">
              <h1 className="font-display-lg text-display-lg text-primary mb-md">404</h1>
              <p className="font-body-lg text-body-lg text-on-surface-variant">This page doesn't exist.</p>
            </main>
          </Layout>
        }
      />
    </Routes>
  );
}
