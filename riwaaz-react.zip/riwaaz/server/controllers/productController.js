const Product = require("../models/Product");
const HttpError = require("../utils/httpError");
const asyncHandler = require("../utils/asyncHandler");
const { removeUpload } = require("../middleware/upload");

const SLUG_RE = /^[a-z0-9-]+$/;
const str = (v, max) => (typeof v === "string" ? v.trim().slice(0, max) : "");

function parseFields(body, { partial = false } = {}) {
  const out = {};
  if (!partial || body.productId !== undefined) {
    out.productId = str(body.productId, 80);
    if (!SLUG_RE.test(out.productId)) throw new HttpError(400, "Product ID must use lowercase letters, numbers and dashes.");
  }
  if (!partial || body.name !== undefined) {
    out.name = str(body.name, 160);
    if (!out.name) throw new HttpError(400, "Name is required.");
  }
  if (!partial || body.price !== undefined) {
    out.price = Number(body.price);
    if (!Number.isFinite(out.price) || out.price < 0) throw new HttpError(400, "Price must be a positive number.");
  }
  for (const [k, max] of [["category", 60], ["description", 2000], ["size", 40], ["color", 40]]) {
    if (body[k] !== undefined) out[k] = str(body[k], max);
  }
  return out;
}

exports.list = asyncHandler(async (req, res) => {
  const filter = {};
  if (typeof req.query.category === "string") filter.category = req.query.category;
  const products = await Product.find(filter).sort({ createdAt: -1 });
  res.json({ products: products.map((p) => p.toPublic()) });
});

exports.get = asyncHandler(async (req, res) => {
  const product = await Product.findOne({ productId: String(req.params.id) });
  if (!product) throw new HttpError(404, "Product not found.");
  res.json({ product: product.toPublic() });
});

exports.create = asyncHandler(async (req, res) => {
  const uploaded = req.file ? `/uploads/${req.file.filename}` : "";
  try {
    const fields = parseFields(req.body || {});
    const image = uploaded || str(req.body.imageUrl, 1000);
    if (!image) throw new HttpError(400, "Please upload a product image.");
    if (await Product.exists({ productId: fields.productId })) throw new HttpError(409, "That product ID is already in use.");
    const product = await Product.create({ ...fields, image });
    res.status(201).json({ product: product.toPublic() });
  } catch (err) {
    removeUpload(uploaded); // don't keep files for failed requests
    throw err;
  }
});

exports.update = asyncHandler(async (req, res) => {
  const uploaded = req.file ? `/uploads/${req.file.filename}` : "";
  try {
    const product = await Product.findOne({ productId: String(req.params.id) });
    if (!product) throw new HttpError(404, "Product not found.");
    const fields = parseFields(req.body || {}, { partial: true });
    delete fields.productId; // the slug is the stable identifier
    Object.assign(product, fields);
    if (uploaded) {
      removeUpload(product.image);
      product.image = uploaded;
    }
    await product.save();
    res.json({ product: product.toPublic() });
  } catch (err) {
    removeUpload(uploaded);
    throw err;
  }
});

exports.remove = asyncHandler(async (req, res) => {
  const product = await Product.findOneAndDelete({ productId: String(req.params.id) });
  if (!product) throw new HttpError(404, "Product not found.");
  removeUpload(product.image);
  res.json({ ok: true });
});
