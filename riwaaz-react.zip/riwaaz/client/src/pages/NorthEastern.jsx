import { PRODUCTS } from "../data/products";
import { useShop } from "../context/ShopContext";
import { formatINR, wishClass } from "../utils/format";

export const meta = { page: "north-eastern", route: "/north-eastern", title: "The North Eastern Edit - RIWAAZ", bodyClass: "antialiased min-h-screen flex flex-col" };

export default function NorthEastern() {
  const { addToBag, toggleWishlist, isSaved } = useShop();
  return (
    <>
      <main className="flex-grow flex flex-col">
        <section className="relative w-full h-[614px] min-h-[400px] flex items-center justify-center overflow-hidden border-b-[0.5px] border-outline/30">
          <div className="absolute inset-0 bg-cover bg-center w-full h-full opacity-60" data-alt="A grand, dark and moody fashion editorial photograph showcasing luxurious Muga silk from North East India. The fabric glows subtly with gold tones against a deep, shadowed background. A model draped elegantly in traditional Mekhela Chador stands amidst palatial, shadowy architecture. The lighting is cinematic, highlighting the rich textures and metallic sheen of the exotic weaves, embodying 'Desi Maximalism' in a high-fashion dark-mode aesthetic." style={{backgroundImage: "url(\"https://lh3.googleusercontent.com/aida-public/AB6AXuD4xHDqPpoLb_XiX0ktdWChDUdi76pkTio1LO8knLGvcJkNOW60OjpPnnrAzFKXHz2ItgjVDWxBns0ewpTOAr4GIDzehoFdlYwsmyrRWmCSBfN4UCt3PizUb6-snjM2K66IvpMkXjp9oGPSHwftuwK5brZbO5kszuTFytJEKDceIoax9QH3HV60OQqypVr-Mse9lkBrzNGZ_pyeMoPWFI5QHooZMbI6KqSkYeO-iT5BMDBsGcZdKAVSew\")"}}></div>
          <div className="absolute inset-0 bg-gradient-to-tr from-deep-maroon/60 via-background/60 to-gold-muted/30 backdrop-blur-[2px]"></div>
          <div className="relative z-10 text-center px-margin-mobile md:px-margin-desktop max-w-4xl mx-auto flex flex-col items-center gap-md">
            <span className="font-label-caps text-label-caps text-gold-muted uppercase tracking-widest">
              Heritage Collection
            </span>
            <h1 className="font-display-lg text-headline-lg-mobile md:text-display-lg text-primary">
              The North Eastern Edit
            </h1>
            <p className="font-body-lg text-body-lg text-on-surface-variant max-w-2xl">
              Discover the untamed opulence of India's North East. This curation celebrates the meticulous craftsmanship of tribal weaves, featuring the radiant golden threads of rare Muga silk and the profound elegance of Eri.
            </p>
            <button className="mt-md px-lg py-sm gold-gradient-bg text-on-primary font-label-caps text-label-caps uppercase gold-glow hover:scale-105 transition-transform duration-300">
              Explore Curations
            </button>
          </div>
        </section>
        <section className="flex-grow flex flex-col md:flex-row px-margin-mobile md:px-margin-desktop py-lg max-w-[1920px] mx-auto w-full gap-xl bg-gradient-to-br from-gold-muted/10 via-background to-surface-container-high/40">
          <aside className="w-full md:w-64 flex-shrink-0 hidden md:flex flex-col gap-lg border-r-[0.5px] border-outline/20 pr-md">
            <div className="flex items-center justify-between pb-sm border-b-[0.5px] border-outline/30">
              <h2 className="font-headline-md text-headline-md text-primary">
                Filters
              </h2>
              <button className="text-on-surface-variant hover:text-primary transition-colors text-sm">
                Clear All
              </button>
            </div>
            <div className="flex flex-col gap-sm">
              <h3 className="font-label-caps text-label-caps text-gold-muted uppercase">
                Textile
              </h3>
              <div className="flex flex-col gap-xs">
                <label className="flex items-center gap-sm cursor-pointer group">
                  <input className="form-checkbox bg-transparent border-outline text-primary focus:ring-primary focus:ring-offset-background w-4 h-4 rounded-sm" type="checkbox" />
                  <span className="font-body-md text-body-md text-on-surface-variant group-hover:text-primary transition-colors">
                    Muga Silk
                  </span>
                </label>
                <label className="flex items-center gap-sm cursor-pointer group">
                  <input defaultChecked className="form-checkbox bg-transparent border-outline text-primary focus:ring-primary focus:ring-offset-background w-4 h-4 rounded-sm" type="checkbox" />
                  <span className="font-body-md text-body-md text-on-surface-variant group-hover:text-primary transition-colors">
                    Eri Silk
                  </span>
                </label>
                <label className="flex items-center gap-sm cursor-pointer group">
                  <input className="form-checkbox bg-transparent border-outline text-primary focus:ring-primary focus:ring-offset-background w-4 h-4 rounded-sm" type="checkbox" />
                  <span className="font-body-md text-body-md text-on-surface-variant group-hover:text-primary transition-colors">
                    Cotton Weaves
                  </span>
                </label>
              </div>
            </div>
            <div className="flex flex-col gap-sm">
              <h3 className="font-label-caps text-label-caps text-gold-muted uppercase">
                Style
              </h3>
              <div className="flex flex-col gap-xs">
                <label className="flex items-center gap-sm cursor-pointer group">
                  <input defaultChecked className="form-checkbox bg-transparent border-outline text-primary focus:ring-primary focus:ring-offset-background w-4 h-4 rounded-sm" type="checkbox" />
                  <span className="font-body-md text-body-md text-on-surface-variant group-hover:text-primary transition-colors">
                    Mekhela Chador
                  </span>
                </label>
                <label className="flex items-center gap-sm cursor-pointer group">
                  <input className="form-checkbox bg-transparent border-outline text-primary focus:ring-primary focus:ring-offset-background w-4 h-4 rounded-sm" type="checkbox" />
                  <span className="font-body-md text-body-md text-on-surface-variant group-hover:text-primary transition-colors">
                    Wrap Skirts
                  </span>
                </label>
                <label className="flex items-center gap-sm cursor-pointer group">
                  <input className="form-checkbox bg-transparent border-outline text-primary focus:ring-primary focus:ring-offset-background w-4 h-4 rounded-sm" type="checkbox" />
                  <span className="font-body-md text-body-md text-on-surface-variant group-hover:text-primary transition-colors">
                    Shawls
                  </span>
                </label>
              </div>
            </div>
            <div className="flex flex-col gap-sm">
              <h3 className="font-label-caps text-label-caps text-gold-muted uppercase">
                Color Palette
              </h3>
              <div className="flex flex-wrap gap-sm">
                <div className="w-6 h-6 rounded-full bg-[#d4af37] border border-outline cursor-pointer ring-1 ring-primary ring-offset-2 ring-offset-background"></div>
                <div className="w-6 h-6 rounded-full bg-[#4a154b] border border-outline cursor-pointer hover:scale-110 transition-transform"></div>
                <div className="w-6 h-6 rounded-full bg-[#1e0b2b] border border-outline cursor-pointer hover:scale-110 transition-transform"></div>
                <div className="w-6 h-6 rounded-full bg-[#eadeed] border border-outline cursor-pointer hover:scale-110 transition-transform"></div>
              </div>
            </div>
          </aside>
          <div className="flex-grow flex flex-col gap-lg">
            <div className="md:hidden flex justify-between items-center pb-sm border-b-[0.5px] border-outline/30">
              <span className="font-body-md text-body-md text-on-surface-variant">
                Showing 24 items
              </span>
              <button className="flex items-center gap-xs text-primary font-label-caps text-label-caps uppercase">
                <span className="material-symbols-outlined text-sm">
                  tune
                </span>
                Filters
              </button>
            </div>
            <div className="flex justify-between items-center hidden md:flex">
              <span className="font-body-md text-body-md text-on-surface-variant">
                Showing 24 Heritage Pieces
              </span>
              <div className="flex items-center gap-sm cursor-pointer group">
                <span className="font-label-caps text-label-caps text-gold-muted uppercase group-hover:text-primary transition-colors">
                  Sort By: Featured
                </span>
                <span className="material-symbols-outlined text-gold-muted group-hover:text-primary transition-colors">
                  expand_more
                </span>
              </div>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-gutter md:gap-md">
              <div className="group cursor-pointer relative flex flex-col" data-product data-product-id="suwani-mekhela" data-product-name="The Suwani Mekhela" data-product-price="45000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuBid7n7t4Kqb13blwMGmFSQJjHxaI7HkQ5ybwiCew2XYLCGiCfDxpLZO9SrKR74m5AJ-S6vXp8nSlSQ0DOsfDbu6H-XU2Nsc-yj_8dZCTzuftRPCo2YOK6GEeqayEX6FGjYI6CYXOT9Qcv3K51Sm5Ul8rH78Ig_YyHK_WPbLB4AR8-7_u2xvaq5hoaZLonPM6tSHoZdtPXROzj596kEpFJQ_jWRe-nVCcO3_4-RH5x7b3XaZ8WHzARx9A">
                <div className="relative w-full aspect-[3/4] overflow-hidden bg-gradient-to-b from-surface-container to-surface-container-high rounded-sm border-[0.5px] border-outline/20">
                  <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" data-alt="A studio shot of a traditional Assamese Mekhela Chador made of rich golden Muga silk, draped beautifully. The dark mode lighting emphasizes the subtle, intricate tribal motifs woven into the borders. The background is a deep, textured black, allowing the golden hue of the silk to stand out brilliantly, capturing the maximalist yet refined aesthetic." src="https://lh3.googleusercontent.com/aida-public/AB6AXuBid7n7t4Kqb13blwMGmFSQJjHxaI7HkQ5ybwiCew2XYLCGiCfDxpLZO9SrKR74m5AJ-S6vXp8nSlSQ0DOsfDbu6H-XU2Nsc-yj_8dZCTzuftRPCo2YOK6GEeqayEX6FGjYI6CYXOT9Qcv3K51Sm5Ul8rH78Ig_YyHK_WPbLB4AR8-7_u2xvaq5hoaZLonPM6tSHoZdtPXROzj596kEpFJQ_jWRe-nVCcO3_4-RH5x7b3XaZ8WHzARx9A" />
                  <div className="absolute inset-0 card-gradient opacity-80"></div>
                  <div className="absolute top-sm right-sm">
                    <button className={wishClass("w-8 h-8 rounded-full bg-surface-container/50 backdrop-blur-sm flex items-center justify-center text-primary hover:bg-primary/20 transition-colors", isSaved("suwani-mekhela"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["suwani-mekhela"]); }}>
                      <span className="material-symbols-outlined text-[18px]">
                        {isSaved("suwani-mekhela") ? "favorite" : "favorite_border"}
                      </span>
                    </button>
                  </div>
                  <div className="absolute bottom-sm left-sm right-sm flex items-end justify-between gap-xs">
                    <div className="font-label-caps text-label-caps px-2 py-1 bg-surface-container-high/80 backdrop-blur-md text-on-surface inline-block border-[0.5px] border-outline/30 uppercase">
                      Muga Silk
                    </div>
                    <button className="shrink-0 w-8 h-8 rounded-full bg-primary text-on-primary flex items-center justify-center hover:bg-gold-tint transition-colors" aria-label="Add to bag" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["suwani-mekhela"]); }}>
                      <span className="material-symbols-outlined text-[18px]">
                        shopping_bag
                      </span>
                    </button>
                  </div>
                </div>
                <div className="pt-sm flex flex-col gap-xs">
                  <h3 className="font-body-lg text-body-lg text-primary group-hover:text-gold-bright transition-colors truncate">
                    The Suwani Mekhela
                  </h3>
                  <p className="font-label-caps text-label-caps text-on-surface-variant">
                    ₹ 45,000
                  </p>
                </div>
              </div>
              <div className="group cursor-pointer relative flex flex-col" data-product data-product-id="ao-geometric-wrap" data-product-name="Ao Geometric Wrap" data-product-price="28500" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuBfpOkb_rAU1mwnoQX5nfDXLz3jCEtS-JIBIzSfxRnWcfpB-i6bXa3XGjAnppr5f-mYS3d-QCPisPEzR8Ie9Wuw11a4YhstlLkGiFJS45Nh6xuZUGaTd4z31h8leZufuheJkg37bhLPVVj-bHQzGo4FPZmPR3XzD5-2oQB66yCbIHl59n-yp48uLt1HsVhg1yiNKfoBLlZEMq7HtnntWI_VSPgik3rKu8_TIkDXH_qOATJOM8pq5vK9Ng">
                <div className="relative w-full aspect-[3/4] overflow-hidden bg-gradient-to-b from-surface-container to-surface-container-high rounded-sm border-[0.5px] border-outline/20">
                  <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" data-alt="A striking image of a Naga tribal wrap skirt in deep maroon and black tones, featuring bold, geometric woven patterns. The fabric appears thick and textured, shot in low-key lighting to enhance the mysterious, palatial vibe. Subtle silver threads catch the light, contrasting beautifully with the dark background, perfectly aligned with the dark maximalist theme." src="https://lh3.googleusercontent.com/aida-public/AB6AXuBfpOkb_rAU1mwnoQX5nfDXLz3jCEtS-JIBIzSfxRnWcfpB-i6bXa3XGjAnppr5f-mYS3d-QCPisPEzR8Ie9Wuw11a4YhstlLkGiFJS45Nh6xuZUGaTd4z31h8leZufuheJkg37bhLPVVj-bHQzGo4FPZmPR3XzD5-2oQB66yCbIHl59n-yp48uLt1HsVhg1yiNKfoBLlZEMq7HtnntWI_VSPgik3rKu8_TIkDXH_qOATJOM8pq5vK9Ng" />
                  <div className="absolute inset-0 card-gradient opacity-80"></div>
                  <div className="absolute top-sm right-sm">
                    <button className={wishClass("w-8 h-8 rounded-full bg-surface-container/50 backdrop-blur-sm flex items-center justify-center text-primary hover:bg-primary/20 transition-colors", isSaved("ao-geometric-wrap"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["ao-geometric-wrap"]); }}>
                      <span className="material-symbols-outlined text-[18px]">
                        {isSaved("ao-geometric-wrap") ? "favorite" : "favorite_border"}
                      </span>
                    </button>
                  </div>
                  <div className="absolute bottom-sm left-sm right-sm flex items-end justify-between gap-xs">
                    <div className="font-label-caps text-label-caps px-2 py-1 bg-surface-container-high/80 backdrop-blur-md text-on-surface inline-block border-[0.5px] border-outline/30 uppercase">
                      Tribal Weave
                    </div>
                    <button className="shrink-0 w-8 h-8 rounded-full bg-primary text-on-primary flex items-center justify-center hover:bg-gold-tint transition-colors" aria-label="Add to bag" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["ao-geometric-wrap"]); }}>
                      <span className="material-symbols-outlined text-[18px]">
                        shopping_bag
                      </span>
                    </button>
                  </div>
                </div>
                <div className="pt-sm flex flex-col gap-xs">
                  <h3 className="font-body-lg text-body-lg text-primary group-hover:text-gold-bright transition-colors truncate">
                    Ao Geometric Wrap
                  </h3>
                  <p className="font-label-caps text-label-caps text-on-surface-variant">
                    ₹ 28,500
                  </p>
                </div>
              </div>
              <div className="group cursor-pointer relative flex flex-col" data-product data-product-id="ahimsa-eri-shawl" data-product-name="Ahimsa Eri Shawl" data-product-price="32000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuBpwSHQc03TXVYK1QsB7iQqSCZxuHcmkU7ekzWAvh42wUCZhvjWyRmOmKlRWtdWogqBe3QOhQwuk7HmhmG23Gv--x43R6QCsxVmtohkg5k6Msx0yH2GphKnfXVcUkPWYhNxQjLkSut293GwzjfqiH1mOO7MRW2_oy33SrDtcijL1z1ejfEGebYYqzhB2rUQjLOpGr7dync_-yGK1qhD5_IWXpeDrJ-skfcJ3dx6LOFTcrr9WvwOPUOeKA">
                <div className="relative w-full aspect-[3/4] overflow-hidden bg-gradient-to-b from-surface-container to-surface-container-high rounded-sm border-[0.5px] border-outline/20">
                  <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" data-alt="A luxurious Eri silk shawl, known as peace silk, draped over a dark carved wooden stand. The off-white fabric has a heavy, textured drape, and its borders are adorned with intricate red and gold threadwork typical of North Eastern designs. The moody lighting casts deep shadows, making the shawl look like a prized artifact in a dimly lit, high-end gallery." src="https://lh3.googleusercontent.com/aida-public/AB6AXuBpwSHQc03TXVYK1QsB7iQqSCZxuHcmkU7ekzWAvh42wUCZhvjWyRmOmKlRWtdWogqBe3QOhQwuk7HmhmG23Gv--x43R6QCsxVmtohkg5k6Msx0yH2GphKnfXVcUkPWYhNxQjLkSut293GwzjfqiH1mOO7MRW2_oy33SrDtcijL1z1ejfEGebYYqzhB2rUQjLOpGr7dync_-yGK1qhD5_IWXpeDrJ-skfcJ3dx6LOFTcrr9WvwOPUOeKA" />
                  <div className="absolute inset-0 card-gradient opacity-80"></div>
                  <div className="absolute top-sm right-sm">
                    <button className={wishClass("w-8 h-8 rounded-full bg-surface-container/50 backdrop-blur-sm flex items-center justify-center text-primary hover:bg-primary/20 transition-colors", isSaved("ahimsa-eri-shawl"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["ahimsa-eri-shawl"]); }}>
                      <span className="material-symbols-outlined text-[18px]">
                        {isSaved("ahimsa-eri-shawl") ? "favorite" : "favorite_border"}
                      </span>
                    </button>
                  </div>
                  <div className="absolute bottom-sm left-sm right-sm flex items-end justify-between gap-xs">
                    <div className="font-label-caps text-label-caps px-2 py-1 bg-surface-container-high/80 backdrop-blur-md text-on-surface inline-block border-[0.5px] border-outline/30 uppercase">
                      Eri Silk
                    </div>
                    <button className="shrink-0 w-8 h-8 rounded-full bg-primary text-on-primary flex items-center justify-center hover:bg-gold-tint transition-colors" aria-label="Add to bag" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["ahimsa-eri-shawl"]); }}>
                      <span className="material-symbols-outlined text-[18px]">
                        shopping_bag
                      </span>
                    </button>
                  </div>
                </div>
                <div className="pt-sm flex flex-col gap-xs">
                  <h3 className="font-body-lg text-body-lg text-primary group-hover:text-gold-bright transition-colors truncate">
                    Ahimsa Eri Shawl
                  </h3>
                  <p className="font-label-caps text-label-caps text-on-surface-variant">
                    ₹ 32,000
                  </p>
                </div>
              </div>
              <div className="group cursor-pointer relative flex flex-col" data-product data-product-id="emerald-zari-mekhela" data-product-name="Emerald Zari Mekhela" data-product-price="65000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuBqH3OTmP6cl6S-16EP64lnOLcb1N7082nN9Wpq94-H58f5ijGrBqwN0npLzY-L6HZCzNiV0VNmho7T4LbB1pwYNZWffrwcLSxHC_YNbJdK9DN_PGzKzSwQ3xvJ0Oh2M4_ADf_mRmErtzeLh2-WW6OIeSgpd6th2RXFKI9ZlnDnpHDVQehqCapfhrAAX8JxV4vR-oQHj6ZfeNeP1nPGw2aCnCRKRisTbRiYjvFab65nCUD3xtvN16eJsg">
                <div className="relative w-full aspect-[3/4] overflow-hidden bg-gradient-to-b from-surface-container to-surface-container-high rounded-sm border-[0.5px] border-outline/20">
                  <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" data-alt="A close-up fashion shot focusing on the ornate blouse and upper draping of a contemporary Mekhela Chador interpretation. The fabric is a deep, saturated emerald green with heavy gold zari work. The model is partially visible, styled with antique gold jewelry. The high-contrast dark mode aesthetic highlights the richness of the South Asian maximalist design against a pure black background." src="https://lh3.googleusercontent.com/aida-public/AB6AXuBqH3OTmP6cl6S-16EP64lnOLcb1N7082nN9Wpq94-H58f5ijGrBqwN0npLzY-L6HZCzNiV0VNmho7T4LbB1pwYNZWffrwcLSxHC_YNbJdK9DN_PGzKzSwQ3xvJ0Oh2M4_ADf_mRmErtzeLh2-WW6OIeSgpd6th2RXFKI9ZlnDnpHDVQehqCapfhrAAX8JxV4vR-oQHj6ZfeNeP1nPGw2aCnCRKRisTbRiYjvFab65nCUD3xtvN16eJsg" />
                  <div className="absolute inset-0 card-gradient opacity-80"></div>
                  <div className="absolute top-sm right-sm">
                    <button className={wishClass("w-8 h-8 rounded-full bg-surface-container/50 backdrop-blur-sm flex items-center justify-center text-primary hover:bg-primary/20 transition-colors", isSaved("emerald-zari-mekhela"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["emerald-zari-mekhela"]); }}>
                      <span className="material-symbols-outlined text-[18px]">
                        {isSaved("emerald-zari-mekhela") ? "favorite" : "favorite_border"}
                      </span>
                    </button>
                  </div>
                  <div className="absolute bottom-sm left-sm right-sm flex items-end justify-between gap-xs">
                    <div className="font-label-caps text-label-caps px-2 py-1 bg-surface-container-high/80 backdrop-blur-md text-on-surface inline-block border-[0.5px] border-outline/30 uppercase">
                      Couture
                    </div>
                    <button className="shrink-0 w-8 h-8 rounded-full bg-primary text-on-primary flex items-center justify-center hover:bg-gold-tint transition-colors" aria-label="Add to bag" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["emerald-zari-mekhela"]); }}>
                      <span className="material-symbols-outlined text-[18px]">
                        shopping_bag
                      </span>
                    </button>
                  </div>
                </div>
                <div className="pt-sm flex flex-col gap-xs">
                  <h3 className="font-body-lg text-body-lg text-primary group-hover:text-gold-bright transition-colors truncate">
                    Emerald Zari Mekhela
                  </h3>
                  <p className="font-label-caps text-label-caps text-on-surface-variant">
                    ₹ 65,000
                  </p>
                </div>
              </div>
            </div>
            <div className="w-full flex justify-center mt-xl">
              <button className="px-lg py-sm border border-gold-muted text-primary font-label-caps text-label-caps uppercase hover:bg-surface-container-high/50 transition-colors duration-300">
                View All Collections
              </button>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}
