// Raw Node http module: request/response lifecycle and manual routing (no Express).
// Run: node examples/04-http-server.js   then open http://localhost:4000/products
const http = require("http");
const products = require("../data/products.json");

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  console.log(req.method, url.pathname);

  if (req.method === "GET" && url.pathname === "/") {
    res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
    return res.end("RIWAAZ raw http server");
  }
  if (req.method === "GET" && url.pathname === "/products") {
    res.writeHead(200, { "Content-Type": "application/json" });
    return res.end(JSON.stringify(products.map(({ id, name, price }) => ({ id, name, price }))));
  }
  if (req.method === "POST" && url.pathname === "/echo") {
    let body = ""; // the request is a readable stream
    req.on("data", (chunk) => (body += chunk));
    req.on("end", () => {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ youSent: JSON.parse(body || "{}") }));
    });
    return;
  }
  res.writeHead(404, { "Content-Type": "application/json" });
  res.end(JSON.stringify({ message: "Not found" }));
});

server.listen(4000, () => console.log("http://localhost:4000"));
