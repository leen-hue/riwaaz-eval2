import { useUI } from "../context/UIContext";

export default function Toast() {
  const { toasts } = useUI();
  return (
    <>
      {toasts.map((t) => (
        <div
          key={t.id}
          className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[9999] bg-primary text-on-primary font-label-caps text-label-caps px-6 py-3 rounded-full shadow-lg transition-opacity duration-300"
          style={{ opacity: t.visible ? 1 : 0 }}
        >
          {t.message}
        </div>
      ))}
    </>
  );
}
