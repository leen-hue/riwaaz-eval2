import { useShop } from "../context/ShopContext";
import { useUI } from "../context/UIContext";
import { formatINR } from "../utils/format";

export default function WishlistPanel() {
  const { wishlist, removeFromWishlist, moveWishlistItemToBag } = useShop();
  const { closeModal } = useUI();
  return (
    <>
      <div className="flex justify-between items-center mb-md">
        <h2 className="font-headline-md text-headline-md text-on-surface">Your Wishlist</h2>
        <button className="text-on-surface-variant hover:text-primary" onClick={closeModal} aria-label="Close">
          <span className="material-symbols-outlined">close</span>
        </button>
      </div>
      <div className="flex flex-col gap-sm">
        {wishlist.length === 0 && (
          <p className="font-body-md text-body-md text-on-surface-variant text-center py-lg">Your wishlist is empty.</p>
        )}
        {wishlist.map((item) => (
          <div key={item.id} className="flex gap-sm items-center border-b-[0.5px] border-outline/10 pb-sm">
            <img src={item.image} alt={item.name} className="w-14 h-18 object-cover rounded shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="font-body-md text-body-md text-on-surface truncate">{item.name}</p>
              <p className="font-label-caps text-label-caps text-gold-muted">{formatINR(item.price)}</p>
            </div>
            <button
              className="font-label-caps text-label-caps text-primary hover:text-gold-tint uppercase"
              onClick={() => moveWishlistItemToBag(item)}
            >
              Add to Bag
            </button>
            <button className="text-on-surface-variant hover:text-error" onClick={() => removeFromWishlist(item.id)} aria-label="Remove">
              <span className="material-symbols-outlined text-[18px]">delete</span>
            </button>
          </div>
        ))}
      </div>
    </>
  );
}
