const jwt = require("jsonwebtoken");
const User = require("../models/User");
const HttpError = require("../utils/httpError");
const asyncHandler = require("../utils/asyncHandler");

function readToken(req) {
  if (req.cookies && req.cookies.token) return req.cookies.token;
  const header = req.headers.authorization || "";
  return header.startsWith("Bearer ") ? header.slice(7) : null;
}

async function userFromRequest(req) {
  const token = readToken(req);
  if (!token) return null;
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    // Always re-read the user so deleted accounts / role changes take effect immediately.
    return await User.findById(payload.sub);
  } catch {
    return null;
  }
}

// Authentication: who are you?
exports.requireAuth = asyncHandler(async (req, res, next) => {
  const user = await userFromRequest(req);
  if (!user) throw new HttpError(401, "Please log in to continue.");
  req.user = user;
  next();
});

exports.optionalAuth = asyncHandler(async (req, res, next) => {
  req.user = await userFromRequest(req);
  next();
});
