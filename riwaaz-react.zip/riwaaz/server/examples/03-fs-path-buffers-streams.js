// fs, path, Buffer, Streams, EventEmitter, error handling
// Run: node examples/03-fs-path-buffers-streams.js
const fs = require("fs");
const path = require("path");
const { EventEmitter } = require("events");
const { pipeline } = require("stream/promises");
const { Transform } = require("stream");

const out = path.join(__dirname, "..", "logs", "demo.txt");
console.log("path:", path.basename(out), path.extname(out), path.dirname(out) === path.join(__dirname, "..", "logs"));

// Buffers
const buf = Buffer.from("Riwaaz ₹", "utf8");
console.log("buffer bytes:", buf.length, buf.toString("hex"), "->", buf.toString());

// Streams: read products.json, upper-case it chunk by chunk, write it out
const upper = new Transform({ transform(chunk, enc, cb) { cb(null, chunk.toString().toUpperCase()); } });
(async () => {
  try {
    await pipeline(fs.createReadStream(path.join(__dirname, "..", "data", "products.json")), upper, fs.createWriteStream(out));
    console.log("stream pipeline finished ->", fs.statSync(out).size, "bytes");
    fs.unlinkSync(out);
    fs.readFileSync(path.join(__dirname, "missing.txt")); // throws ENOENT
  } catch (err) {
    console.log("handled error:", err.code);
  }
})();

// EventEmitter
const shop = new EventEmitter();
shop.once("sale", (item) => console.log("event: sale on", item));
shop.on("error", (e) => console.log("event: error handled ->", e.message));
shop.emit("sale", "lehengas");
shop.emit("error", new Error("out of stock"));
