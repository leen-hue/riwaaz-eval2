const Message = require("../models/Message");
const asyncHandler = require("../utils/asyncHandler");
const events = require("../utils/events");
const { contact } = require("../utils/validators");

exports.create = asyncHandler(async (req, res) => {
  const msg = await Message.create(contact(req.body));
  events.emit("contact:received", msg);
  res.status(201).json({ ok: true });
});

exports.list = asyncHandler(async (req, res) => {
  res.json({ messages: await Message.find().sort({ createdAt: -1 }).limit(200) });
});
