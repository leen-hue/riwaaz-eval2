export function formatINR(amount) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(Number(amount) || 0);
}

// Same highlight the old highlightActiveNavLink() applied.
export function navClass(base, active) {
  if (!active) return base;
  return (
    base.replace("text-on-surface-variant", "").replace(/\s+/g, " ").trim() +
    " text-primary border-b-2 border-primary pb-1"
  );
}

// Heart button colour: red when saved (mirrors old refreshWishlistIcons()).
export function wishClass(base, saved) {
  if (!saved) return base;
  return base.replace(/text-on-surface(-variant)?/g, "").replace(/\s+/g, " ").trim() + " text-error";
}
