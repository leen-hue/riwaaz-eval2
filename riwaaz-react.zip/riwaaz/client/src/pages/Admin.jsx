import { useCallback, useEffect, useState } from "react";
import api, { errorMessage } from "../api/client";
import { useUI } from "../context/UIContext";
import { formatINR } from "../utils/format";
import { meta as homeMeta } from "./Home";

export const meta = { ...homeMeta, page: "admin", route: "/admin", title: "Admin — RIWAAZ" };

const field =
  "w-full bg-surface-container rounded-DEFAULT border-[0.5px] border-outline/30 px-sm py-xs font-body-md text-on-surface focus:outline-none focus:border-primary";
const label = "font-label-caps text-label-caps text-on-surface-variant block mb-xs";
const btn =
  "gold-gradient-bg text-on-primary font-label-caps text-label-caps uppercase tracking-widest px-md py-sm rounded-DEFAULT disabled:opacity-60";

export default function Admin() {
  const { showToast } = useUI();
  const [products, setProducts] = useState([]);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const res = await api.get("/products");
      setProducts(res.data.products);
    } catch (err) {
      showToast(errorMessage(err));
    }
  }, [showToast]);

  useEffect(() => {
    load();
  }, [load]);

  async function submit(e, url, okMessage) {
    e.preventDefault();
    const form = e.target;
    const fd = new FormData(form); // includes the image file for multer
    setBusy(true);
    try {
      await api.post(url, fd);
      showToast(okMessage);
      form.reset();
      load();
    } catch (err) {
      showToast(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  async function remove(p) {
    if (!window.confirm(`Delete "${p.name}"?`)) return;
    try {
      await api.delete(`/products/${p.id}`);
      showToast("Product deleted");
      load();
    } catch (err) {
      showToast(errorMessage(err));
    }
  }

  return (
    <main className="max-w-[1920px] mx-auto px-margin-mobile md:px-margin-desktop py-lg flex flex-col gap-xl">
      <h1 className="font-display-lg text-display-lg text-primary text-glow">Admin Dashboard</h1>

      <section className="grid grid-cols-1 lg:grid-cols-2 gap-lg">
        <form
          onSubmit={(e) => submit(e, "/products", "Product saved")}
          className="bg-surface-container-low border-[0.5px] border-outline/30 rounded-lg p-md flex flex-col gap-sm"
        >
          <h2 className="font-headline-md text-headline-md text-on-surface">Add product</h2>
          <div><label className={label}>Product ID (slug)</label><input name="productId" required pattern="[a-z0-9-]+" placeholder="velvet-zardozi-potli" className={field} /></div>
          <div><label className={label}>Name</label><input name="name" required className={field} /></div>
          <div className="grid grid-cols-2 gap-sm">
            <div><label className={label}>Price (₹)</label><input name="price" type="number" min="0" required className={field} /></div>
            <div><label className={label}>Category</label><input name="category" placeholder="north-indian" className={field} /></div>
          </div>
          <div><label className={label}>Description</label><textarea name="description" rows="2" className={field} /></div>
          <div><label className={label}>Image (JPG, PNG or WebP, max 5 MB)</label><input name="image" type="file" accept="image/jpeg,image/png,image/webp" required className={field} /></div>
          <button className={btn + " self-start"} disabled={busy}>Save product</button>
        </form>

        <form
          onSubmit={(e) => submit(e, "/auctions", "Auction lot created")}
          className="bg-surface-container-low border-[0.5px] border-outline/30 rounded-lg p-md flex flex-col gap-sm"
        >
          <h2 className="font-headline-md text-headline-md text-on-surface">Schedule auction lot</h2>
          <div><label className={label}>Title</label><input name="title" required className={field} /></div>
          <div><label className={label}>Description</label><textarea name="description" rows="2" className={field} /></div>
          <div className="grid grid-cols-2 gap-sm">
            <div><label className={label}>Base price (₹)</label><input name="basePrice" type="number" min="1" required className={field} /></div>
            <div><label className={label}>Bid increment (₹)</label><input name="increment" type="number" min="1" required className={field} /></div>
          </div>
          <div><label className={label}>Starts at (leave empty to go live now)</label><input name="startsAt" type="datetime-local" className={field} /></div>
          <div><label className={label}>Image</label><input name="image" type="file" accept="image/jpeg,image/png,image/webp" className={field} /></div>
          <button className={btn + " self-start"} disabled={busy}>Create lot</button>
        </form>
      </section>

      <section>
        <h2 className="font-headline-md text-headline-md text-on-surface mb-md">Products ({products.length})</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 gap-md">
          {products.map((p) => (
            <div key={p.id} className="bg-surface-container-low border-[0.5px] border-outline/20 rounded-lg overflow-hidden flex flex-col">
              <img src={p.image} alt={p.name} className="aspect-[3/4] object-cover w-full" />
              <div className="p-sm flex flex-col gap-xs flex-1">
                <p className="font-body-md text-body-md text-on-surface truncate">{p.name}</p>
                <p className="font-label-caps text-label-caps text-gold-muted">{formatINR(p.price)}</p>
                <button onClick={() => remove(p)} className="mt-auto text-left font-label-caps text-label-caps text-on-surface-variant hover:text-error">
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
