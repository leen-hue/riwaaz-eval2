const HttpError = require("./httpError");

const str = (v, max = 200) => (typeof v === "string" ? v.trim().slice(0, max) : "");

// Throws a 400 with the first problem found.
exports.shipping = (body = {}) => {
  const s = {
    fullName: str(body.fullName, 80),
    phone: str(body.phone, 15),
    address: str(body.address, 250),
    city: str(body.city, 80),
    pincode: str(body.pincode, 6),
  };
  if (!s.fullName) throw new HttpError(400, "Full name is required.");
  if (!/^[6-9]\d{9}$/.test(s.phone)) throw new HttpError(400, "Enter a valid 10-digit Indian mobile number.");
  if (s.address.length < 8) throw new HttpError(400, "Please enter your full address.");
  if (!s.city) throw new HttpError(400, "City is required.");
  if (!/^\d{6}$/.test(s.pincode)) throw new HttpError(400, "Enter a valid 6-digit PIN code.");
  return s;
};

exports.contact = (body = {}) => {
  const m = { name: str(body.name, 80), email: str(body.email, 120).toLowerCase(), message: str(body.message, 2000) };
  if (!m.name) throw new HttpError(400, "Please enter your name.");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(m.email)) throw new HttpError(400, "Please enter a valid email address.");
  if (m.message.length < 10) throw new HttpError(400, "Message should be at least 10 characters.");
  return m;
};
