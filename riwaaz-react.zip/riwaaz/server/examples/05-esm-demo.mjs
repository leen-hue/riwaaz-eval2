// ES Modules (import/export, top-level await) vs CommonJS (require/module.exports).
// Run: node examples/05-esm-demo.mjs
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";

const __dirname = path.dirname(fileURLToPath(import.meta.url)); // not available by default in ESM
const require = createRequire(import.meta.url); // use CommonJS from ESM

const products = JSON.parse(await readFile(path.join(__dirname, "../data/products.json"), "utf8"));
const { EventEmitter } = require("events");
console.log(products.length, "products; EventEmitter from CJS:", typeof EventEmitter);
console.log("global objects: process.argv.length =", process.argv.length, "| __filename undefined in ESM:", typeof __filename);
