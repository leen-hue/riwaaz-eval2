import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useUI } from "../context/UIContext";

const inputCls =
  "w-full bg-surface-container rounded-DEFAULT border-[0.5px] border-outline/30 px-sm py-xs font-body-md text-on-surface focus:outline-none focus:border-primary";

export default function AccountPanel() {
  const { user, login, signUp, logout, isAdmin } = useAuth();
  const { closeModal, showToast } = useUI();
  const [mode, setMode] = useState("login"); // "login" | "signup"
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const isSignup = mode === "signup";

  const Header = ({ title }) => (
    <div className="flex justify-between items-center mb-md">
      <h2 className="font-headline-md text-headline-md text-on-surface">{title}</h2>
      <button className="text-on-surface-variant hover:text-primary" onClick={closeModal} aria-label="Close">
        <span className="material-symbols-outlined">close</span>
      </button>
    </div>
  );

  if (user) {
    return (
      <>
        <Header title="Your Account" />
        <p className="font-body-md text-body-md text-on-surface mb-xs">
          Signed in as <span className="text-gold-muted">{user.name}</span>
        </p>
        <p className="font-label-caps text-label-caps text-on-surface-variant mb-lg">{user.email}</p>
        <Link
          to="/orders"
          onClick={closeModal}
          className="block text-center w-full border border-outline/40 text-on-surface font-label-caps text-label-caps uppercase tracking-widest py-sm rounded-DEFAULT mb-sm hover:border-primary hover:text-primary transition-colors"
        >
          My Orders
        </Link>
        {isAdmin && (
          <Link
            to="/admin"
            onClick={closeModal}
            className="block text-center w-full border border-outline/40 text-on-surface font-label-caps text-label-caps uppercase tracking-widest py-sm rounded-DEFAULT mb-sm hover:border-primary hover:text-primary transition-colors"
          >
            Admin Dashboard
          </Link>
        )}
        <button
          className="w-full border border-primary text-primary font-label-caps text-label-caps uppercase tracking-widest py-sm rounded-DEFAULT hover:bg-primary hover:text-on-primary transition-colors"
          onClick={async () => {
            await logout();
            showToast("You've been logged out");
            closeModal();
          }}
        >
          Log Out
        </button>
      </>
    );
  }

  async function handleSubmit(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = { name: fd.get("name"), email: fd.get("email"), password: fd.get("password") };
    setSubmitting(true);
    const result = isSignup ? await signUp(payload) : await login(payload);
    setSubmitting(false);
    if (!result.ok) return setError(result.message);
    showToast(isSignup ? `Welcome, ${result.user.name}!` : `Welcome back, ${result.user.name}!`);
    closeModal();
  }

  return (
    <>
      <Header title={isSignup ? "Create Account" : "Log In"} />
      <form className="flex flex-col gap-sm" onSubmit={handleSubmit}>
        {isSignup && <input type="text" name="name" placeholder="Full name" required className={inputCls} />}
        <input type="email" name="email" placeholder="Email" required className={inputCls} />
        <input type="password" name="password" placeholder="Password" required minLength={isSignup ? 8 : undefined} className={inputCls} />
        {error && <p className="font-label-caps text-label-caps text-error">{error}</p>}
        <button
          type="submit"
          disabled={submitting}
          className="w-full gold-gradient-bg text-on-primary font-label-caps text-label-caps uppercase tracking-widest py-sm rounded-DEFAULT mt-xs disabled:opacity-60"
        >
          {isSignup ? "Sign Up" : "Log In"}
        </button>
      </form>
      <p className="font-body-md text-body-md text-on-surface-variant text-center mt-md">
        <span>{isSignup ? "Already have an account?" : "New here?"}</span>{" "}
        <button
          type="button"
          className="text-primary hover:text-gold-tint underline"
          onClick={() => {
            setMode(isSignup ? "login" : "signup");
            setError("");
          }}
        >
          {isSignup ? "Log in" : "Create an account"}
        </button>
      </p>
    </>
  );
}
