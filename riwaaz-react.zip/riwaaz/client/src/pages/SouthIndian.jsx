import { PRODUCTS } from "../data/products";
import { useShop } from "../context/ShopContext";
import { formatINR, wishClass } from "../utils/format";

export const meta = { page: "south-indian", route: "/south-indian", title: "The South Indian Edit - VEDA", bodyClass: "antialiased min-h-screen flex flex-col" };

export default function SouthIndian() {
  const { addToBag, toggleWishlist, isSaved } = useShop();
  return (
    <>
      <main className="flex-grow flex flex-col">
        <section className="relative w-full h-[614px] md:h-[716px] flex items-center justify-center overflow-hidden border-b-[0.5px] border-outline/30">
          <div className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-40 mix-blend-overlay" data-alt="A cinematic, wide-angle shot of a majestic South Indian temple corridor draped in rich crimson and gold Kanjeevaram silks. The lighting is dramatic, with shafts of golden sunlight piercing through the ancient stone pillars, illuminating the intricate zari work on the fabrics. The aesthetic is deep, moody, and palatial, embodying Desi Maximalism. The color palette revolves around dark ruby reds, deep blacks, and brilliant gold accents. The atmosphere is solemn, opulent, and steeped in heritage luxury." style={{backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuCwimy7sn41yFKoe4utfClwtiW4dAU7e2QdWB7qklqgEVMptWog-FJZCQLcdu1op8r3a1dq4Bl_OY1baE3hk6l7JPGJ5JVrp7B6hnXlspxVPbsg5kY63sJzkJrmFVlJRGptqCQPaWaFzukqt6kPXRaPzmFBJvJFq1yhqkxmNigi5vxXBnqme4o5w18fSx3FYUWLogobJJy5XWKj6RvkS5KdobFTEl_nErpV9mlljeSu3QeJDASaDqalmA')"}}></div>
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent"></div>
          <div className="relative z-10 text-center px-margin-mobile md:px-margin-desktop max-w-4xl mx-auto flex flex-col items-center">
            <span className="font-label-caps text-label-caps text-gold-muted mb-sm tracking-[0.2em]">
              CURATED COLLECTION
            </span>
            <h1 className="font-display-lg text-display-lg text-primary mb-md gold-text-gradient">
              The South Indian Edit
            </h1>
            <p className="font-body-lg text-body-lg text-on-surface-variant max-w-2xl mx-auto mb-lg">
              An opulent journey through the storied weaves of Kanchipuram and the intricate artistry of temple filigree. Experience Desi Maximalism draped in heavy silks, deep jewel tones, and ancestral motifs.
            </p>
          </div>
        </section>
        <section className="px-margin-mobile md:px-margin-desktop py-xl max-w-[1920px] mx-auto w-full flex flex-col md:flex-row gap-lg backdrop-blur-sm bg-background/40 rounded-xl my-lg border border-outline/10">
          <aside className="hidden md:block w-64 flex-shrink-0 sticky top-32 h-[calc(100vh-120px)] overflow-y-auto hide-scrollbar border-r-[0.5px] border-outline/20 pr-md pt-md">
            <div className="mb-lg">
              <h3 className="font-headline-md text-headline-md text-primary mb-md pb-xs border-b-[0.5px] border-outline/30">
                Category
              </h3>
              <ul className="space-y-sm font-body-md text-body-md text-on-surface-variant">
                <li className="">
                  <label className="flex items-center space-x-3 cursor-pointer group">
                    <input defaultChecked className="form-checkbox bg-surface-container border-outline/50 text-gold-bright focus:ring-gold-muted rounded-DEFAULT" type="checkbox" />
                    <span className="group-hover:text-primary transition-colors">
                      Kanjeevaram Sarees
                    </span>
                  </label>
                </li>
                <li className="">
                  <label className="flex items-center space-x-3 cursor-pointer group">
                    <input className="form-checkbox bg-surface-container border-outline/50 text-gold-bright focus:ring-gold-muted rounded-DEFAULT" type="checkbox" />
                    <span className="group-hover:text-primary transition-colors">
                      Veshtis & Dhotis
                    </span>
                  </label>
                </li>
                <li className="">
                  <label className="flex items-center space-x-3 cursor-pointer group">
                    <input className="form-checkbox bg-surface-container border-outline/50 text-gold-bright focus:ring-gold-muted rounded-DEFAULT" type="checkbox" />
                    <span className="group-hover:text-primary transition-colors">
                      Temple Jewelry
                    </span>
                  </label>
                </li>
                <li className="">
                  <label className="flex items-center space-x-3 cursor-pointer group">
                    <input className="form-checkbox bg-surface-container border-outline/50 text-gold-bright focus:ring-gold-muted rounded-DEFAULT" type="checkbox" />
                    <span className="group-hover:text-primary transition-colors">
                      Silk Angavastrams
                    </span>
                  </label>
                </li>
              </ul>
            </div>
            <div className="mb-lg">
              <h3 className="font-headline-md text-headline-md text-primary mb-md pb-xs border-b-[0.5px] border-outline/30">
                Color
              </h3>
              <div className="flex flex-wrap gap-sm">
                <button aria-label="Maroon" className="w-8 h-8 rounded-full bg-deep-maroon border-2 border-primary focus:outline-none focus:ring-2 focus:ring-gold-muted focus:ring-offset-2 focus:ring-offset-background"></button>
                <button aria-label="Deep Green" className="w-8 h-8 rounded-full bg-[#003732] border border-outline/30 focus:outline-none focus:ring-2 focus:ring-gold-muted focus:ring-offset-2 focus:ring-offset-background"></button>
                <button aria-label="Gold" className="w-8 h-8 rounded-full bg-[#d4af37] border border-outline/30 focus:outline-none focus:ring-2 focus:ring-gold-muted focus:ring-offset-2 focus:ring-offset-background"></button>
                <button aria-label="Black" className="w-8 h-8 rounded-full bg-surface-container border border-outline/30 focus:outline-none focus:ring-2 focus:ring-gold-muted focus:ring-offset-2 focus:ring-offset-background"></button>
              </div>
            </div>
            <div className="mb-lg">
              <h3 className="font-headline-md text-headline-md text-primary mb-md pb-xs border-b-[0.5px] border-outline/30">
                Price Range
              </h3>
              <div className="flex flex-col space-y-md">
                <input className="w-full h-1 bg-surface-container-high rounded-lg appearance-none cursor-pointer accent-gold-muted" max="100" min="0" type="range" defaultValue="70" />
                <div className="flex justify-between font-label-caps text-label-caps text-on-surface-variant">
                  <span className="">
                    $500
                  </span>
                  <span className="">
                    $5,000+
                  </span>
                </div>
              </div>
            </div>
          </aside>
          <div className="flex-grow pt-md">
            <div className="md:hidden flex justify-between items-center mb-md border-b-[0.5px] border-outline/30 pb-sm">
              <span className="font-body-md text-body-md text-on-surface-variant">
                12 Items
              </span>
              <button className="flex items-center space-x-xs font-label-caps text-label-caps text-primary border border-outline/30 px-sm py-xs rounded-DEFAULT">
                <span className="material-symbols-outlined text-[16px]" data-icon="tune">
                  tune
                </span>
                <span className="">
                  FILTERS
                </span>
              </button>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-md md:gap-lg auto-rows-[300px] md:auto-rows-[400px]">
              <div className="col-span-2 row-span-2 group relative overflow-hidden rounded-lg bg-surface-container-low border border-outline/10 cursor-pointer shadow-lg shadow-black/20" data-product data-product-id="rajarajeshwari-drape" data-product-name="The Rajarajeshwari Drape" data-product-price="270000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuDSvGb1zzEMRLeYXMKt1iNx8ZQeADZozBnRto5zBcE_X15KZFF2CVXoJChKoZ0m9VCl3putvc2f1pFYTJLQV-OzJ_ibGB010B3q2adi5i0EiA6n8S38xhkIf2Resy9QV0YnPITMm0KNfMohVR3ftwWrn3RUj-QUi2zUmL2_YYTjtd-m0mRMdBxNkRQwa1GYTkbSzh3_kDGAJbQBKZI7VJW_3GYbWv8_9_yk5C-0cSW9oH4DmxSxYjhYLQ">
                <img className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" data-alt="A stunning, full-length portrait of a model wearing a heavy, dark maroon Kanjeevaram silk saree with expansive, intricate gold zari borders featuring traditional peacock and mango motifs. The model is adorned with authentic antique gold temple jewelry, including a heavy choker and long haram. The background is a moody, dark palace interior lit by warm, ambient golden light. The style is Desi Maximalist, rich, tactile, and highly detailed, emphasizing the weight and sheen of the silk." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDSvGb1zzEMRLeYXMKt1iNx8ZQeADZozBnRto5zBcE_X15KZFF2CVXoJChKoZ0m9VCl3putvc2f1pFYTJLQV-OzJ_ibGB010B3q2adi5i0EiA6n8S38xhkIf2Resy9QV0YnPITMm0KNfMohVR3ftwWrn3RUj-QUi2zUmL2_YYTjtd-m0mRMdBxNkRQwa1GYTkbSzh3_kDGAJbQBKZI7VJW_3GYbWv8_9_yk5C-0cSW9oH4DmxSxYjhYLQ" />
                <div className="absolute inset-0 bg-gradient-to-t from-background/95 via-background/40 to-transparent"></div>
                <button className={wishClass("absolute top-sm right-sm text-primary/70 hover:text-primary transition-colors p-xs backdrop-blur-sm bg-surface/30 rounded-full", isSaved("rajarajeshwari-drape"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["rajarajeshwari-drape"]); }}>
                  <span className="material-symbols-outlined" data-icon="favorite_border">
                    {isSaved("rajarajeshwari-drape") ? "favorite" : "favorite_border"}
                  </span>
                </button>
                <div className="absolute bottom-0 left-0 w-full p-md">
                  <span className="font-label-caps text-label-caps text-gold-muted mb-xs block">
                    KANJEEVARAM
                  </span>
                  <h3 className="font-headline-md text-headline-md text-primary mb-xs">
                    The Rajarajeshwari Drape
                  </h3>
                  <p className="font-body-md text-body-md text-on-surface-variant mb-sm line-clamp-2">
                    A masterpiece in deep maroon silk woven with pure gold zari threads, depicting palatial narratives.
                  </p>
                  <span className="font-body-lg text-body-lg text-primary">
                    ₹2,70,000
                  </span>
                  <button className="mt-sm px-md py-xs bg-primary text-on-primary font-label-caps text-label-caps uppercase tracking-widest rounded-full hover:bg-gold-tint transition-colors" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["rajarajeshwari-drape"]); }}>
                    Add to Bag
                  </button>
                </div>
              </div>
              <div className="col-span-1 row-span-1 group relative overflow-hidden rounded-lg bg-surface-container-low border border-outline/10 cursor-pointer shadow-lg shadow-black/20" data-product data-product-id="lakshmi-heritage-choker" data-product-name="Lakshmi Heritage Choker" data-product-price="155000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuDoD7sFSdcYmUwMpG8cIUYGc0GLvKNhg4koat1-URz51HSkZInyx2C-dJOi0QLSyA9DHrH8Ik0ZMxPh48LgH3TNHbz0vOUara4HkGlaOoLOa2QIAZxK5NBerSt7Vuv1fIZnfhVeleDHxtAIHpcuIdgzzHBPFfoil5Gjk0eumL9P35dnOGlg0Ezx3gVt_Y4y1dxkmTQLc8WCKPuT6Qd73MLAIausm9KJivt9Cq3av4-F1cdbqd0Wun6mcg">
                <img className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" data-alt="A close-up studio shot of an ornate, antique-finish gold choker necklace intricately carved with depictions of deities and lotus flowers, characteristic of South Indian temple jewelry. The necklace rests on a dark, textured velvet surface. The lighting highlights the tactile, raised filigree details and the muted, rich tone of the gold against the deep black background. The mood is luxurious, historical, and opulent." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDoD7sFSdcYmUwMpG8cIUYGc0GLvKNhg4koat1-URz51HSkZInyx2C-dJOi0QLSyA9DHrH8Ik0ZMxPh48LgH3TNHbz0vOUara4HkGlaOoLOa2QIAZxK5NBerSt7Vuv1fIZnfhVeleDHxtAIHpcuIdgzzHBPFfoil5Gjk0eumL9P35dnOGlg0Ezx3gVt_Y4y1dxkmTQLc8WCKPuT6Qd73MLAIausm9KJivt9Cq3av4-F1cdbqd0Wun6mcg" />
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent"></div>
                <button className={wishClass("absolute top-sm right-sm text-primary/70 hover:text-primary transition-colors p-xs backdrop-blur-sm bg-surface/30 rounded-full", isSaved("lakshmi-heritage-choker"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["lakshmi-heritage-choker"]); }}>
                  <span className="material-symbols-outlined" data-icon="favorite_border">
                    {isSaved("lakshmi-heritage-choker") ? "favorite" : "favorite_border"}
                  </span>
                </button>
                <div className="absolute bottom-0 left-0 w-full p-sm">
                  <h3 className="font-headline-md text-headline-md text-primary mb-xs text-[18px] leading-tight">
                    Lakshmi Heritage Choker
                  </h3>
                  <span className="font-body-md text-body-md text-on-surface-variant">
                    ₹1,55,000
                  </span>
                  <button className="mt-xs px-sm py-[2px] border border-primary text-primary font-label-caps text-label-caps uppercase tracking-widest rounded-full hover:bg-primary hover:text-on-primary transition-colors block w-max" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["lakshmi-heritage-choker"]); }}>
                    Add to Bag
                  </button>
                </div>
              </div>
              <div className="col-span-1 row-span-1 group relative overflow-hidden rounded-lg bg-surface-container-low border border-outline/10 cursor-pointer shadow-lg shadow-black/20" data-product data-product-id="emerald-silk-veshti-set" data-product-name="Emerald & Silk Veshti Set" data-product-price="72000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuBPx5MiEoNL51QjxCUdBZFbTcSQOff-8b0_8lmu_gyBGhvYIgvazZQrYj8B02UPxynvXlZWw2MFrC76B1oqzLCS5goGyWykRKFC20SCYRDBTAS_zYhZSXdJcpTqahjcILmCW6tA6nj8eTuGTksoe8wdxhJu5iNvEf7KtQ2TXwuUH4UJiuEREOSfJcZOdrQfTl7YINVcUznjqVfKaXtMyF8-vI27fbFO0NJSpUbFblMOAUkumtZfW4P6dw">
                <img className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" data-alt="A male model elegantly draped in a pristine, cream-colored silk Veshti with a broad, luminous gold zari border. He is wearing a matching silk Angavastram over a deep emerald green raw silk kurta. The setting is a dimly lit, atmospheric heritage courtyard with dark wood pillars. The style is sophisticated, traditional yet styled with a modern, high-fashion dark mode aesthetic. The contrast between the bright silk and dark surroundings is striking." src="https://lh3.googleusercontent.com/aida-public/AB6AXuBPx5MiEoNL51QjxCUdBZFbTcSQOff-8b0_8lmu_gyBGhvYIgvazZQrYj8B02UPxynvXlZWw2MFrC76B1oqzLCS5goGyWykRKFC20SCYRDBTAS_zYhZSXdJcpTqahjcILmCW6tA6nj8eTuGTksoe8wdxhJu5iNvEf7KtQ2TXwuUH4UJiuEREOSfJcZOdrQfTl7YINVcUznjqVfKaXtMyF8-vI27fbFO0NJSpUbFblMOAUkumtZfW4P6dw" />
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent"></div>
                <button className={wishClass("absolute top-sm right-sm text-primary/70 hover:text-primary transition-colors p-xs backdrop-blur-sm bg-surface/30 rounded-full", isSaved("emerald-silk-veshti-set"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["emerald-silk-veshti-set"]); }}>
                  <span className="material-symbols-outlined" data-icon="favorite_border">
                    {isSaved("emerald-silk-veshti-set") ? "favorite" : "favorite_border"}
                  </span>
                </button>
                <div className="absolute bottom-0 left-0 w-full p-sm">
                  <h3 className="font-headline-md text-headline-md text-primary mb-xs text-[18px] leading-tight">
                    Emerald & Silk Veshti Set
                  </h3>
                  <span className="font-body-md text-body-md text-on-surface-variant">
                    ₹72,000
                  </span>
                  <button className="mt-xs px-sm py-[2px] border border-primary text-primary font-label-caps text-label-caps uppercase tracking-widest rounded-full hover:bg-primary hover:text-on-primary transition-colors block w-max" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["emerald-silk-veshti-set"]); }}>
                    Add to Bag
                  </button>
                </div>
              </div>
              <div className="col-span-1 row-span-1 group relative overflow-hidden rounded-lg bg-surface-container-low border border-outline/10 cursor-pointer shadow-lg shadow-black/20" data-product data-product-id="indigo-zari-weave" data-product-name="Indigo Zari Weave" data-product-price="180000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuDaXjntLrazzZ0qDsCqPuxl5SxUquJ41sQDdJ1m7BHxcTMjjrn7r23m9ZPAqF6mVuS-fk-TbkXq1FeO3fVrUZeZE5TPIvkVmCh_CElo7ZvdzwMvT6M4_IvMhsmMumLrs3TH7snz5PbD0GWGLfhLCFFtI6y1DraL2neL7F2KP2xoFb48yQ82W7rPtCf4P0lcJpNva1rf5MQRz9DVHe-jYgOW0SyImoolKxByM2X0ODUdaDgGjf5LK8X48Q">
                <img className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" data-alt="A detailed, macro view of the pallu (end piece) of a Kanchipuram silk saree. The silk base is a deep, majestic indigo blue, heavily ornamented with complex geometric and floral patterns woven in contrasting silver and gold zari. The lighting is low and directional, emphasizing the tactile, raised texture of the metallic threads against the smooth silk base. The overall aesthetic is dark, luxurious, and highly detailed." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDaXjntLrazzZ0qDsCqPuxl5SxUquJ41sQDdJ1m7BHxcTMjjrn7r23m9ZPAqF6mVuS-fk-TbkXq1FeO3fVrUZeZE5TPIvkVmCh_CElo7ZvdzwMvT6M4_IvMhsmMumLrs3TH7snz5PbD0GWGLfhLCFFtI6y1DraL2neL7F2KP2xoFb48yQ82W7rPtCf4P0lcJpNva1rf5MQRz9DVHe-jYgOW0SyImoolKxByM2X0ODUdaDgGjf5LK8X48Q" />
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent"></div>
                <button className={wishClass("absolute top-sm right-sm text-primary/70 hover:text-primary transition-colors p-xs backdrop-blur-sm bg-surface/30 rounded-full", isSaved("indigo-zari-weave"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["indigo-zari-weave"]); }}>
                  <span className="material-symbols-outlined" data-icon="favorite_border">
                    {isSaved("indigo-zari-weave") ? "favorite" : "favorite_border"}
                  </span>
                </button>
                <div className="absolute bottom-0 left-0 w-full p-sm">
                  <h3 className="font-headline-md text-headline-md text-primary mb-xs text-[18px] leading-tight">
                    Indigo Zari Weave
                  </h3>
                  <span className="font-body-md text-body-md text-on-surface-variant">
                    ₹1,80,000
                  </span>
                  <button className="mt-xs px-sm py-[2px] border border-primary text-primary font-label-caps text-label-caps uppercase tracking-widest rounded-full hover:bg-primary hover:text-on-primary transition-colors block w-max" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["indigo-zari-weave"]); }}>
                    Add to Bag
                  </button>
                </div>
              </div>
              <div className="col-span-1 row-span-1 group relative overflow-hidden rounded-lg bg-surface-container-low border border-outline/10 cursor-pointer shadow-lg shadow-black/20" data-product data-product-id="ruby-temple-armlets" data-product-name="Ruby Temple Armlets" data-product-price="100000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuDOO-l5QlAkIRs254eOX42fJVVsWmCgltF5sOgfJJuFLr1HhC2KVwXaNrO0ylwTcPSNf_e-hyCp6rV3HeumbEAt28WoyC294RyrKe4pH5gXCve01WzPj8wYovPhUZQcBpYXe-c9hbfXEjfVFFy3y8UBKMR8YrPO4uPXeXClkAcn9OT6rbzBoDySUVoFjSRFRq0GYSfq1A3YHn7NM6kX651jNggsJ82D5T8-WUZ2mmsgnPR6ng1hr6fUvA">
                <img className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" data-alt="An imposing set of heavy, gold Vanki (armlets) and matching bangles resting atop a piece of raw, unspun deep crimson silk. The jewelry features intricate repousse work typical of South Indian temple design, studded with unpolished rubies and emeralds. The scene is shot with a macro lens in a dark studio setting, using spotlighting to make the gold and jewels gleam intensely against the dark, textured fabric background." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDOO-l5QlAkIRs254eOX42fJVVsWmCgltF5sOgfJJuFLr1HhC2KVwXaNrO0ylwTcPSNf_e-hyCp6rV3HeumbEAt28WoyC294RyrKe4pH5gXCve01WzPj8wYovPhUZQcBpYXe-c9hbfXEjfVFFy3y8UBKMR8YrPO4uPXeXClkAcn9OT6rbzBoDySUVoFjSRFRq0GYSfq1A3YHn7NM6kX651jNggsJ82D5T8-WUZ2mmsgnPR6ng1hr6fUvA" />
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent"></div>
                <button className={wishClass("absolute top-sm right-sm text-primary/70 hover:text-primary transition-colors p-xs backdrop-blur-sm bg-surface/30 rounded-full", isSaved("ruby-temple-armlets"))} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(PRODUCTS["ruby-temple-armlets"]); }}>
                  <span className="material-symbols-outlined" data-icon="favorite_border">
                    {isSaved("ruby-temple-armlets") ? "favorite" : "favorite_border"}
                  </span>
                </button>
                <div className="absolute bottom-0 left-0 w-full p-sm">
                  <h3 className="font-headline-md text-headline-md text-primary mb-xs text-[18px] leading-tight">
                    Ruby Temple Armlets
                  </h3>
                  <span className="font-body-md text-body-md text-on-surface-variant">
                    ₹1,00,000
                  </span>
                  <button className="mt-xs px-sm py-[2px] border border-primary text-primary font-label-caps text-label-caps uppercase tracking-widest rounded-full hover:bg-primary hover:text-on-primary transition-colors block w-max" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["ruby-temple-armlets"]); }}>
                    Add to Bag
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}
