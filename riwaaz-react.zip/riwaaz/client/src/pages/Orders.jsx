import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api, { errorMessage } from "../api/client";
import { useShop } from "../context/ShopContext";
import { formatINR } from "../utils/format";
import { meta as homeMeta } from "./Home";

export const meta = { ...homeMeta, page: "orders", route: "/orders", title: "My Orders — RIWAAZ" };

export default function Orders() {
  const { items } = useShop(); // re-fetch when the cart changes (e.g. just after checkout)
  const [orders, setOrders] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    api
      .get("/orders/mine")
      .then((res) => !cancelled && setOrders(res.data.orders))
      .catch((err) => !cancelled && setError(errorMessage(err)));
    return () => {
      cancelled = true;
    };
  }, [items.length]);

  return (
    <main className="max-w-[1920px] mx-auto px-margin-mobile md:px-margin-desktop py-lg flex flex-col gap-md">
      <h1 className="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg">My Orders</h1>
      {error && <p className="text-error font-body-md">{error}</p>}
      {orders && orders.length === 0 && (
        <p className="font-body-md text-on-surface-variant">
          No orders yet. <Link to="/" className="text-primary underline">Start shopping</Link>
        </p>
      )}
      {(orders || []).map((o) => (
        <article key={o._id} className="bg-surface-container-low border-[0.5px] border-outline/30 rounded-lg p-md flex flex-col gap-sm">
          <header className="flex flex-wrap justify-between gap-sm">
            <p className="font-label-caps text-label-caps text-on-surface-variant">
              Order {o._id.slice(-6).toUpperCase()} · {new Date(o.createdAt).toLocaleDateString("en-IN")}
            </p>
            <span className="font-label-caps text-label-caps text-gold-muted uppercase">{o.status}</span>
          </header>
          {o.items.map((i) => (
            <div key={i.productId + i.size + i.color} className="flex items-center gap-sm">
              {/* i.product is the populated Product document */}
              {i.product?.image && <img src={i.product.image} alt="" className="w-12 h-16 object-cover rounded" />}
              <div className="flex-1 min-w-0">
                <p className="font-body-md text-on-surface truncate">{i.name}</p>
                <p className="font-label-caps text-label-caps text-on-surface-variant">Qty {i.qty}</p>
              </div>
              <span className="text-gold-muted font-body-md">{formatINR(i.price * i.qty)}</span>
            </div>
          ))}
          <footer className="flex justify-between border-t-[0.5px] border-outline/20 pt-sm font-headline-md text-headline-md text-gold-bright">
            <span>Total</span><span>{formatINR(o.total)}</span>
          </footer>
        </article>
      ))}
    </main>
  );
}
