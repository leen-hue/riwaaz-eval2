const jwt = require("jsonwebtoken");

const WEEK_MS = 7 * 24 * 60 * 60 * 1000;

exports.signToken = (user) =>
  jwt.sign({ sub: user._id.toString(), role: user.role }, process.env.JWT_SECRET, { expiresIn: "7d" });

// httpOnly keeps the token out of reach of page JavaScript (XSS).
const cookieOptions = () => ({
  httpOnly: true,
  sameSite: "lax",
  secure: process.env.NODE_ENV === "production",
  path: "/",
});

exports.setAuthCookie = (res, token) => res.cookie("token", token, { ...cookieOptions(), maxAge: WEEK_MS });
exports.clearAuthCookie = (res) => res.clearCookie("token", cookieOptions());
