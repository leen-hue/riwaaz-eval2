/**
 * npm run seed            -> products, admin user, and demo auction lots (only if none exist)
 * npm run seed:auction    -> wipes auctions and recreates the demo lots (handy for demos)
 */
require("dotenv").config();
const bcrypt = require("bcryptjs");
const mongoose = require("mongoose");
const connectDB = require("../config/db");
const Product = require("../models/Product");
const User = require("../models/User");
const Auction = require("../models/Auction");
const products = require("../data/products.json");

async function seedProducts() {
  // The "-auction" entry is the auction lot, handled below.
  const list = products.filter((p) => !p.id.endsWith("-auction"));
  for (const p of list) {
    await Product.updateOne(
      { productId: p.id },
      { $set: { name: p.name, price: p.price, image: p.image, category: p.category, description: p.description || "", size: p.size || "", color: p.color || "" } },
      { upsert: true }
    );
  }
  console.log(`Products upserted: ${list.length}`);
}

async function seedAdmin() {
  const { ADMIN_EMAIL, ADMIN_PASSWORD, ADMIN_NAME } = process.env;
  if (!ADMIN_EMAIL || !ADMIN_PASSWORD) return console.log("ADMIN_EMAIL / ADMIN_PASSWORD not set - skipping admin user.");
  if (ADMIN_PASSWORD.length < 8) throw new Error("ADMIN_PASSWORD must be at least 8 characters.");
  const email = ADMIN_EMAIL.trim().toLowerCase();
  const existing = await User.findOne({ email });
  if (existing) {
    if (existing.role !== "admin") {
      existing.role = "admin";
      await existing.save();
    }
    return console.log(`Admin ready: ${email}`);
  }
  await User.create({
    name: ADMIN_NAME || "Riwaaz Admin",
    email,
    passwordHash: await bcrypt.hash(ADMIN_PASSWORD, 12),
    role: "admin",
  });
  console.log(`Admin created: ${email}`);
}

async function seedAuctions({ reset }) {
  if (reset) await Auction.deleteMany({});
  if (await Auction.exists({})) return console.log("Auctions already exist - skipping (use npm run seed:auction to reset).");
  const lot = products.find((p) => p.id.endsWith("-auction"));
  const now = Date.now();
  await Auction.create([
    {
      title: "Heritage Ruby Choker",
      description:
        "A one-of-a-kind 22k gold choker set with uncut diamonds and Burmese rubies, hand-crafted by master karigars over 400 hours.",
      image: lot ? lot.image : "",
      basePrice: 240000,
      increment: 7500,
      currentBid: 240000,
      startsAt: new Date(now - 60 * 1000),
      status: "live",
    },
    {
      title: "The Zamindari Emerald Collection — Lot 07",
      description: "",
      image: "",
      basePrice: 150000,
      increment: 5000,
      currentBid: 150000,
      // same "3 days, 6 hours, 45 minutes from now" the static page showed
      startsAt: new Date(now + ((3 * 24 + 6) * 60 + 45) * 60 * 1000),
      status: "upcoming",
    },
  ]);
  console.log("Demo auction lots created.");
}

(async () => {
  try {
    await connectDB();
    await seedProducts();
    await seedAdmin();
    await seedAuctions({ reset: process.argv.includes("--reset-auction") });
  } catch (err) {
    console.error(err);
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
})();
