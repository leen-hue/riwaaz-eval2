// Call stack, callback queue, microtasks and non-blocking I/O.
// Run: node examples/02-event-loop.js   (predict the order before running!)
const fs = require("fs");

console.log("1 sync (call stack)");
setTimeout(() => console.log("5 setTimeout 0 (timers phase)"), 0);
setImmediate(() => console.log("6 setImmediate (check phase)"));
fs.readFile(__filename, () => console.log("7 fs.readFile callback (I/O finished, thread was never blocked)"));
Promise.resolve().then(() => console.log("3 promise .then (microtask queue)"));
process.nextTick(() => console.log("2 process.nextTick (runs before promises)"));
console.log("4 sync (still the same stack)");
