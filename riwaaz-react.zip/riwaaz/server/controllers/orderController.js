const Order = require("../models/Order");
const Cart = require("../models/Cart");
const Product = require("../models/Product");
const HttpError = require("../utils/httpError");
const asyncHandler = require("../utils/asyncHandler");
const events = require("../utils/events");
const { shipping } = require("../utils/validators");

const STATUSES = ["placed", "shipped", "delivered", "cancelled"];

// Turn the logged-in user's cart into an order. Prices come from the database.
exports.checkout = asyncHandler(async (req, res) => {
  const ship = shipping(req.body?.shipping);
  const cart = await Cart.findOne({ user: req.user._id });
  if (!cart || cart.items.length === 0) throw new HttpError(400, "Your bag is empty.");

  const products = await Product.find({ productId: { $in: cart.items.map((i) => i.productId) } });
  const byId = new Map(products.map((p) => [p.productId, p]));
  const items = cart.items
    .filter((i) => byId.has(i.productId))
    .map((i) => {
      const p = byId.get(i.productId);
      return { product: p._id, productId: p.productId, name: p.name, price: p.price, size: i.size, color: i.color, qty: i.qty };
    });
  if (items.length === 0) throw new HttpError(400, "None of the items in your bag are available any more.");

  const total = items.reduce((sum, i) => sum + i.price * i.qty, 0);
  const order = await Order.create({ user: req.user._id, items, total, shipping: ship });

  cart.items = [];
  await cart.save();
  events.emit("order:placed", order);
  res.status(201).json({ order });
});

// .populate() swaps the stored ObjectIds for the referenced documents.
exports.mine = asyncHandler(async (req, res) => {
  const orders = await Order.find({ user: req.user._id }).sort({ createdAt: -1 }).populate("items.product", "name image");
  res.json({ orders });
});

exports.get = asyncHandler(async (req, res) => {
  if (!/^[a-f\d]{24}$/i.test(String(req.params.id))) throw new HttpError(404, "Order not found.");
  const order = await Order.findById(req.params.id).populate("items.product", "name image").populate("user", "name email");
  // Authorization: owners see their own orders, admins see all.
  if (!order || (req.user.role !== "admin" && order.user._id.toString() !== req.user._id.toString())) {
    throw new HttpError(404, "Order not found.");
  }
  res.json({ order });
});

exports.all = asyncHandler(async (req, res) => {
  const orders = await Order.find().sort({ createdAt: -1 }).limit(200).populate("user", "name email");
  res.json({ orders });
});

exports.setStatus = asyncHandler(async (req, res) => {
  const status = req.body?.status;
  if (!STATUSES.includes(status)) throw new HttpError(400, "Invalid status.");
  const order = await Order.findByIdAndUpdate(String(req.params.id), { status }, { new: true, runValidators: true });
  if (!order) throw new HttpError(404, "Order not found.");
  res.json({ order });
});
