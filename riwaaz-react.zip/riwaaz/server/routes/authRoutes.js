const router = require("express").Router();
const rateLimit = require("express-rate-limit");
const c = require("../controllers/authController");
const { optionalAuth } = require("../middleware/auth");

// Slows down password guessing.
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: "Too many attempts. Please try again in a few minutes." },
});

router.post("/register", limiter, c.register);
router.post("/login", limiter, c.login);
router.post("/logout", c.logout);
router.get("/me", optionalAuth, c.me);

module.exports = router;
