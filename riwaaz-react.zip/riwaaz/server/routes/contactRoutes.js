const router = require("express").Router();
const rateLimit = require("express-rate-limit");
const c = require("../controllers/contactController");
const { requireAuth } = require("../middleware/auth");
const { requireRole } = require("../middleware/role");

const limiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 10, message: { message: "Too many messages. Please try later." } });

router.post("/", limiter, c.create);
router.get("/", requireAuth, requireRole("admin"), c.list);

module.exports = router;
