// Reusable controlled input (props: parent -> child communication).
export default function FormField({ label, name, value, onChange, error, as = "input", ...rest }) {
  const Tag = as;
  return (
    <div>
      <label htmlFor={name} className="font-label-caps text-label-caps text-on-surface-variant block mb-xs">
        {label}
      </label>
      <Tag
        id={name}
        name={name}
        value={value}
        onChange={onChange}
        className={
          "w-full bg-surface-container rounded-DEFAULT border-[0.5px] px-sm py-xs font-body-md text-on-surface focus:outline-none focus:border-primary " +
          (error ? "border-error" : "border-outline/30")
        }
        {...rest}
      />
      {error && <p className="font-label-caps text-label-caps text-error mt-xs">{error}</p>}
    </div>
  );
}
