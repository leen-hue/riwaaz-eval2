import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useUI } from "../context/UIContext";
import { useEffect } from "react";

/** Blocks a route unless the user is logged in (and has `role`, if given). */
export default function ProtectedRoute({ role, children }) {
  const { user, loading } = useAuth();
  const { openModal } = useUI();

  useEffect(() => {
    if (!loading && !user) openModal("account");
  }, [loading, user, openModal]);

  if (loading) return null;
  if (!user || (role && user.role !== role)) return <Navigate to="/" replace />;
  return children;
}
