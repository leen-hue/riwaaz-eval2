const router = require("express").Router();
const c = require("../controllers/cartController");
const { requireAuth } = require("../middleware/auth");

router.use(requireAuth); // every cart is private to its owner (req.user)
router.get("/", c.get);
router.post("/items", c.addItem);
router.patch("/items", c.setQty);
router.delete("/items", c.removeItem);
router.post("/merge", c.merge);

module.exports = router;
