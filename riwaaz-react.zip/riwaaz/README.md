# RIWAAZ — React + Express + MongoDB

```
client/   React (Vite) + Tailwind  — the original pages, converted to components
server/   Express + MongoDB (Mongoose), JWT auth, roles, multer uploads
```

## Run it

```bash
# 1. server
cd server
cp .env.example .env        # set JWT_SECRET and MONGO_URI (local mongod or Atlas)
npm install
npm run seed                # products, admin user, demo auction lots
npm run dev                 # http://localhost:5000

# 2. client (new terminal)
cd client
npm install
npm run dev                 # http://localhost:5173  (proxies /api and /uploads to :5000)
```

Log in with the `ADMIN_EMAIL` / `ADMIN_PASSWORD` from `.env` to reach `/admin`
(account icon → Admin Dashboard). `npm run seed:auction` resets the demo auction.

## API

| Method | Route | Access |
|---|---|---|
| POST | /api/auth/register, /login, /logout | public |
| GET | /api/auth/me | public (returns `user: null` if logged out) |
| GET | /api/products, /api/products/:id | public |
| POST/PUT/DELETE | /api/products[/:id] (multipart, field `image`) | admin |
| GET/POST/PATCH/DELETE | /api/cart, /api/cart/items, POST /api/cart/merge | logged in |
| GET/POST/DELETE | /api/wishlist, /toggle, /merge, /:productId | logged in |
| GET | /api/auctions | public |
| POST | /api/auctions/:id/bid | logged in |
| POST/DELETE | /api/auctions[/:id] (multipart, field `image`) | admin |

## Extra: course-topic demos
- `server/examples/` — runnable Node demos: async patterns (callbacks → promises → async/await), event loop order, fs/path/Buffer/streams/EventEmitter, a raw `http` server with manual routing, and an ES-module script. Run e.g. `node examples/02-event-loop.js`. Start Node's REPL with `node`.
- `server/postman/riwaaz.postman_collection.json` — import into Postman to test every endpoint.
- Orders (`/api/orders`, Mongoose `populate`), Contact form (Fetch API + localStorage draft), and the order log written with an `fs` stream via EventEmitter.
