import { useCallback, useEffect, useRef, useState } from "react";
import api, { errorMessage } from "../api/client";
import { useAuth } from "../context/AuthContext";
import { useUI } from "../context/UIContext";
import { formatINR } from "../utils/format";

const EMPTY = {
  title: "Heritage Ruby Choker", basePrice: 240000, increment: 7500,
  currentBid: 240000, bidCount: 0, status: "live", endsAt: null,
};

/**
 * Live auction state comes from the server (so every visitor sees the same
 * lot). The server owns the 5-second window: each valid bid extends `endsAt`,
 * and the lot is sold once `endsAt` passes. We poll once a second and tick a
 * local clock for the countdown display.
 */
export function useAuction() {
  const { user } = useAuth();
  const { showToast, openModal } = useUI();
  const [state, setState] = useState({ auction: null, next: null, windowSeconds: 5 });
  const [clockOffset, setClockOffset] = useState(0); // serverTime - Date.now()
  const [now, setNow] = useState(Date.now());
  const [busy, setBusy] = useState(false);
  const announcedEnd = useRef(false);

  const fetchState = useCallback(async () => {
    try {
      const res = await api.get("/auctions");
      setClockOffset(new Date(res.data.serverTime).getTime() - Date.now());
      setState(res.data);
    } catch {
      /* keep showing the last known state */
    }
  }, []);

  useEffect(() => {
    fetchState();
    const poll = setInterval(fetchState, 1000);
    const tick = setInterval(() => setNow(Date.now()), 250);
    return () => {
      clearInterval(poll);
      clearInterval(tick);
    };
  }, [fetchState]);

  const auction = state.auction || EMPTY;
  const serverNow = now + clockOffset;
  const endsAtMs = auction.endsAt ? new Date(auction.endsAt).getTime() : null;
  const ended = auction.status === "ended" || (endsAtMs !== null && serverNow >= endsAtMs);
  const showTimer = endsAtMs !== null && !ended;
  const secondsLeft = endsAtMs
    ? Math.max(0, Math.min(state.windowSeconds, Math.ceil((endsAtMs - serverNow) / 1000)))
    : state.windowSeconds;

  useEffect(() => {
    if (ended && state.auction && !announcedEnd.current) {
      announcedEnd.current = true;
      showToast(`Auction ended — winning bid ${formatINR(auction.currentBid)}`);
    }
    if (!ended) announcedEnd.current = false;
  }, [ended, state.auction, auction.currentBid, showToast]);

  // "Next auction" countdown (DD:HH:MM)
  const nextStart = state.next ? new Date(state.next.startsAt).getTime() : null;
  const diff = nextStart ? nextStart - serverNow : 0;
  const totalMinutes = Math.max(0, Math.floor(diff / 60000));
  const pad = (n) => String(n).padStart(2, "0");
  const countdown = {
    done: nextStart !== null && diff <= 0,
    days: pad(Math.floor(totalMinutes / (60 * 24))),
    hours: pad(Math.floor((totalMinutes % (60 * 24)) / 60)),
    mins: pad(totalMinutes % 60),
    name: state.next ? state.next.title : "No upcoming auctions scheduled",
  };

  const placeBid = useCallback(async () => {
    if (!user) {
      showToast("Please log in to place a bid");
      openModal("account");
      return;
    }
    if (!state.auction || busy) return;
    setBusy(true);
    try {
      const res = await api.post(`/auctions/${state.auction.id}/bid`);
      setState((s) => ({ ...s, auction: res.data.auction }));
      setClockOffset(new Date(res.data.serverTime).getTime() - Date.now());
      showToast(`Bid placed — ${formatINR(res.data.auction.currentBid)}`);
    } catch (err) {
      showToast(errorMessage(err));
      fetchState();
    } finally {
      setBusy(false);
    }
  }, [user, state.auction, busy, showToast, openModal, fetchState]);

  return { auction, countdown, ended, showTimer, secondsLeft, placeBid, busy };
}
