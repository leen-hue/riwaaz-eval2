const mongoose = require("mongoose");

module.exports = mongoose.model(
  "Message",
  new mongoose.Schema(
    {
      name: { type: String, required: true, maxlength: 80 },
      email: { type: String, required: true, lowercase: true },
      message: { type: String, required: true, minlength: 10, maxlength: 2000 },
    },
    { timestamps: true }
  )
);
