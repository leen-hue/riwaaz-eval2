const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const multer = require("multer");
const HttpError = require("../utils/httpError");

const UPLOAD_DIR = path.join(__dirname, "..", "uploads");
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// Extension comes from the verified MIME type, never from the client's file name.
const EXT = { "image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp" };

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${crypto.randomBytes(8).toString("hex")}${EXT[file.mimetype]}`),
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024, files: 1 },
  fileFilter: (req, file, cb) =>
    EXT[file.mimetype] ? cb(null, true) : cb(new HttpError(400, "Only JPG, PNG or WebP images are allowed.")),
});

// Removes a previously uploaded file (only ever touches our own uploads folder).
function removeUpload(publicPath) {
  if (!publicPath || !publicPath.startsWith("/uploads/")) return;
  const file = path.join(UPLOAD_DIR, path.basename(publicPath));
  fs.unlink(file, () => {});
}

module.exports = { upload, removeUpload, UPLOAD_DIR };
