// Callbacks -> Promises -> Promise chaining -> async/await -> error handling
// Run: node examples/01-async-patterns.js
const fs = require("fs");
const path = require("path");
const file = path.join(__dirname, "..", "data", "products.json");

// 1) Callback style (error-first)
fs.readFile(file, "utf8", (err, text) => {
  if (err) return console.error("callback error:", err.message);
  console.log("1) callback: products.json has", JSON.parse(text).length, "products");

  // 2) Promise + chaining
  fs.promises
    .readFile(file, "utf8")
    .then((t) => JSON.parse(t))
    .then((list) => list.filter((p) => p.price > 100000))
    .then((expensive) => console.log("2) promise chain:", expensive.length, "products over ₹1,00,000"))
    .catch((e) => console.error("promise error:", e.message))
    .finally(() => run()); // 3) continue with async/await
});

// 3) async/await with try/catch + Promise.all
const delay = (ms, value, fail) => new Promise((res, rej) => setTimeout(() => (fail ? rej(new Error(value)) : res(value)), ms));

async function run() {
  try {
    const results = await Promise.all([delay(50, "a"), delay(10, "b")]);
    console.log("3) Promise.all:", results);
    await delay(5, "boom", true);
  } catch (e) {
    console.log("3) caught with try/catch:", e.message);
  }
  const settled = await Promise.allSettled([delay(5, "ok"), delay(5, "bad", true)]);
  console.log("4) allSettled:", settled.map((s) => s.status));
}
