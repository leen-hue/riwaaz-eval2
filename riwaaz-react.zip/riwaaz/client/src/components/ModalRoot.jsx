import { useEffect } from "react";
import { useUI } from "../context/UIContext";
import AccountPanel from "./AccountPanel";
import WishlistPanel from "./WishlistPanel";

export default function ModalRoot() {
  const { modal, closeModal } = useUI();

  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && closeModal();
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [closeModal]);

  if (!modal) return null;
  return (
    <div className="fixed inset-0 z-[10000] flex items-center justify-center p-md">
      <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" onClick={closeModal}></div>
      <div className="relative w-full max-w-md bg-surface-container-high border-[0.5px] border-outline/30 rounded-lg shadow-xl p-lg max-h-[85vh] overflow-y-auto">
        {modal === "wishlist" && <WishlistPanel />}
        {modal === "account" && <AccountPanel />}
      </div>
    </div>
  );
}
