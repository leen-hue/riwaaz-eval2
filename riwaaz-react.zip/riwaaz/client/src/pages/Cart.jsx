import { Link } from "react-router-dom";
import { PRODUCTS } from "../data/products";
import { useShop } from "../context/ShopContext";
import { formatINR, wishClass } from "../utils/format";
import CartLine from "../components/CartLine";

export const meta = { page: "cart", route: "/cart", title: "VEDA - Shopping Cart", bodyClass: "bg-background text-on-background font-body-md min-h-screen noise-bg flex flex-col" };

export default function Cart() {
  const { addToBag, toggleWishlist, isSaved, items, subtotal } = useShop();
  return (
    <>
      <main className="flex-grow px-margin-mobile md:px-margin-desktop py-lg max-w-[1920px] mx-auto w-full relative z-10">
        <h1 className="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg mb-lg">
          Your Bag
        </h1>
        <div className="flex flex-col lg:flex-row gap-lg md:gap-xl">
          <div className="flex-1 flex flex-col gap-md">
            <div id="cart-empty-state" className={items.length === 0 ? "hidden flex flex-col items-center justify-center text-center gap-md py-xl border-[0.5px] border-outline/20 rounded-lg bg-surface-container-low".replace("hidden ", "") : "hidden flex flex-col items-center justify-center text-center gap-md py-xl border-[0.5px] border-outline/20 rounded-lg bg-surface-container-low"}>
              <span className="material-symbols-outlined text-[48px] text-on-surface-variant">
                shopping_bag
              </span>
              <div>
                <h3 className="font-headline-md text-headline-md text-on-surface mb-xs">
                  Your bag is empty
                </h3>
                <p className="font-body-md text-body-md text-on-surface-variant">
                  Looks like you haven't added anything yet.
                </p>
              </div>
              <Link className="gold-gradient-bg text-on-primary font-label-caps text-label-caps px-lg py-sm rounded-full hover:scale-105 transition-transform" to="/">
                Start Shopping
              </Link>
            </div>
            <div id="cart-items-list" className="flex flex-col gap-md">
              {items.map((item) => <CartLine key={item.key} item={item} />)}
            </div>
          </div>
          <div className="w-full lg:w-96 shrink-0">
            <div className="sticky top-[100px] bg-surface-container-high/80 backdrop-blur-md rounded-xl p-md border-[0.5px] border-outline/30 flex flex-col gap-md">
              <h2 className="font-headline-md text-headline-md border-b-[0.5px] border-outline/20 pb-sm">
                Order Summary
              </h2>
              <div className="flex flex-col gap-sm font-body-md text-body-md">
                <div className="flex justify-between text-on-surface-variant">
                  <span className="">
                    Subtotal
                  </span>
                  <span className="text-on-surface" id="cart-subtotal">
                    {formatINR(subtotal)}
                  </span>
                </div>
                <div className="flex justify-between text-on-surface-variant">
                  <span className="">
                    Shipping (Estimated)
                  </span>
                  <span className="text-on-surface">
                    Calculated at checkout
                  </span>
                </div>
                <div className="flex justify-between text-on-surface-variant">
                  <span className="">
                    Taxes
                  </span>
                  <span className="text-on-surface">
                    Included
                  </span>
                </div>
              </div>
              <div className="border-t-[0.5px] border-outline/20 pt-md mt-xs flex justify-between items-end">
                <span className="font-headline-md text-headline-md">
                  Total
                </span>
                <span className="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg text-gold-bright" id="cart-total">
                  {formatINR(subtotal)}
                </span>
              </div>
              <Link to="/checkout" className="w-full mt-sm py-sm rounded-lg gold-gradient-bg text-on-primary font-label-caps text-label-caps uppercase tracking-widest gold-glow hover:scale-[1.02] transition-transform active:scale-95 flex justify-center items-center gap-xs">
                Proceed to Checkout
                <span className="material-symbols-outlined text-sm">
                  arrow_forward
                </span>
              </Link>
              <div className="mt-sm flex justify-center gap-sm text-on-surface-variant opacity-70">
                <span className="material-symbols-outlined text-sm">
                  lock
                </span>
                <span className="font-label-caps text-[10px] tracking-widest uppercase">
                  Secure Checkout
                </span>
              </div>
            </div>
          </div>
        </div>
        <section className="mt-xl pt-lg border-t-[0.5px] border-outline/20">
          <h2 className="font-headline-md text-headline-md mb-md text-gold-muted">
            You May Also Like
          </h2>
          <div className="flex overflow-x-auto gap-gutter hide-scrollbar pb-sm">
            <div className="w-48 md:w-64 shrink-0 group cursor-pointer" data-product data-product-id="gold-tissue-scallop-dupatta" data-product-name="Gold Tissue Scallop Dupatta" data-product-price="15000" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuDbkSN6bIJbYq-SXlYijXFTMHNu0QguQU8AdP1ZywktZ4HKeYDJHlAg6D2FrC2MgW4GI9MSoKu8F0cTuRBl2pTWkjg8uDFBQZwel5qmkpyhPD7-4o0eSkQC7YE-KWWww3H4qP2dXZJUPoTNTkgWeVdbXInmSl-y8DZUr1hF2BxnkQL6B0WNoNrPebKCtqTIc0uYN4a-3QshediGL_yb1XHs9s8nSmpH4hOyMTcASnsr1n0-h-_CpKxFZQ">
              <div className="aspect-[3/4] rounded-lg bg-surface-container overflow-hidden mb-sm relative">
                <img className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" data-alt="A shimmering gold tissue silk dupatta with scalloped borders and heavy embellishments, draped elegantly on a dark background to highlight its metallic sheen." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDbkSN6bIJbYq-SXlYijXFTMHNu0QguQU8AdP1ZywktZ4HKeYDJHlAg6D2FrC2MgW4GI9MSoKu8F0cTuRBl2pTWkjg8uDFBQZwel5qmkpyhPD7-4o0eSkQC7YE-KWWww3H4qP2dXZJUPoTNTkgWeVdbXInmSl-y8DZUr1hF2BxnkQL6B0WNoNrPebKCtqTIc0uYN4a-3QshediGL_yb1XHs9s8nSmpH4hOyMTcASnsr1n0-h-_CpKxFZQ" />
                <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-sm">
                  <button className="w-full py-xs border-[0.5px] border-gold-muted text-gold-muted font-label-caps text-label-caps uppercase hover:bg-gold-muted hover:text-on-primary transition-colors backdrop-blur-sm" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["gold-tissue-scallop-dupatta"]); }}>
                    Add to Bag
                  </button>
                </div>
              </div>
              <h4 className="font-body-md text-body-md truncate">
                Gold Tissue Scallop Dupatta
              </h4>
              <p className="font-label-caps text-label-caps text-gold-muted mt-xs">
                ₹15,000
              </p>
            </div>
            <div className="w-48 md:w-64 shrink-0 group cursor-pointer" data-product data-product-id="velvet-zardozi-potli" data-product-name="Velvet Zardozi Potli" data-product-price="8500" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuAfCbH2JumA56fPF4e6nCw7gK49Gz2myAQ1H-X-Mh1V3OFsn3hJvH1b6CcWb56sTjx0yrqJ-ZwjqmT7PEYLxghnEVhnzjhzW76b38NOOBSCOU5HsOobNmmG1_dw5zGnEPrO5QnxlMeSENUDt8-T7KuQkvjtpp6DVRjJLSkt8-cvDzuZsTSfpLjmU7r56urJhtW3IAW8xOUV0p98VVATvNHIy16LF9QYE0EUVJmDDpK6le1ScLV351kwtA">
              <div className="aspect-[3/4] rounded-lg bg-surface-container overflow-hidden mb-sm relative">
                <img className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" data-alt="An ornate handcrafted potli bag in deep maroon velvet, adorned with antique gold zardozi embroidery and pearl tassels, sitting on a polished stone surface." src="https://lh3.googleusercontent.com/aida-public/AB6AXuAfCbH2JumA56fPF4e6nCw7gK49Gz2myAQ1H-X-Mh1V3OFsn3hJvH1b6CcWb56sTjx0yrqJ-ZwjqmT7PEYLxghnEVhnzjhzW76b38NOOBSCOU5HsOobNmmG1_dw5zGnEPrO5QnxlMeSENUDt8-T7KuQkvjtpp6DVRjJLSkt8-cvDzuZsTSfpLjmU7r56urJhtW3IAW8xOUV0p98VVATvNHIy16LF9QYE0EUVJmDDpK6le1ScLV351kwtA" />
                <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-sm">
                  <button className="w-full py-xs border-[0.5px] border-gold-muted text-gold-muted font-label-caps text-label-caps uppercase hover:bg-gold-muted hover:text-on-primary transition-colors backdrop-blur-sm" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["velvet-zardozi-potli"]); }}>
                    Add to Bag
                  </button>
                </div>
              </div>
              <h4 className="font-body-md text-body-md truncate">
                Velvet Zardozi Potli
              </h4>
              <p className="font-label-caps text-label-caps text-gold-muted mt-xs">
                ₹8,500
              </p>
            </div>
            <div className="w-48 md:w-64 shrink-0 group cursor-pointer" data-product data-product-id="ivory-embroidered-mojari" data-product-name="Ivory Embroidered Mojari" data-product-price="6200" data-product-image="https://lh3.googleusercontent.com/aida-public/AB6AXuARb_jqOor-4piigeo-nnc9BRlbSwS34kBPfxCwZ2Gp5TrQ0LTbCLwa2Fpwd8qxcLN0YkZDCHSw4prn6GuQikg1D2BpOdvEtLwuhYIKm4W4UC9wparHmtipkZJAM4eqpcdjoRkscRBPSW18XaXeaBuhjP1aUfqaLyFJnjfHAI61MFYA8_XsBX-uNPMyEo35qBg7KmIo8OndCoMqFRkhV9PWf3674954VfQG9_pflRVGRsK3f0cMQC9ciA">
              <div className="aspect-[3/4] rounded-lg bg-surface-container overflow-hidden mb-sm relative">
                <img className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" data-alt="A pair of traditional men's embroidered mojari shoes in ivory raw silk with subtle gold accents, placed on a dark, textured velvet fabric." src="https://lh3.googleusercontent.com/aida-public/AB6AXuARb_jqOor-4piigeo-nnc9BRlbSwS34kBPfxCwZ2Gp5TrQ0LTbCLwa2Fpwd8qxcLN0YkZDCHSw4prn6GuQikg1D2BpOdvEtLwuhYIKm4W4UC9wparHmtipkZJAM4eqpcdjoRkscRBPSW18XaXeaBuhjP1aUfqaLyFJnjfHAI61MFYA8_XsBX-uNPMyEo35qBg7KmIo8OndCoMqFRkhV9PWf3674954VfQG9_pflRVGRsK3f0cMQC9ciA" />
                <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-sm">
                  <button className="w-full py-xs border-[0.5px] border-gold-muted text-gold-muted font-label-caps text-label-caps uppercase hover:bg-gold-muted hover:text-on-primary transition-colors backdrop-blur-sm" onClick={(e) => { e.preventDefault(); e.stopPropagation(); addToBag(PRODUCTS["ivory-embroidered-mojari"]); }}>
                    Add to Bag
                  </button>
                </div>
              </div>
              <h4 className="font-body-md text-body-md truncate">
                Ivory Embroidered Mojari
              </h4>
              <p className="font-label-caps text-label-caps text-gold-muted mt-xs">
                ₹6,200
              </p>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}
