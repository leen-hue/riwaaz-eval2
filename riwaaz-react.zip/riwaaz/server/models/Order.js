const mongoose = require("mongoose");

const orderSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
    items: [
      {
        _id: false,
        // Reference to the product document (used with .populate()), plus a
        // snapshot so the order still reads correctly if the product changes.
        product: { type: mongoose.Schema.Types.ObjectId, ref: "Product", required: true },
        productId: String,
        name: String,
        price: Number,
        size: String,
        color: String,
        qty: { type: Number, required: true, min: 1 },
      },
    ],
    total: { type: Number, required: true, min: 0 },
    status: { type: String, enum: ["placed", "shipped", "delivered", "cancelled"], default: "placed" },
    shipping: {
      fullName: { type: String, required: true },
      phone: { type: String, required: true },
      address: { type: String, required: true },
      city: { type: String, required: true },
      pincode: { type: String, required: true },
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Order", orderSchema);
