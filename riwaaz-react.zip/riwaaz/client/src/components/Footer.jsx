import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="bg-surface-container-lowest dark:bg-surface-container-lowest text-primary dark:text-primary font-label-caps text-label-caps w-full py-xl border-t-[0.5px] border-outline/20">
      <div className="grid grid-cols-12 gap-gutter px-margin-mobile md:px-margin-desktop max-w-[1920px] mx-auto">
        <div className="col-span-12 md:col-span-4 flex flex-col gap-lg">
          <span className="font-headline-lg text-headline-lg text-gold-muted">
            RIWAAZ
          </span>
          <p className="font-body-md text-body-md text-on-surface-variant normal-case max-w-sm">
            Crafting heritage luxury for the modern era. Deeply rooted in tradition, elevated for the avant-garde.
          </p>
        </div>
        <div className="col-span-6 md:col-span-4 flex flex-col gap-md">
          <a className="text-on-surface-variant hover:text-primary transition-colors hover:translate-x-1 transition-transform inline-block w-max" href="#">
            Our Story
          </a>
          <a className="text-on-surface-variant hover:text-primary transition-colors hover:translate-x-1 transition-transform inline-block w-max" href="#">
            Craftsmanship
          </a>
          <a className="text-on-surface-variant hover:text-primary transition-colors hover:translate-x-1 transition-transform inline-block w-max" href="#">
            Sustainability
          </a>
        </div>
        <div className="col-span-6 md:col-span-4 flex flex-col gap-md">
          <a className="text-on-surface-variant hover:text-primary transition-colors hover:translate-x-1 transition-transform inline-block w-max" href="#">
            Shipping & Returns
          </a>
          <Link className="text-on-surface-variant hover:text-primary transition-colors hover:translate-x-1 transition-transform inline-block w-max" to="/contact">
            Contact Us
          </Link>
          <a className="text-on-surface-variant hover:text-primary transition-colors hover:translate-x-1 transition-transform inline-block w-max" href="#">
            Store Locator
          </a>
        </div>
        <div className="col-span-12 mt-xl pt-lg border-t-[0.5px] border-outline/10 text-on-surface-variant text-center md:text-left">
          © 2024 RIWAAZ LUXURY ETHNIC. ALL RIGHTS RESERVED.
        </div>
      </div>
    </footer>
  );
}
